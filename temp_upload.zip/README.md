
# FreteCerto - Truck Logistics (v1.0.0 STABLE)

> **VERSÃO:** 1.0.0 (MVP)
> **STATUS:** Produção (Offline-First / Local)
> **DATA:** Dezembro 2025

O **FreteCerto** é uma plataforma de inteligência logística para caminhoneiros autônomos e pequenas transportadoras. O sistema oferece cálculo de viabilidade de fretes, gestão de custos, manutenção de frota e análise financeira.

---

## 1. Arquitetura do Sistema (v1.0)
Nesta versão, o sistema opera em modo **Offline-First**. Isso garante velocidade máxima e funcionamento mesmo sem internet constante na estrada.

*   **Frontend:** React (Vite) + TypeScript + TailwindCSS.
*   **Banco de Dados:** `localStorage` do navegador (Simulando uma API REST).
*   **Autenticação:** Local (Usuários salvos no dispositivo).
*   **Integrações:**
    *   **IA:** Google Gemini (Análise de Rotas e Relatórios de Frota).
    *   **Mapas/Pedágio:** Google Maps API / TollGuru (via Proxy).
    *   **FIPE:** Parallelum API.
    *   **SMS:** Twilio (Configurável).

## 2. Funcionalidades Principais

### 🚛 Para o Motorista
*   **Calculadora de Viabilidade:** Insira origem, destino e valor do frete. O sistema calcula pedágios, combustível (diesel), desgaste de pneus e manutenção para dar o **Lucro Líquido Real**.
*   **Gestão de Pneus:** Controle detalhado de pneus (Novos vs Remold) por eixo (Direcional, Tração, Carreta).
*   **Manutenção:** Registro de troca de óleos (Motor/Câmbio) e Filtros com alertas de KM.
*   **Custo Fixo:** Cálculo automático do custo diário do caminhão parado (Depreciação + Salário + Seguro).

### 🏢 Para a Transportadora (ERP Oculto/Ativável)
*   **Dashboard Financeiro:** Fluxo de caixa, receitas vs despesas.
*   **Gestão de RH:** Cadastro de motoristas e controle de vencimento de CNH.
*   **Relatórios Inteligentes:** A IA analisa os dados financeiros e sugere cortes de custos.

### ⚙️ Painel Administrativo (Root)
*   Gestão de Usuários (Bloqueio, Edição de Créditos).
*   Configuração de Planos de Venda.
*   Configuração de Chaves de API (Sem mexer no código).
*   Backups e Exportação de Dados.

---

## 3. Guia de Instalação e Deploy

Consulte o arquivo `DEPLOY.md` para instruções detalhadas sobre como subir este projeto para o GitHub e hospedar em uma VPS (Hostinger).

## 4. Migração para Banco de Dados Real (Supabase)

Atualmente, os dados residem no navegador do usuário. Para migrar para um banco de dados em nuvem (PostgreSQL/Supabase), consulte o arquivo `SUPABASE_SETUP.md`.

---

## 5. Credenciais de Desenvolvimento (Local)

*   **Super Admin (Backdoor):** O número `(48) 99933-5785` possui acesso Root automático ao fazer login com qualquer senha.
*   **Modo de Teste:** O Admin possui um botão "Testar Calculadora" no painel para simular o uso do aplicativo como usuário final.
