
# Guia de Deploy - FreteCerto v1.0

Este guia orienta o processo de colocar o sistema em um repositório Git e subi-lo para um servidor VPS (Hostinger) ou Hospedagem Compartilhada.

## 1. Preparando o Git (Upload para GitHub)

1.  Crie um novo repositório no **GitHub** (ex: `fretecerto-app`).
2.  No terminal do seu computador (na pasta do projeto), execute:

```bash
# Inicializa o Git
git init

# Adiciona todos os arquivos (o .gitignore vai ignorar o node_modules)
git add .

# Salva a primeira versão
git commit -m "Versão 1.0.0 - MVP Finalizado"

# Conecta ao seu repositório remoto (Substitua a URL pela sua)
git remote add origin https://github.com/SEU_USUARIO/fretecerto-app.git

# Envia os arquivos
git push -u origin master
```

---

## 2. Deploy (Servidor Apache / Hostinger)

Se você está usando **Apache** (padrão em hospedagens compartilhadas e muitas VPS), siga estes passos.

### Passo 1: Gerar o Build
No seu computador, gere a versão de produção. O sistema já inclui um arquivo `.htaccess` automático para corrigir rotas.

```bash
npm install
npm run build
```

Isso criará uma pasta chamada `dist`.

### Passo 2: Enviar Arquivos
1.  Acesse seu servidor via **FTP (FileZilla)** ou **Gerenciador de Arquivos** da Hostinger.
2.  Navegue até a pasta pública (`public_html` ou `/var/www/html`).
3.  **Apague** o conteúdo antigo dessa pasta.
4.  **Copie** todo o conteúdo de DENTRO da pasta `dist` (do seu PC) para dentro da `public_html`.

### Passo 3: Verificar o .htaccess
Certifique-se de que o arquivo `.htaccess` (que estava na pasta `public` do projeto e foi copiado para `dist`) está presente no servidor. Ele é invisível em alguns gerenciadores de arquivos.

O conteúdo dele deve ser:
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteCond %{REQUEST_FILENAME} !-l
  RewriteRule . /index.html [L]
</IfModule>
```

**Nota:** Se você estiver usando VPS, garanta que o `mod_rewrite` esteja ativado e o `AllowOverride All` configurado no seu `apache2.conf` ou `httpd.conf`.

---

## 3. Variáveis de Ambiente
Como o sistema v1.0 permite configuração via **Painel Root**, você não precisa configurar arquivo `.env` complexo no servidor.

1. Acesse o sistema pelo navegador.
2. Faça login como Root ou Admin.
3. Vá em "APIs & Config" e insira suas chaves do Supabase, Google Maps e Gemini.
