
export interface PaymentValidationResult {
    success: boolean;
    message: string;
}

// Lista de Proxies para garantir que a requisição passe (Fallback)
// Removed 'allorigins' because it doesn't support custom headers or POST bodies reliably.
const CORS_PROXIES = [
    "https://corsproxy.io/?",
    "https://thingproxy.freeboard.io/fetch/"
];

// Helper para tentar múltiplos proxies
const fetchWithProxyFallback = async (targetUrl: string, options: RequestInit): Promise<Response> => {
    let lastError;
    for (const proxy of CORS_PROXIES) {
        try {
            const proxiedUrl = proxy + encodeURIComponent(targetUrl);
            const response = await fetch(proxiedUrl, options);
            
            // Verifica se houve uma resposta de rede válida
            if (response) {
                 return response; 
            }
        } catch (e) {
            console.warn(`Proxy ${proxy} failed, trying next...`);
            lastError = e;
        }
    }
    throw lastError || new Error("Falha ao conectar através dos proxies.");
};

export const validateMercadoPagoCredentials = async (accessToken: string): Promise<PaymentValidationResult> => {
    if (!accessToken) {
        return { success: false, message: "O Access Token está vazio." };
    }

    try {
        // Endpoint seguro para testar token: Dados do Usuário
        const targetUrl = "https://api.mercadopago.com/users/me";

        const response = await fetchWithProxyFallback(targetUrl, {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${accessToken}`,
                "Content-Type": "application/json"
            }
        });

        if (response.status === 200) {
            try {
                const data = await response.json();
                
                // Validação extra para garantir que não é um HTML de erro do proxy mascarado de 200
                if (data && (data.id || data.site_id || data.nickname)) {
                    const userName = `${data.first_name || ''} ${data.last_name || ''}`.trim() || data.nickname || 'Usuário MP';
                    return { 
                        success: true, 
                        message: `✅ SUCESSO! Token Válido.\nConta: ${userName}\nID: ${data.id}\nPaís: ${data.site_id}`
                    };
                } else {
                    throw new Error("Resposta da API irreconhecível.");
                }
            } catch (jsonError) {
                // Se falhar ao ler JSON, provavelmente o proxy retornou HTML. Isso é um erro.
                return { success: false, message: "❌ ERRO: A API não retornou os dados esperados (Possível falha de Proxy)." };
            }
        } else if (response.status === 401 || response.status === 403) {
            return { success: false, message: "⛔ ERRO: Token inválido ou expirado (401/403)." };
        } else {
            return { success: false, message: `⚠️ ERRO: A API respondeu com código ${response.status}.` };
        }

    } catch (error: any) {
        return { success: false, message: `❌ ERRO DE CONEXÃO: ${error.message}` };
    }
};

export const validateStripeCredentials = async (secretKey: string): Promise<PaymentValidationResult> => {
    if (!secretKey) {
        return { success: false, message: "A Secret Key está vazia." };
    }

    try {
        // Endpoint seguro para testar token: Listar Clientes (limit 1)
        const targetUrl = "https://api.stripe.com/v1/customers?limit=1";

        const response = await fetchWithProxyFallback(targetUrl, {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${secretKey}`,
                "Content-Type": "application/x-www-form-urlencoded"
            }
        });

        if (response.status === 200) {
            try {
                const data = await response.json();
                // Verifica estrutura básica do Stripe
                if (data && data.object === 'list') {
                     return { success: true, message: "✅ SUCESSO! Chave Stripe Válida e Ativa." };
                } else {
                    throw new Error("Resposta inesperada do Stripe.");
                }
            } catch (e) {
                return { success: false, message: "❌ ERRO: Resposta inválida do servidor." };
            }
        } else if (response.status === 401) {
             return { success: false, message: "⛔ ERRO: Chave Stripe Inválida (401)." };
        } else {
             return { success: false, message: `⚠️ ERRO: A API Stripe respondeu com código ${response.status}.` };
        }
    } catch (error: any) {
        return { success: false, message: `❌ ERRO DE CONEXÃO: ${error.message}` };
    }
};
