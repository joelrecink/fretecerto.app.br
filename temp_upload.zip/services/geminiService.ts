
import { GoogleGenAI } from "@google/genai";
import { RouteData, VehicleData, SimulationResult, TollPlaza, FinancialRecord, SavedVehicle, Employee } from "../types";
import { getSystemConfig } from "./dbService";

// Helper safely access environment variables
const getEnvVar = (key: string): string => {
  try {
    if (typeof process !== 'undefined' && process.env && process.env[key]) {
      return process.env[key];
    }
  } catch (e) {}
  return '';
};

// DYNAMIC GENAI CLIENT GETTER
// This ensures we can switch keys at runtime from the Dashboard without rebuilding
const getGenAI = async () => {
    let apiKey = getEnvVar('API_KEY') || getEnvVar('VITE_API_KEY');
    
    // Try to get from System Config (LocalStorage) if not in Env
    if (!apiKey) {
        const config = await getSystemConfig();
        if (config.gemini_api_key) {
            apiKey = config.gemini_api_key;
        }
    }

    if (!apiKey) {
        console.warn("⚠️ Google Gemini API Key missing!");
        // Return a dummy client that will fail gracefully later or rely on fallbacks
    }

    return new GoogleGenAI({ apiKey: apiKey || 'dummy_key' });
};

// --- VALIDATE KEY ---
export const validateGeminiKey = async (key: string) => {
    if (!key) return { success: false, message: "Chave vazia." };
    try {
        const client = new GoogleGenAI({ apiKey: key });
        // Simple generation test
        await client.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: 'Test connection',
        });
        return { success: true, message: "✅ Gemini Conectado com Sucesso!" };
    } catch (e: any) {
        return { success: false, message: `Erro: ${e.message}` };
    }
};

const ROUTE_CACHE = new Map<string, any>();

// CORS Proxies configuration
const CORS_PROXIES = [
    "https://corsproxy.io/?",
    "https://thingproxy.freeboard.io/fetch/",
    "https://api.allorigins.win/raw?url="
];

// Helper to fetch using proxies
const fetchWithProxyFallback = async (targetUrl: string, options: RequestInit): Promise<Response> => {
    let lastError: any;
    
    // 1. Try Direct Fetch first (some APIs allow direct CORS)
    try {
        const response = await fetch(targetUrl, options);
        if (response.ok || response.status === 400 || response.status === 401 || response.status === 403) {
            return response;
        }
    } catch (e) {
        // Ignore direct fetch error
    }

    // 2. Try Proxies
    for (const proxy of CORS_PROXIES) {
        try {
            const proxiedUrl = proxy + encodeURIComponent(targetUrl);
            const response = await fetch(proxiedUrl, options);
            if (response.ok || response.status === 400 || response.status === 401 || response.status === 403) {
                 return response; 
            }
        } catch (e) {
            console.warn(`Proxy ${proxy} failed for ${targetUrl}:`, e);
            lastError = e;
        }
    }
    throw lastError || new Error("Falha de conexão com a API (Bloqueio de CORS).");
};

// Mapeamento Correto TollGuru
const getTollGuruVehicleType = (axles: number): string => {
    if (axles <= 2) return '2AxlesTruck';
    if (axles >= 9) return '9AxlesTruck';
    return `${axles}AxlesTruck`;
};

// --- TESTE CONEXÃO TOLLGURU ---
export const testTollGuruConnection = async (apiKey: string): Promise<{ success: boolean; message: string }> => {
    if (!apiKey) return { success: false, message: "Chave de API vazia." };
    const cleanKey = apiKey.trim();

    try {
        const TARGET_URL = 'https://apis.tollguru.com/toll/v2/origin-destination-waypoints';
        const payload = {
            from: { address: "Sao Paulo, SP, Brazil" },
            to: { address: "Campinas, SP, Brazil" },
            serviceProvider: "here",
            vehicle: { type: "2AxlesTruck" }
        };

        const response = await fetchWithProxyFallback(TARGET_URL, {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json', 
                'x-api-key': cleanKey 
            },
            body: JSON.stringify(payload)
        });

        if (response.status === 200) {
            return { success: true, message: "✅ Conexão bem-sucedida! Chave válida e ativa." };
        } else if (response.status === 403) {
            return { success: false, message: "⛔ Acesso Negado (403). Verifique a chave e as permissões do plano." };
        } else if (response.status === 401) {
            return { success: false, message: "⛔ Não Autorizado (401). Chave incorreta." };
        } else {
            const errText = await response.text();
            return { success: false, message: `Erro na API (${response.status}): ${errText.substring(0, 100)}` };
        }
    } catch (error: any) {
        return { success: false, message: `Erro de Rede: ${error.message}` };
    }
};

// --- TOLLGURU ROUTING ---
const fetchTollGuruRoute = async (
    vehicle: VehicleData, 
    stops: string[], 
    origin: string, 
    destination: string, 
    apiKey: string
) => {
    const TARGET_URL = 'https://apis.tollguru.com/toll/v2/origin-destination-waypoints';
    const cleanKey = apiKey.trim();
    
    const payload: any = {
        from: { address: origin },
        to: { address: destination },
        serviceProvider: "here",
        vehicle: {
            type: getTollGuruVehicleType(vehicle.axles),
            weight: { value: vehicle.cargoCapacity || 10, unit: "tonnes" },
            height: { value: 4.4, unit: "meter" },
            length: { value: 18, unit: "meter" },
            axles: vehicle.axles
        },
        fuelPrice: { value: vehicle.fuelPrice, currency: "BRL", units: "liter" },
        fuelEfficiency: { value: vehicle.fuelConsumption, units: "km/l" }
    };

    if (stops && stops.length > 0) {
        payload.waypoints = stops.map(addr => ({ address: addr }));
    }

    return await fetchWithProxyFallback(TARGET_URL, {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/json', 
            'x-api-key': cleanKey 
        },
        body: JSON.stringify(payload)
    });
};

const getCacheKey = (vehicle: VehicleData, route: RouteData) => {
    const points = [
        route.pickups[0].address,
        ...(route.waypoints?.map(w => w.address) || []),
        route.deliveries[route.deliveries.length - 1].address
    ].join('|');
    return `${points}-${vehicle.axles}-${vehicle.cargoCapacity}`;
};

export const analyzeRouteViability = async (
  vehicle: VehicleData,
  route: RouteData
): Promise<SimulationResult> => {
  
  const config = await getSystemConfig();
  const TOLLGURU_KEY = config.tollguru_key || '';
  
  const cacheKey = getCacheKey(vehicle, route);
  if (ROUTE_CACHE.has(cacheKey)) {
      console.log("Using Cached Route Analysis");
      return ROUTE_CACHE.get(cacheKey);
  }

  const origin = route.pickups[0].address;
  const destination = route.deliveries[route.deliveries.length - 1].address;
  const stops = [
      ...route.pickups.slice(1).map(p => p.address),
      ...(route.waypoints?.map(w => w.address) || []),
      ...route.deliveries.slice(0, -1).map(d => d.address)
  ].filter(s => s && s.trim().length > 0);

  const totalFreightValue = [...route.pickups, ...route.deliveries].reduce((acc, curr) => acc + (curr.value || 0), 0);

  // --- API DATA HOLDERS ---
  let realTollCost = 0;
  let realDistanceKm = 0;
  let realDurationHours = 0;
  let detectedTollPlazas: TollPlaza[] = [];
  let apiSuccess = false;

  // 1. Call TollGuru API (If Key Exists)
  if (TOLLGURU_KEY) {
      try {
          const response = await fetchTollGuruRoute(vehicle, stops, origin, destination, TOLLGURU_KEY);
          
          if (response.ok) {
              const data = await response.json();
              const routeInfo = data.routes ? data.routes[0] : null;
              
              if (routeInfo) {
                  apiSuccess = true;
                  realDistanceKm = (routeInfo.summary?.distance?.metric || 0) / 1000;
                  realDurationHours = (routeInfo.summary?.duration?.value || 0) / 3600;
                  realTollCost = routeInfo.costs?.tag || routeInfo.costs?.cash || 0;
                  
                  if (routeInfo.tolls && Array.isArray(routeInfo.tolls)) {
                      detectedTollPlazas = routeInfo.tolls.map((t: any) => ({
                          name: t.name || t.road || "Praça de Pedágio",
                          cost: t.tagCost || t.cashCost || 0
                      }));
                  }
              }
          } else {
              console.warn(`TollGuru API Warn ${response.status}:`, await response.text());
          }
      } catch (error) { 
          // Suppress error to avoid white screen, just log warn
          console.warn("TollGuru Network/Proxy Issue (Fallback to AI):", error); 
      }
  }

  // 2. Prepare AI Config (Hybrid Strategy)
  let geminiConfig: any = {};
  
  if (apiSuccess && realDistanceKm > 0) {
      geminiConfig = {
          responseMimeType: 'application/json'
      };
  } else {
      geminiConfig = {
          tools: [{ googleMaps: {} }, { googleSearch: {} }]
      };
  }

  const prompt = `
    Atue como um analista de logística de transporte de cargas no Brasil.
    
    DADOS DA ROTA (FONTE: ${apiSuccess ? 'API REAL (TOLLGURU)' : 'ESTIMATIVA'}):
    - Origem: ${origin}
    - Destino: ${destination}
    - Veículo: ${vehicle.axles} Eixos
    - Carga: ${vehicle.cargoCapacity} Ton
    ${apiSuccess 
        ? `- Distância EXATA: ${realDistanceKm.toFixed(2)} km`
        : '- Distância: Calcular estimativa precisa via Google Maps Data'}
    ${apiSuccess 
        ? `- Custo Pedágio REAL: R$ ${realTollCost.toFixed(2)}`
        : '- Pedágio: Estimar baseada em R$ 0,14/eixo/km se não houver dados'}
    ${apiSuccess 
        ? `- Tempo Viagem: ${realDurationHours.toFixed(1)} horas`
        : '- Tempo: Estimar'}

    FINANCEIRO:
    - Valor do Frete: R$ ${totalFreightValue.toFixed(2)}
    - Preço Diesel: R$ ${vehicle.fuelPrice}/L
    - Consumo Médio: ${vehicle.fuelConsumption} km/L

    TAREFA:
    1. Analise a viabilidade da viagem com base no LUCRO LÍQUIDO.
    2. Identifique rotas perigosas ou problemas na região.
    3. Retorne APENAS um JSON válido.
    
    Output JSON Format:
    {
      "viabilityScore": "high" | "medium" | "low",
      "viabilityMessage": "Resumo executivo...",
      "routeSuggestions": "Dicas de estrada...",
      "totalDistanceKm": number,
      "estimatedTollCost": number,
      "totalDurationHours": number
    }
  `;

  try {
    const ai = await getGenAI();
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: geminiConfig
    });

    let text = response.text || '{}';
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) text = jsonMatch[0];

    let aiData;
    try { aiData = JSON.parse(text); } catch (e) { console.error("JSON Parse Error", e); aiData = {}; }

    // 4. Merge Data (API Authority)
    const finalDistance = apiSuccess && realDistanceKm > 0 ? realDistanceKm : (aiData.totalDistanceKm || 0);
    const finalDuration = apiSuccess && realDurationHours > 0 ? realDurationHours : (aiData.totalDurationHours || 0);
    const finalTollCost = apiSuccess ? realTollCost : (aiData.estimatedTollCost || 0);
    const finalTollPlazas = apiSuccess ? detectedTollPlazas : (aiData.tollPlazas || []);

    const safeDistance = finalDistance > 0 ? finalDistance : 100;

    // 5. Calculate Local Costs (Precision Math)
    const consumption = vehicle.fuelConsumption > 0 ? vehicle.fuelConsumption : 1;
    const finalFuelCost = (safeDistance / consumption) * (vehicle.fuelPrice || 0);

    // Maintenance & Fluids Calculation (Prorated per Km)
    // TIRE CALCULATION (Using Global References & Split Mix)
    let tireCostPerKm = 0;
    const priceNew = vehicle.refTirePriceNew || 3500;
    const lifeNew = vehicle.refTireLifespanNew || 100000;
    const priceRemold = vehicle.refTirePriceRemold || 1800;
    const lifeRemold = vehicle.refTireLifespanRemold || 60000;

    const calculateAxleTireCost = (qtyNew: number = 0, qtyRemold: number = 0) => {
        let cost = 0;
        if (lifeNew > 0) cost += (qtyNew * priceNew) / lifeNew;
        if (lifeRemold > 0) cost += (qtyRemold * priceRemold) / lifeRemold;
        return cost;
    };

    tireCostPerKm += calculateAxleTireCost(vehicle.tireSteerQtyNew, vehicle.tireSteerQtyRemold);
    tireCostPerKm += calculateAxleTireCost(vehicle.tireDriveQtyNew, vehicle.tireDriveQtyRemold);
    tireCostPerKm += calculateAxleTireCost(vehicle.tireTrailerQtyNew, vehicle.tireTrailerQtyRemold);

    let fluidAndFilterCostPerKm = 0;
    if (vehicle.lastOilChangeCost && vehicle.oilChangeIntervalKm)
        fluidAndFilterCostPerKm += vehicle.lastOilChangeCost / vehicle.oilChangeIntervalKm;
    if (vehicle.lastTransOilChangeCost && vehicle.transOilChangeIntervalKm)
        fluidAndFilterCostPerKm += vehicle.lastTransOilChangeCost / vehicle.transOilChangeIntervalKm;
    if (vehicle.lastFilterChangeCost && vehicle.filterChangeIntervalKm)
        fluidAndFilterCostPerKm += vehicle.lastFilterChangeCost / vehicle.filterChangeIntervalKm;

    const totalVariableRate = tireCostPerKm + fluidAndFilterCostPerKm;
    const totalVariableCost = safeDistance * totalVariableRate;

    // Fixed Costs Prorated (Daily)
    const drivingHoursPerDay = vehicle.drivingHoursPerDay || 9; 
    const estimatedDays = Math.max(1, Math.ceil(finalDuration / drivingHoursPerDay));
    
    // Depreciation
    const depreciationRate = (vehicle.annualDepreciationRate || 15) / 100;
    const yearlyDepreciation = (vehicle.assetValue || 0) * depreciationRate;
    
    // Salary with 13th Provision
    let annualSalary = (vehicle.driverSalaryMonthly || 0) * 12;
    if (vehicle.driverSalaryInclude13th) {
        annualSalary += (vehicle.driverSalaryMonthly || 0);
    }
    
    const yearlyFixed = 
        (vehicle.insuranceYearly || 0) + 
        (vehicle.registrationYearly || 0) + 
        yearlyDepreciation + 
        annualSalary;
    
    const dailyFixedCost = yearlyFixed / 365;
    const totalFixedCostForTrip = dailyFixedCost * estimatedDays;

    const commissionCost = totalFreightValue * ((vehicle.driverCommissionPercentage || 0) / 100);

    const totalCost = finalFuelCost + finalTollCost + commissionCost + totalVariableCost + totalFixedCostForTrip;
    const netProfit = totalFreightValue - totalCost;

    let viabilityScore: 'high' | 'medium' | 'low' = aiData.viabilityScore || 'medium';
    if (netProfit < 0) viabilityScore = 'low';
    else if ((netProfit / totalFreightValue) > 0.30) viabilityScore = 'high';

    // Extract Grounding
    const groundingUrls: Array<{ title: string; uri: string }> = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
      chunks.forEach((chunk: any) => {
        if (chunk.web?.uri) groundingUrls.push({ title: chunk.web.title || 'Fonte', uri: chunk.web.uri });
        if (chunk.maps?.uri) groundingUrls.push({ title: chunk.maps.title || 'Google Maps', uri: chunk.maps.uri });
      });
    }

    const result: SimulationResult = {
      totalDistanceKm: parseFloat(finalDistance.toFixed(1)),
      totalDurationHours: parseFloat(finalDuration.toFixed(1)),
      totalDurationDays: estimatedDays,
      estimatedFuelCost: parseFloat(finalFuelCost.toFixed(2)),
      estimatedTollCost: parseFloat(finalTollCost.toFixed(2)),
      driverCommissionCost: parseFloat(commissionCost.toFixed(2)),
      // Split Maintenance (Variable) vs Fixed
      estimatedMaintenanceCost: parseFloat(totalVariableCost.toFixed(2)), 
      estimatedFixedCost: parseFloat(totalFixedCostForTrip.toFixed(2)), 
      tollPlazas: finalTollPlazas,
      totalFreightIncome: totalFreightValue,
      netProfit: parseFloat(netProfit.toFixed(2)),
      viabilityScore: viabilityScore,
      viabilityMessage: aiData.viabilityMessage || (netProfit > 0 ? "Lucro projetado positivo." : "Prejuízo estimado. Revise os custos."),
      routeSuggestions: aiData.routeSuggestions || "Rota calculada com dados reais.",
      groundingUrls
    };

    ROUTE_CACHE.set(cacheKey, result);
    return result;

  } catch (error) {
    console.error("Analysis Error:", error);
    throw error;
  }
};

// --- FLEET INTELLIGENCE ANALYSIS ---
export const analyzeFleetIntelligence = async (
    financials: FinancialRecord[],
    vehicles: SavedVehicle[],
    employees: Employee[]
): Promise<string> => {
    
    // Summarize Data for AI Context (Avoid Token Overflow)
    const totalIncome = financials.filter(f => f.type === 'INCOME').reduce((sum, f) => sum + f.amount, 0);
    const totalExpense = financials.filter(f => f.type === 'EXPENSE').reduce((sum, f) => sum + f.amount, 0);
    const balance = totalIncome - totalExpense;
    
    const categories = financials.reduce((acc, curr) => {
        acc[curr.category] = (acc[curr.category] || 0) + curr.amount;
        return acc;
    }, {} as Record<string, number>);

    const prompt = `
        Atue como um CFO (Diretor Financeiro) especializado em Logística e Transportes.
        Analise os dados reais da transportadora abaixo e gere um relatório estratégico curto em Markdown.

        DADOS FINANCEIROS:
        - Receita Total: R$ ${totalIncome.toFixed(2)}
        - Despesa Total: R$ ${totalExpense.toFixed(2)}
        - Saldo Líquido: R$ ${balance.toFixed(2)}
        
        GASTOS POR CATEGORIA:
        ${Object.entries(categories).map(([cat, val]) => `- ${cat}: R$ ${val.toFixed(2)}`).join('\n')}

        FROTA:
        - Total Veículos: ${vehicles.length}
        
        RH:
        - Total Funcionários: ${employees.length}

        TAREFA:
        1. Analise a Saúde Financeira (Margem, Pontos Críticos).
        2. Dê 3 sugestões práticas para reduzir custos baseadas nas categorias de maior gasto.
        3. Identifique riscos (ex: saldo negativo, custo de manutenção alto).
        4. Use emojis para facilitar a leitura.
        5. Seja direto e profissional.
    `;

    try {
        const ai = await getGenAI();
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt
        });
        return response.text || "Não foi possível gerar a análise no momento.";
    } catch (error: any) {
        console.error("Fleet AI Error:", error);
        return "Erro ao conectar com a Inteligência Artificial. Verifique sua chave de API ou conexão.";
    }
};
