
import { User, VehicleData, SavedVehicle, MaintenanceLog } from '../types';
import { supabase } from './supabaseClient';

const USER_STORAGE_KEY = 'fretecerto_user_session';

// --- AUTHENTICATION ---

export const signInUser = async (email: string, password: string, rememberMe = true): Promise<User> => {
    const { data, error } = await supabase.auth.signInWithPassword({
        email: email,
        password: password,
    });

    if (error) throw new Error(error.message === 'Invalid login credentials' ? 'Senha incorreta ou usuário não encontrado.' : error.message);
    if (!data.user) throw new Error('Erro ao autenticar.');

    // Buscar perfil completo
    const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', data.user.id)
        .single();

    if (profile?.is_blocked) {
        await supabase.auth.signOut();
        throw new Error('Conta bloqueada pelo administrador.');
    }

    const user: User = {
        email: email,
        isAuthenticated: true,
        isAdmin: profile?.is_admin || false,
        isRoot: profile?.is_root || false,
        isFleetManager: profile?.is_fleet_manager || false
    };

    // Salvar sessão local para persistência rápida na UI
    const sessionData = { ...user, id: data.user.id };
    if (rememberMe) {
        localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(sessionData));
    } else {
        sessionStorage.setItem(USER_STORAGE_KEY, JSON.stringify(sessionData));
    }

    return user;
};

export const signUpUser = async (email: string, password: string, role: 'driver' | 'fleet' = 'driver', rememberMe = true): Promise<User> => {
    // Metadata helps the Trigger create the profile correctly
    const { data, error } = await supabase.auth.signUp({
        email: email,
        password: password,
        options: {
            data: {
                full_name: '', // Will be updated later
                role: role
            }
        }
    });

    if (error) throw new Error(error.message);
    if (!data.user) throw new Error('Erro ao criar conta.');

    // Check profile created by trigger
    const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', data.user.id)
        .single();

    const user: User = {
        email: email,
        isAuthenticated: true,
        isAdmin: profile?.is_admin || false,
        isRoot: profile?.is_root || false,
        isFleetManager: profile?.is_fleet_manager || false
    };

    if (rememberMe) {
        localStorage.setItem(USER_STORAGE_KEY, JSON.stringify({ ...user, id: data.user.id }));
    }

    return user;
};

export const getStoredUser = (): (User & { id?: string }) | null => {
  try {
      const stored = localStorage.getItem(USER_STORAGE_KEY) || sessionStorage.getItem(USER_STORAGE_KEY);
      return stored ? JSON.parse(stored) : null;
  } catch {
      return null;
  }
};

export const logoutUser = async () => {
  await supabase.auth.signOut();
  localStorage.removeItem(USER_STORAGE_KEY);
  sessionStorage.removeItem(USER_STORAGE_KEY);
};

export const resetPasswordRequest = async (email: string) => {
    const { error } = await supabase.auth.resetPasswordForEmail(email);
    if (error) throw error;
};

// --- PREFERENCES & VEHICLES (REMOTE DB) ---

export const saveUserPreferences = async (email: string, data: VehicleData) => {
    // Cache local rápido
    localStorage.setItem(`fretecerto_prefs_${email}`, JSON.stringify(data));
};

export const getUserPreferences = async (email: string): Promise<VehicleData | null> => {
    const local = localStorage.getItem(`fretecerto_prefs_${email}`);
    return local ? JSON.parse(local) : null;
};

export const getUserVehicles = async (): Promise<SavedVehicle[]> => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data, error } = await supabase
        .from('vehicles')
        .select('*')
        .eq('user_id', user.id);
    
    if (error) console.error("Error fetching vehicles:", error);
    return data || [];
};

export const saveNewVehicle = async (vehicle: VehicleData): Promise<{ success: boolean; mode: 'cloud' | 'local' }> => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('AUTH_REQUIRED');

    // Mapear VehicleData para Colunas do DB (snake_case)
    const payload = {
        user_id: user.id,
        license_plate: vehicle.licensePlate?.toUpperCase(),
        model_name: `${vehicle.axles} Eixos - ${vehicle.cargoCapacity}T`,
        axles: vehicle.axles,
        fuel_consumption: vehicle.fuelConsumption,
        fuel_price: vehicle.fuelPrice,
        cargo_capacity: vehicle.cargoCapacity,
        maintenance_cost_per_km: vehicle.maintenanceCostPerKm,
        
        // Pneus
        ref_tire_price_new: vehicle.refTirePriceNew,
        ref_tire_lifespan_new: vehicle.refTireLifespanNew,
        ref_tire_price_remold: vehicle.refTirePriceRemold,
        ref_tire_lifespan_remold: vehicle.refTireLifespanRemold,
        tire_steer_qty_new: vehicle.tireSteerQtyNew,
        tire_steer_qty_remold: vehicle.tireSteerQtyRemold,
        tire_drive_qty_new: vehicle.tireDriveQtyNew,
        tire_drive_qty_remold: vehicle.tireDriveQtyRemold,
        tire_trailer_qty_new: vehicle.tireTrailerQtyNew,
        tire_trailer_qty_remold: vehicle.tireTrailerQtyRemold,

        // Óleo e Manutenção
        last_oil_change_km: vehicle.lastOilChangeKm,
        last_oil_change_date: vehicle.lastOilChangeDate,
        last_oil_change_cost: vehicle.lastOilChangeCost,
        last_oil_change_location: vehicle.lastOilChangeLocation,
        oil_change_interval_km: vehicle.oilChangeIntervalKm,

        last_trans_oil_change_km: vehicle.lastTransOilChangeKm,
        last_trans_oil_change_date: vehicle.lastTransOilChangeDate,
        last_trans_oil_change_cost: vehicle.lastTransOilChangeCost,
        trans_oil_change_interval_km: vehicle.transOilChangeIntervalKm,

        last_filter_change_km: vehicle.lastFilterChangeKm,
        last_filter_change_date: vehicle.lastFilterChangeDate,
        last_filter_change_cost: vehicle.lastFilterChangeCost,
        filter_change_interval_km: vehicle.filterChangeIntervalKm,

        current_odometer: vehicle.currentOdometer,

        // Custos Fixos
        driver_salary_monthly: vehicle.driverSalaryMonthly,
        driver_salary_include_13th: vehicle.driverSalaryInclude13th,
        driver_commission_percentage: vehicle.driverCommissionPercentage,
        asset_value: vehicle.assetValue,
        annual_depreciation_rate: vehicle.annualDepreciationRate,
        insurance_yearly: vehicle.insuranceYearly,
        registration_yearly: vehicle.registrationYearly
    };

    const { data: existing } = await supabase.from('vehicles').select('id').eq('license_plate', payload.license_plate).eq('user_id', user.id).maybeSingle();

    let error;
    if (existing) {
        const { error: err } = await supabase.from('vehicles').update(payload).eq('id', existing.id);
        error = err;
    } else {
        const { error: err } = await supabase.from('vehicles').insert(payload);
        error = err;
    }

    if (error) {
        console.error("Save Vehicle Error:", error);
        return { success: false, mode: 'cloud' };
    }
    return { success: true, mode: 'cloud' };
};

export const addMaintenanceLog = async (log: Omit<MaintenanceLog, 'id'>): Promise<{ success: boolean; mode: 'cloud' | 'local' }> => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('AUTH_REQUIRED');

    const { error } = await supabase.from('maintenance_logs').insert({
        user_id: user.id,
        ...log
    });

    if (error) throw error;
    return { success: true, mode: 'cloud' };
};

export const getMaintenanceHistory = async (licensePlate: string): Promise<MaintenanceLog[]> => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data } = await supabase
        .from('maintenance_logs')
        .select('*')
        .eq('user_id', user.id)
        .eq('license_plate', licensePlate)
        .order('service_date', { ascending: false });
        
    return data || [];
};
