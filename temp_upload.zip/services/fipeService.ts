
// Service to interact with FIPE Table data
// We use Parallelum API as it provides reliable Brand -> Model -> Year navigation
// Docs: https://deividfortuna.github.io/fipe/

export interface FipeBrand {
  nome: string;
  codigo: string;
}

export interface FipeModel {
  nome: string;
  codigo: string;
}

export interface FipeYear {
  nome: string;
  codigo: string;
}

export interface FipeResult {
  valor: string; // "R$ 100.000,00"
  marca: string;
  modelo: string;
  anoModelo: number;
  combustivel: string;
  codigoFipe: string;
  mesReferencia: string;
  tipoVeiculo: number;
  siglaCombustivel: string;
}

const BASE_URL = 'https://parallelum.com.br/fipe/api/v1';

// Type 'caminhoes' is standard for this API
const DEFAULT_TYPE = 'caminhoes'; 

export const getFipeBrands = async (): Promise<FipeBrand[]> => {
  try {
    const response = await fetch(`${BASE_URL}/${DEFAULT_TYPE}/marcas`);
    if (!response.ok) throw new Error('Erro ao buscar marcas');
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const getFipeModels = async (brandCode: string): Promise<FipeModel[]> => {
  try {
    const response = await fetch(`${BASE_URL}/${DEFAULT_TYPE}/marcas/${brandCode}/modelos`);
    if (!response.ok) throw new Error('Erro ao buscar modelos');
    const data = await response.json();
    
    // Parallelum API returns an object { modelos: [], anos: [] }
    // We only need 'modelos' here
    return data.modelos || [];
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const getFipeYears = async (brandCode: string, modelCode: string): Promise<FipeYear[]> => {
  try {
    const response = await fetch(`${BASE_URL}/${DEFAULT_TYPE}/marcas/${brandCode}/modelos/${modelCode}/anos`);
    if (!response.ok) throw new Error('Erro ao buscar anos');
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const getFipePrice = async (brandCode: string, modelCode: string, yearCode: string): Promise<FipeResult | null> => {
  try {
    const response = await fetch(`${BASE_URL}/${DEFAULT_TYPE}/marcas/${brandCode}/modelos/${modelCode}/anos/${yearCode}`);
    if (!response.ok) throw new Error('Erro ao buscar preço');
    const data = await response.json();
    
    // Map Parallelum (TitleCase) to our Interface (camelCase)
    return {
        valor: data.Valor,
        marca: data.Marca,
        modelo: data.Modelo,
        anoModelo: data.AnoModelo,
        combustivel: data.Combustivel,
        codigoFipe: data.CodigoFipe,
        mesReferencia: data.MesReferencia,
        tipoVeiculo: data.TipoVeiculo,
        siglaCombustivel: data.SiglaCombustivel
    };
  } catch (error) {
    console.error(error);
    return null;
  }
};

export const parseFipeValue = (valueStr: string): number => {
  // Converts "R$ 450.200,00" to 450200.00
  if (!valueStr) return 0;
  const clean = valueStr.replace('R$', '').replace(/\./g, '').replace(',', '.').trim();
  return parseFloat(clean);
};
