
import { VehicleData } from '../types';

// Interface padronizada para resposta de telemetria
export interface TelemetryResponse {
    odometer: number;
    fuelLevelPercent: number;
    location?: { lat: number, lng: number };
    engineHours?: number;
    lastSync: string;
    status: 'success' | 'error' | 'offline';
}

/**
 * Serviço de Integração de Telemetria
 * 
 * Este serviço atua como uma camada de abstração (Adapter Pattern).
 * No futuro, aqui serão feitas as chamadas reais para:
 * - Scania Fleet Management API
 * - Volvo Dynafleet API
 * - Mercedes Fleetboard API
 * - APIs de Rastreadores (Sascar, Omnilink, etc)
 */

export const syncVehicleTelemetry = async (
    provider: string, 
    deviceId: string
): Promise<TelemetryResponse> => {
    
    console.log(`Iniciando sincronização com provedor: ${provider} para dispositivo: ${deviceId}`);

    // SIMULAÇÃO DE CHAMADA DE API (MOCK)
    // Em produção, aqui entraria um fetch('https://api.scania.com/fleet/v1/vehicles/...')
    
    return new Promise((resolve) => {
        setTimeout(() => {
            // Simulando um hodômetro levemente maior que o esperado para demonstrar atualização
            // Num cenário real, isso viria do JSON da API da montadora
            const randomOdometer = 150000 + Math.floor(Math.random() * 5000);
            
            resolve({
                odometer: randomOdometer,
                fuelLevelPercent: 78, // 78% do tanque
                lastSync: new Date().toISOString(),
                status: 'success'
            });
        }, 2000); // Delay de 2s para simular rede
    });
};

export const getAvailableProviders = () => [
    { id: 'scania', name: 'Scania Fleet' },
    { id: 'volvo', name: 'Volvo Dynafleet' },
    { id: 'mercedes', name: 'Mercedes Fleetboard' },
    { id: 'omnilink', name: 'Omnilink / Sascar' },
    { id: 'manual', name: 'Manual (Sem integração)' }
];
