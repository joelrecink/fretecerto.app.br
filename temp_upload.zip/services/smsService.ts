
import { getSystemConfig } from "./dbService";

// Lista de Proxies para contornar CORS (mesma estratégia usada em pagamentos)
const CORS_PROXIES = [
    "https://corsproxy.io/?",
    "https://thingproxy.freeboard.io/fetch/"
];

const fetchWithProxy = async (url: string, options: RequestInit) => {
    let lastError;
    for (const proxy of CORS_PROXIES) {
        try {
            // Encode the target URL to safely pass it as a query parameter
            const proxiedUrl = proxy + encodeURIComponent(url);
            const res = await fetch(proxiedUrl, options);
            if (res) return res;
        } catch (e) {
            lastError = e;
        }
    }
    throw lastError || new Error("Falha de conexão (Proxy)");
};

export const validateTwilioCredentials = async (sid: string, token: string) => {
    if (!sid || !token) return { success: false, message: "SID ou Token ausentes." };
    
    try {
        // Endpoint de teste: Consultar dados da conta
        // Twilio usa Basic Auth com SID:Token
        const url = `https://api.twilio.com/2010-04-01/Accounts/${sid}.json`;
        const auth = btoa(`${sid}:${token}`);
        
        const response = await fetchWithProxy(url, {
            method: 'GET',
            headers: {
                'Authorization': `Basic ${auth}`,
                'Accept': 'application/json'
            }
        });

        if (response.ok) {
            const data = await response.json();
            return { 
                success: true, 
                message: `✅ Sucesso! Conta Twilio: ${data.friendly_name || 'Ativa'} (${data.status})` 
            };
        } else {
            return { success: false, message: `⛔ Erro Twilio: ${response.statusText || 'Credenciais Inválidas'}` };
        }
    } catch (error: any) {
        return { success: false, message: `Erro de conexão: ${error.message}` };
    }
};

export const validateMessageBirdCredentials = async (key: string) => {
    if (!key) return { success: false, message: "Chave ausente." };

    try {
        // Endpoint de teste: Saldo
        const url = `https://rest.messagebird.com/balance`;
        
        const response = await fetchWithProxy(url, {
            method: 'GET',
            headers: {
                'Authorization': `AccessKey ${key}`,
                'Accept': 'application/json'
            }
        });

        if (response.ok) {
            const data = await response.json();
            return { 
                success: true, 
                message: `✅ Sucesso! MessageBird Ativo. Tipo: ${data.type}, Saldo: ${data.amount}` 
            };
        } else {
            return { success: false, message: "⛔ Chave inválida ou erro de acesso." };
        }
    } catch (error: any) {
        return { success: false, message: `Erro de conexão: ${error.message}` };
    }
};

// --- REAL SEND FUNCTION ---
export const sendSms = async (to: string, body: string): Promise<{ success: boolean; message: string }> => {
    try {
        const config = await getSystemConfig();
        const provider = config.sms_provider || 'TWILIO';

        // Clean phone number (Ensure E.164 format +55...)
        const cleanPhone = to.replace(/\D/g, '');
        const formattedPhone = cleanPhone.length <= 11 ? `+55${cleanPhone}` : `+${cleanPhone}`;

        if (provider === 'TWILIO') {
            const sid = config.twilio_sid;
            const token = config.twilio_token;
            const from = config.twilio_phone;

            if (!sid || !token || !from) throw new Error("Configuração Twilio incompleta no Painel Root.");

            const url = `https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`;
            const auth = btoa(`${sid}:${token}`);
            
            // Twilio expects form-urlencoded
            const formData = new URLSearchParams();
            formData.append('To', formattedPhone);
            formData.append('From', from);
            formData.append('Body', body);

            const response = await fetchWithProxy(url, {
                method: 'POST',
                headers: {
                    'Authorization': `Basic ${auth}`,
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: formData.toString()
            });

            if (response.ok) {
                return { success: true, message: "SMS Enviado." };
            } else {
                const errText = await response.text();
                console.error("Twilio Error:", errText);
                throw new Error(`Erro Twilio: ${response.status}`);
            }
        } 
        
        // Placeholder for MessageBird or others
        return { success: false, message: "Provedor não suportado." };

    } catch (error: any) {
        console.error("Send SMS Error:", error);
        return { success: false, message: error.message || "Erro ao enviar SMS." };
    }
};
