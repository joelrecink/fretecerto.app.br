import { createClient } from '@supabase/supabase-js';

// Robust environment variable access for Vite
const getEnv = (key: string) => {
    // Check import.meta.env (Vite standard)
    if (typeof import.meta !== 'undefined' && (import.meta as any).env && (import.meta as any).env[key]) {
        return (import.meta as any).env[key];
    }
    // Check process.env (Fallback)
    if (typeof process !== 'undefined' && process.env && process.env[key]) {
        return process.env[key];
    }
    return '';
};

const supabaseUrl = getEnv('VITE_SUPABASE_URL');
const supabaseAnonKey = getEnv('VITE_SUPABASE_ANON_KEY');

const isConfigured = 
    supabaseUrl && 
    supabaseAnonKey && 
    !supabaseUrl.includes('placeholder') &&
    supabaseUrl.startsWith('http');

if (!isConfigured) {
    console.warn("⚠️ Supabase Credentials Missing in .env! Application will default to Offline/Mock mode where possible or fail on DB requests.");
}

export const supabase = createClient(
    isConfigured ? supabaseUrl : 'https://placeholder.supabase.co', 
    isConfigured ? supabaseAnonKey : 'placeholder'
);

export const isSupabaseConfigured = () => !!isConfigured;