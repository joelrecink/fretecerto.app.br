import React, { Component, useState, useEffect, ErrorInfo, ReactNode } from 'react';
import LoginScreen from './components/LoginScreen';
import DriverSetup from './components/DriverSetup';
import VehicleSetup from './components/VehicleSetup';
import VehicleCosts from './components/VehicleCosts';
import RoutePlanner from './components/RoutePlanner';
import ReviewScreen from './components/ReviewScreen';
import Dashboard from './components/Dashboard';
import AdminDashboard from './components/AdminDashboard';
import RootDashboard from './components/RootDashboard';
import FleetDashboard from './components/FleetDashboard';
import CreditDisplay from './components/CreditDisplay';
import PurchaseModal from './components/PurchaseModal';
import SecurityModal from './components/SecurityModal';
import { VehicleData, RouteData, AppState, User, SimulationResult } from './types';
import { DEFAULT_VEHICLE, DEFAULT_ROUTE } from './constants';
import { analyzeRouteViability } from './services/geminiService';
import { getStoredCredits, hasCredit, consumeCredit, addPremiumCredits } from './services/creditService';
import { getStoredUser, logoutUser, getUserPreferences, saveUserPreferences } from './services/authService';
import { addFinancialRecord } from './services/dbService';
import { isSupabaseConfigured } from './services/supabaseClient';
import { LogOut, User as UserIcon, Shield, AlertTriangle, RefreshCw, Briefcase, Lock, Terminal } from 'lucide-react';

interface ErrorBoundaryProps {
  children?: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

// --- ROBUST ERROR BOUNDARY ---
class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  public state: ErrorBoundaryState = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("App Crash:", error, errorInfo);
  }

  public handleReset = () => {
    this.setState({ hasError: false, error: null });
    logoutUser(); 
    window.location.reload();
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-red-50 p-6 text-center font-sans">
          <div className="bg-white p-8 rounded-3xl shadow-xl max-w-md w-full border border-red-100">
            <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertTriangle size={32} />
            </div>
            <h1 className="text-2xl font-bold text-slate-900 mb-2">Ops! Algo deu errado.</h1>
            <p className="text-slate-500 mb-6 text-sm">
              O aplicativo encontrou um erro inesperado.
            </p>
            <div className="bg-slate-100 p-3 rounded-lg text-xs text-slate-600 font-mono mb-6 text-left overflow-auto max-h-32 border border-slate-200">
                {this.state.error?.message || "Erro desconhecido"}
            </div>
            <button
              onClick={this.handleReset}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <RefreshCw size={20} /> Reiniciar App
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const AppContent: React.FC = () => {
  const [state, setState] = useState<AppState>({
    step: 'driver', 
    user: null,
    vehicle: DEFAULT_VEHICLE,
    route: DEFAULT_ROUTE,
    result: null,
    loading: false,
    credits: { freeCredits: 0, premiumCredits: 0, lastResetDate: '' },
    showPurchaseModal: false
  });
  
  const [showSecurityModal, setShowSecurityModal] = useState(false);
  const [dbConfigured, setDbConfigured] = useState(true);

  useEffect(() => {
    const init = async () => {
        // Verifica configuração do DB
        setDbConfigured(isSupabaseConfigured());

        try {
            const user = getStoredUser();
            if (user && user.isAuthenticated) {
                if (user.isRoot) {
                     setState(prev => ({ ...prev, user, step: 'root' }));
                     return;
                }
                if (user.isAdmin) {
                     setState(prev => ({ ...prev, user, step: 'admin' }));
                     return;
                }
                
                const initialStep: AppState['step'] = 'driver';
                
                const credits = await getStoredCredits(user.email);
                const prefs = await getUserPreferences(user.email);
                
                setState(prev => ({ 
                    ...prev, 
                    user, 
                    credits, 
                    vehicle: prefs ? {...DEFAULT_VEHICLE, ...prefs} : prev.vehicle,
                    step: initialStep
                }));
            }
        } catch (e) { 
            console.error("Init error:", e); 
        }
    };
    init();
  }, []);

  const handleLoginSuccess = async (user: User) => {
    if (user.isRoot) {
         setState(prev => ({ ...prev, user, step: 'root' }));
         return;
    }
    if (user.isAdmin) {
         setState(prev => ({ ...prev, user, step: 'admin' }));
         return;
    }
    
    try {
        const credits = await getStoredCredits(user.email);
        const prefs = await getUserPreferences(user.email);
        
        const nextStep: AppState['step'] = state.previousStep || 'driver';
        
        setState(prev => ({ 
            ...prev, user, credits, 
            vehicle: prefs ? {...DEFAULT_VEHICLE, ...prefs} : state.vehicle,
            step: nextStep
        }));
    } catch (e) {
        console.error("Login data load error", e);
        setState(prev => ({ 
            ...prev, 
            user, 
            step: prev.previousStep || 'driver' 
        }));
    }
  };

  const handleLogout = async () => {
      await logoutUser(); 
      setState({
        step: 'driver',
        user: null,
        vehicle: DEFAULT_VEHICLE,
        route: DEFAULT_ROUTE,
        result: null,
        loading: false,
        credits: { freeCredits: 0, premiumCredits: 0, lastResetDate: '' },
        showPurchaseModal: false
      });
  };

  const handleSaveOnly = async () => {
      if (!state.user) return setState(prev => ({ ...prev, step: 'login', previousStep: 'review' }));

      try {
          setState(prev => ({ ...prev, loading: true }));
          
          const totalFreight = [...state.route.pickups, ...state.route.deliveries].reduce((acc, c) => acc + (c.value || 0), 0);
          const desc = `Frete (Simples): ${state.route.pickups[0].address.split(',')[0]} -> ${state.route.deliveries[0].address.split(',')[0]}`;
          
          await addFinancialRecord({
              type: 'INCOME',
              category: 'FREIGHT',
              amount: totalFreight,
              description: desc,
              date: new Date().toISOString().split('T')[0],
              status: 'pending',
              vehicle_plate: state.vehicle.licensePlate || 'NÃO INFORMADO'
          });

          setState(prev => ({ ...prev, loading: false }));
          alert("Viagem registrada no histórico!");

      } catch (e) {
          console.error(e);
          setState(prev => ({ ...prev, loading: false }));
      }
  };

  const handleAnalyzeClick = async () => {
      if (!state.user) return setState(prev => ({ ...prev, step: 'login', previousStep: 'review' }));
      
      try {
          const credits = await getStoredCredits(state.user.email);
          if (!hasCredit(credits)) return setState(prev => ({ ...prev, showPurchaseModal: true }));
          
          setState(prev => ({ ...prev, loading: true }));
          
          await saveUserPreferences(state.user.email, state.vehicle);
          const res = await analyzeRouteViability(state.vehicle, state.route);
          const newCredits = await consumeCredit(credits, state.user.email);
          
          setState(prev => ({ ...prev, result: res, step: 'dashboard', loading: false, credits: newCredits }));
      } catch (e: any) {
          console.error(e);
          alert(`Erro na análise: ${e.message || 'Verifique sua conexão.'}`);
          setState(prev => ({ ...prev, loading: false }));
      }
  };

  if (state.step === 'login') {
      return <LoginScreen onLoginSuccess={handleLoginSuccess} onCancel={() => setState(prev => ({ ...prev, step: prev.previousStep || 'driver' }))} />;
  }
  
  if (state.step === 'root') {
      return <RootDashboard 
          onLogout={handleLogout} 
          onTestSystem={() => setState(prev => ({ ...prev, step: 'driver' }))}
      />;
  }

  if (state.step === 'admin') {
      return (
        <AdminDashboard 
            onLogout={handleLogout} 
            onOpenFleet={() => {
                alert("Módulo ERP desativado nesta versão.");
            }}
            onTestCalculator={() => {
                setState(prev => ({ ...prev, step: 'driver' }))
            }}
        />
      );
  }

  if (state.step === 'fleet_dashboard') {
      return <FleetDashboard onBack={() => setState(prev => ({ ...prev, step: prev.previousStep || 'driver' }))} />;
  }

  const getUserDisplay = () => {
      if (!state.user) return '';
      if (state.vehicle.driverName) return state.vehicle.driverName.split(' ')[0];
      return state.user.email;
  };

  return (
    <div className="min-h-screen bg-gray-100 font-sans text-gray-900">
      
      {/* DB NOT CONFIGURED WARNING BANNER */}
      {!dbConfigured && (
        <div className="bg-red-600 text-white px-4 py-3 shadow-md fixed top-0 left-0 right-0 z-50 flex items-center justify-center gap-3">
            <Terminal size={20} className="animate-pulse" />
            <div className="text-sm font-bold">
                Configuração Pendente: Reinicie o terminal (Ctrl+C, depois npm run dev) para carregar as chaves do .env
            </div>
        </div>
      )}

      <PurchaseModal 
        isOpen={state.showPurchaseModal} 
        onClose={() => setState(prev => ({ ...prev, showPurchaseModal: false }))}
        onPurchase={async (amount) => {
            const newCredits = await addPremiumCredits(amount, state.user?.email);
            setState(prev => ({ ...prev, credits: newCredits }));
        }}
      />
      
      <SecurityModal 
        isOpen={showSecurityModal}
        onClose={() => setShowSecurityModal(false)}
      />

      <header className={`bg-white shadow-sm sticky z-40 ${!dbConfigured ? 'top-12' : 'top-0'}`}>
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 shrink-0">
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight hidden md:block">
                Frete<span className="text-blue-600">Certo</span>
            </h1>
          </div>
          
          <div className="flex items-center gap-2 md:gap-4">
             {state.user ? (
                 <>
                    <CreditDisplay 
                        credits={state.credits} 
                        onBuyClick={() => setState(prev => ({ ...prev, showPurchaseModal: true }))}
                    />
                    <div className="hidden md:flex items-center gap-2 text-slate-600 font-medium bg-slate-50 px-3 py-1.5 rounded-full border border-slate-200">
                        <UserIcon size={14} className="text-blue-500"/>
                        <span className="text-sm truncate max-w-[100px]">{getUserDisplay()}</span>
                    </div>
                    {state.user.isRoot && (
                        <div className="flex items-center gap-1 bg-red-600 text-white px-2 py-1 rounded-full text-[10px] font-bold">ROOT</div>
                    )}
                    
                    {state.user.isRoot && (
                        <button 
                            onClick={() => setState(prev => ({...prev, step: 'root'}))}
                            className="bg-red-100 text-red-700 px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-red-200 transition-colors"
                        >
                            Voltar Root
                        </button>
                    )}

                    {state.user.isAdmin && !state.user.isRoot && (
                        <button 
                            onClick={() => setState(prev => ({...prev, step: 'admin'}))}
                            className="bg-purple-100 text-purple-700 px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-purple-200 transition-colors"
                        >
                            Voltar Admin
                        </button>
                    )}
                    
                    <button 
                        onClick={() => setShowSecurityModal(true)} 
                        className="text-slate-400 hover:text-blue-600 p-2 rounded-lg transition-colors"
                        title="Segurança"
                    >
                        <Lock size={20} />
                    </button>

                    <button 
                        onClick={handleLogout} 
                        className="text-slate-400 hover:text-red-500 p-2 rounded-lg transition-colors"
                        title="Sair"
                    >
                        <LogOut size={20} />
                    </button>
                 </>
             ) : (
                 <button 
                    onClick={() => setState(prev => ({ ...prev, step: 'login', previousStep: state.step as any }))}
                    className="text-blue-600 font-bold text-sm bg-blue-50 hover:bg-blue-100 px-4 py-2 rounded-lg transition-colors"
                 >
                    Entrar / Cadastrar
                 </button>
             )}
          </div>
        </div>
      </header>

      <main className={`p-4 md:p-6 max-w-5xl mx-auto ${!dbConfigured ? 'mt-8' : ''}`}>
        {state.step === 'driver' && (
            <DriverSetup 
                data={state.vehicle} 
                onUpdate={(v) => setState(prev => ({ ...prev, vehicle: v }))} 
                onNext={() => setState(prev => ({ ...prev, step: 'costs' }))} 
                onLogin={() => setState(prev => ({ ...prev, step: 'login', previousStep: 'driver' }))}
            />
        )}

        {state.step === 'costs' && (
            <VehicleCosts
                data={state.vehicle}
                onUpdate={(v) => setState(prev => ({ ...prev, vehicle: v }))}
                onNext={() => setState(prev => ({ ...prev, step: 'vehicle' }))}
                onBack={() => setState(prev => ({ ...prev, step: 'driver' }))}
                onLogin={() => setState(prev => ({ ...prev, step: 'login', previousStep: 'costs' }))}
            />
        )}

        {state.step === 'vehicle' && (
            <VehicleSetup 
                data={state.vehicle} 
                onUpdate={(v) => setState(prev => ({ ...prev, vehicle: v }))} 
                onNext={() => setState(prev => ({ ...prev, step: 'pickup' }))} 
                onBack={() => setState(prev => ({ ...prev, step: 'costs' }))} 
                onLogin={() => setState(prev => ({ ...prev, step: 'login', previousStep: 'vehicle' }))}
            />
        )}

        {state.step === 'pickup' && (
            <RoutePlanner 
                step="pickup"
                data={state.route} 
                vehicle={state.vehicle}
                onUpdate={(r) => setState(prev => ({ ...prev, route: r }))} 
                onNext={() => setState(prev => ({ ...prev, step: 'delivery' }))} 
                onBack={() => setState(prev => ({ ...prev, step: 'vehicle' }))} 
                onAnalyze={handleAnalyzeClick} 
                isLoading={state.loading}
            />
        )}

        {state.step === 'delivery' && (
            <RoutePlanner 
                step="delivery"
                data={state.route} 
                vehicle={state.vehicle}
                onUpdate={(r) => setState(prev => ({ ...prev, route: r }))} 
                onNext={() => setState(prev => ({ ...prev, step: 'review' }))} 
                onBack={() => setState(prev => ({ ...prev, step: 'pickup' }))} 
                onAnalyze={handleAnalyzeClick} 
                isLoading={state.loading}
            />
        )}

        {state.step === 'review' && (
            <ReviewScreen
                vehicle={state.vehicle}
                route={state.route}
                onEditVehicle={() => setState(prev => ({ ...prev, step: 'vehicle' }))}
                onEditRoute={(step) => setState(prev => ({ ...prev, step }))}
                onAnalyze={handleAnalyzeClick}
                onSaveOnly={handleSaveOnly}
                onBack={() => setState(prev => ({ ...prev, step: 'delivery' }))}
                isLoading={state.loading}
            />
        )}

        {state.step === 'dashboard' && state.result && (
            <Dashboard 
                result={state.result} 
                route={state.route}
                onReset={() => setState(prev => ({ ...prev, step: 'driver', result: null, route: DEFAULT_ROUTE }))} 
                onRecalculate={(newRoute) => setState(prev => ({ ...prev, route: newRoute, step: 'review' }))}
                isRecalculating={state.loading}
            />
        )}
      </main>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <ErrorBoundary>
        <AppContent />
    </ErrorBoundary>
  );
}

export default App;