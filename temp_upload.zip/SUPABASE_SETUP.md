
-- ============================================================================
-- SETUP DO BANCO DE DADOS (SUPABASE)
-- ============================================================================
-- 
-- STATUS:
-- [OK] Arquivo .env configurado com URL e KEY.
-- [PENDENTE] Rodar o script abaixo no Supabase para criar as tabelas.
--
-- ============================================================================
-- INSTRUÇÕES DE USO DESTE SCRIPT:
-- 1. Acesse o painel do seu projeto: https://supabase.com/dashboard/project/dvfpwtzratbnsfjcqibr
-- 2. No menu lateral esquerdo, clique em "SQL Editor" (ícone de terminal >_ ).
-- 3. Clique em "New Query".
-- 4. Copie TODO o código SQL abaixo.
-- 5. Cole no editor e clique no botão "Run" (verde, canto inferior direito).
-- ============================================================================

-- 1. Habilitar extensão para UUIDs (Essencial para gen_random_uuid())
create extension if not exists "pgcrypto";

-- 2. Tabela de Perfis (Vinculada ao Auth do Supabase)
-- ALTERADO: 'phone' removido ou tornado opcional, 'email' adicionado como identificador principal
create table if not exists public.profiles (
  id uuid references auth.users not null primary key,
  email text unique, 
  full_name text,
  role text default 'driver', -- 'driver', 'fleet', 'admin', 'root'
  credits int default 1,
  premium_credits int default 0,
  is_admin boolean default false,
  is_root boolean default false,
  is_fleet_manager boolean default false,
  is_blocked boolean default false,
  last_reset_date_str text,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- 3. Tabela de Veículos
create table if not exists public.vehicles (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) not null,
  license_plate text,
  model_name text,
  axles int,
  fuel_consumption float,
  fuel_price float,
  cargo_capacity float,
  current_odometer float,
  
  -- Pneus (Configuração)
  ref_tire_price_new float,
  ref_tire_lifespan_new float,
  ref_tire_price_remold float,
  ref_tire_lifespan_remold float,
  tire_steer_qty_new int default 0,
  tire_steer_qty_remold int default 0,
  tire_drive_qty_new int default 0,
  tire_drive_qty_remold int default 0,
  tire_trailer_qty_new int default 0,
  tire_trailer_qty_remold int default 0,

  -- Manutenção (Óleos/Filtros)
  last_oil_change_km float,
  last_oil_change_date date,
  last_oil_change_cost float,
  last_oil_change_location text,
  oil_change_interval_km float,
  
  last_trans_oil_change_km float,
  last_trans_oil_change_date date,
  last_trans_oil_change_cost float,
  trans_oil_change_interval_km float,

  last_filter_change_km float,
  last_filter_change_date date,
  last_filter_change_cost float,
  filter_change_interval_km float,

  -- Custos Fixos
  driver_salary_monthly float,
  driver_salary_include_13th boolean,
  driver_commission_percentage float,
  asset_value float,
  annual_depreciation_rate float,
  insurance_yearly float,
  registration_yearly float,
  maintenance_cost_per_km float, 

  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- 4. Histórico de Manutenção
create table if not exists public.maintenance_logs (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) not null,
  license_plate text,
  service_type text, 
  odometer float,
  cost float,
  location text,
  service_date date,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- 5. Registros Financeiros
create table if not exists public.financial_records (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) not null,
  type text, 
  category text, 
  description text,
  amount float,
  date date,
  status text default 'pending',
  vehicle_plate text,
  document_number text,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- 6. Pacotes de Créditos
create table if not exists public.credit_packages (
  id uuid default gen_random_uuid() primary key,
  label text,
  description text,
  price float,
  credits int,
  features text[],
  is_active boolean default true,
  is_recommended boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- 7. Configurações do Sistema
create table if not exists public.system_config (
  key text primary key,
  value text
);

-- 8. Funcionários
create table if not exists public.employees (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) not null,
  name text,
  role text,
  salary float,
  cnh_number text,
  cnh_expiration date,
  status text default 'active',
  admission_date date,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- 9. Transações
create table if not exists public.transactions (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) not null,
  amount float,
  credits int,
  method text,
  status text,
  date timestamp with time zone default timezone('utc'::text, now())
);

-- 10. TRIGGER PARA CRIAR PERFIL AUTOMÁTICO
-- Primeiro removemos para recriar sem erro
drop trigger if exists on_auth_user_created on auth.users;

create or replace function public.handle_new_user()
returns trigger as $$
declare
  is_super_user boolean;
begin
  -- Regra Hardcoded para Super Admin
  if new.email = 'jbbaggio81@gmail.com' then
    is_super_user := true;
  else
    is_super_user := false;
  end if;

  insert into public.profiles (id, email, full_name, role, is_admin, is_root)
  values (
    new.id, 
    new.email,
    new.raw_user_meta_data->>'full_name', 
    coalesce(new.raw_user_meta_data->>'role', 'driver'),
    is_super_user,
    is_super_user
  )
  on conflict (id) do nothing; 
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 11. HABILITAR RLS (Segurança)
alter table profiles enable row level security;
alter table vehicles enable row level security;
alter table maintenance_logs enable row level security;
alter table financial_records enable row level security;
alter table credit_packages enable row level security;

-- 12. POLÍTICAS DE ACESSO (Dropamos antes para evitar duplicidade)

-- Profiles
drop policy if exists "Users can see own profile" on profiles;
drop policy if exists "Users can update own profile" on profiles;

create policy "Users can see own profile" on profiles for select using (auth.uid() = id);
create policy "Users can update own profile" on profiles for update using (auth.uid() = id);

-- Vehicles
drop policy if exists "Users can see own vehicles" on vehicles;
drop policy if exists "Users can insert own vehicles" on vehicles;
drop policy if exists "Users can update own vehicles" on vehicles;

create policy "Users can see own vehicles" on vehicles for select using (auth.uid() = user_id);
create policy "Users can insert own vehicles" on vehicles for insert with check (auth.uid() = user_id);
create policy "Users can update own vehicles" on vehicles for update using (auth.uid() = user_id);

-- Maintenance Logs
drop policy if exists "Users can see own logs" on maintenance_logs;
drop policy if exists "Users can insert own logs" on maintenance_logs;

create policy "Users can see own logs" on maintenance_logs for select using (auth.uid() = user_id);
create policy "Users can insert own logs" on maintenance_logs for insert with check (auth.uid() = user_id);

-- Financial Records
drop policy if exists "Users can see own finance" on financial_records;
drop policy if exists "Users can insert own finance" on financial_records;
drop policy if exists "Users can update own finance" on financial_records;

create policy "Users can see own finance" on financial_records for select using (auth.uid() = user_id);
create policy "Users can insert own finance" on financial_records for insert with check (auth.uid() = user_id);
create policy "Users can update own finance" on financial_records for update using (auth.uid() = user_id);

-- Public Packages
drop policy if exists "Public read packages" on credit_packages;
create policy "Public read packages" on credit_packages for select using (true);
