const { Pool } = require('pg');
require('dotenv').config();

// Configuração para conectar ao banco na MESMA máquina (localhost da VPS)
const pool = new Pool({
  user: process.env.DB_USER || 'jbbaggio81',
  host: process.env.DB_HOST || 'localhost',
  database: process.env.DB_NAME || 'fretecerto_db',
  password: process.env.DB_PASSWORD || 'Rec4545@#/Fre',
  port: process.env.DB_PORT || 5432,
});

pool.on('error', (err, client) => {
  console.error('Erro inesperado no cliente PostgreSQL', err);
  process.exit(-1);
});

module.exports = pool;