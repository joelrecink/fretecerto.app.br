const express = require('express');
const cors = require('cors');
const pool = require('./db');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'segredo_super_secreto_mudar_na_prod';

// Middleware
app.use(cors());
app.use(express.json());

// Middleware de Autenticação
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.status(401).json({ error: 'Token não fornecido' });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Token inválido' });
    req.user = user;
    next();
  });
};

// --- ROTAS DE AUTH ---

// Registro
app.post('/api/auth/register', async (req, res) => {
  const { phone, password, role } = req.body;
  try {
    // Verificar se já existe
    const userCheck = await pool.query('SELECT id FROM users WHERE phone = $1', [phone]);
    if (userCheck.rows.length > 0) {
      return res.status(400).json({ error: 'Telefone já cadastrado.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    
    const newUser = await pool.query(
      `INSERT INTO users (phone, password_hash, role) VALUES ($1, $2, $3) RETURNING id, phone, role, credits, premium_credits`,
      [phone, hashedPassword, role || 'driver']
    );

    const user = newUser.rows[0];
    const token = jwt.sign({ id: user.id, phone: user.phone }, JWT_SECRET);

    res.json({ token, user });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao registrar usuário' });
  }
});

// Login
app.post('/api/auth/login', async (req, res) => {
  const { phone, password } = req.body;
  try {
    const result = await pool.query('SELECT * FROM users WHERE phone = $1', [phone]);
    if (result.rows.length === 0) return res.status(400).json({ error: 'Usuário não encontrado.' });

    const user = result.rows[0];
    if (user.is_blocked) return res.status(403).json({ error: 'Conta bloqueada.' });

    const validPassword = await bcrypt.compare(password, user.password_hash);
    if (!validPassword) return res.status(400).json({ error: 'Senha incorreta.' });

    const token = jwt.sign({ id: user.id, phone: user.phone }, JWT_SECRET);
    
    // Remover hash da resposta
    delete user.password_hash;
    
    res.json({ token, user });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro no login' });
  }
});

// --- ROTAS DE DADOS (Protegidas) ---

// Perfil e Créditos
app.get('/api/profile', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT id, phone, full_name, role, credits, premium_credits, last_reset_date_str FROM users WHERE id = $1', [req.user.id]);
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/credits/consume', authenticateToken, async (req, res) => {
    const { type } = req.body; // 'free' or 'premium'
    try {
        if (type === 'free') {
            await pool.query('UPDATE users SET credits = credits - 1 WHERE id = $1', [req.user.id]);
        } else {
            await pool.query('UPDATE users SET premium_credits = premium_credits - 1 WHERE id = $1', [req.user.id]);
        }
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/credits/add', authenticateToken, async (req, res) => {
    const { amount } = req.body;
    try {
        await pool.query('UPDATE users SET premium_credits = premium_credits + $1 WHERE id = $2', [amount, req.user.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Veículos
app.get('/api/vehicles', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM vehicles WHERE user_id = $1', [req.user.id]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/vehicles', authenticateToken, async (req, res) => {
  const v = req.body;
  const client = await pool.connect();
  try {
    // Verificar se existe veículo com essa placa para este usuário
    const check = await client.query('SELECT id FROM vehicles WHERE license_plate = $1 AND user_id = $2', [v.license_plate, req.user.id]);
    
    // Preparar campos para evitar SQL Injection e mapear camelCase para snake_case se necessário
    // Simplificação: Assumindo que o Frontend envia um objeto com as chaves corretas do banco (snake_case)
    // Se o frontend envia camelCase, deve ser convertido aqui ou no frontend.
    // O service do frontend abaixo converte.
    
    if (check.rows.length > 0) {
        // Update Genérico
        const id = check.rows[0].id;
        const keys = Object.keys(v).filter(k => k !== 'id' && k !== 'user_id' && k !== 'created_at');
        const values = keys.map(k => v[k]);
        const setClause = keys.map((k, i) => `${k} = $${i + 1}`).join(', ');
        
        await client.query(`UPDATE vehicles SET ${setClause} WHERE id = $${keys.length + 1}`, [...values, id]);
        res.json({ success: true, action: 'updated' });

    } else {
        // Insert Genérico
        const keys = Object.keys(v).filter(k => k !== 'id' && k !== 'created_at');
        const values = keys.map(k => v[k]);
        const placeholders = keys.map((_, i) => `$${i + 1}`).join(', ');
        
        // Adiciona user_id manualmente se não vier no body (segurança)
        if (!keys.includes('user_id')) {
             await client.query(
                `INSERT INTO vehicles (user_id, ${keys.join(', ')}) VALUES ($1, ${placeholders.replace(/\$/g, '$').split(', ').map((_,i)=>`$${i+2}`).join(', ')})`,
                [req.user.id, ...values]
            );
        } else {
             await client.query(
                `INSERT INTO vehicles (${keys.join(', ')}) VALUES (${placeholders})`,
                values
            );
        }
       
        res.json({ success: true, action: 'inserted' });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  } finally {
    client.release();
  }
});

// Financeiro
app.get('/api/financial', authenticateToken, async (req, res) => {
    try {
      const result = await pool.query('SELECT * FROM financial_records WHERE user_id = $1 ORDER BY date DESC', [req.user.id]);
      res.json(result.rows);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
});
  
app.post('/api/financial', authenticateToken, async (req, res) => {
    const f = req.body;
    try {
        const result = await pool.query(
            `INSERT INTO financial_records (user_id, type, category, description, amount, date, status, vehicle_plate, document_number)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
            [req.user.id, f.type, f.category, f.description, f.amount, f.date, f.status, f.vehicle_plate, f.document_number]
        );
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Logs Manutenção
app.post('/api/maintenance', authenticateToken, async (req, res) => {
    const m = req.body;
    try {
        await pool.query(
            `INSERT INTO maintenance_logs (user_id, license_plate, service_type, odometer, cost, location, service_date)
             VALUES ($1, $2, $3, $4, $5, $6, $7)`,
            [req.user.id, m.license_plate, m.service_type, m.odometer, m.cost, m.location, m.service_date]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/maintenance', authenticateToken, async (req, res) => {
    const { plate } = req.query;
    try {
        const result = await pool.query('SELECT * FROM maintenance_logs WHERE user_id = $1 AND license_plate = $2 ORDER BY service_date DESC', [req.user.id, plate]);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Admin Stats (Simplified)
app.get('/api/admin/stats', async (req, res) => {
    try {
        const usersCount = await pool.query('SELECT COUNT(*) FROM users');
        const revenue = await pool.query('SELECT SUM(amount) FROM transactions');
        res.json({
            totalUsers: parseInt(usersCount.rows[0].count),
            totalRevenue: parseFloat(revenue.rows[0].sum || 0),
            activeSimulations: 0,
            recentTransactions: []
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Configuração do Sistema
app.get('/api/config', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM system_config');
        const config = {};
        result.rows.forEach(row => config[row.key] = row.value);
        res.json(config);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Servir Frontend
app.use(express.static(path.join(__dirname, '../dist')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../dist/index.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 Servidor (Postgres Only) rodando na porta ${PORT}`);
});