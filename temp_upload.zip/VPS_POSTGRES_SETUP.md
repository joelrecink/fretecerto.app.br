# Guia: Configurando PostgreSQL na VPS Hostinger (Sem Supabase)

Este guia configura o banco de dados PostgreSQL local para substituir o Supabase.

## Passo 1: Instalar o PostgreSQL

Acesse sua VPS via SSH e rode:

```bash
sudo apt update
sudo apt install postgresql postgresql-contrib -y
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

## Passo 2: Criar Banco e Usuário (Credenciais Fornecidas)

```bash
# Entrar no usuário postgres
sudo -i -u postgres

# Entrar no terminal do banco
psql

# --- DENTRO DO PSQL ---

# 1. Criar banco de dados
CREATE DATABASE fretecerto_db;

# 2. Criar usuário específico
CREATE USER jbbaggio81 WITH ENCRYPTED PASSWORD 'Rec4545@#/Fre';

# 3. Dar permissões
GRANT ALL PRIVILEGES ON DATABASE fretecerto_db TO jbbaggio81;

# 4. Sair
\q
exit
```

## Passo 3: Criar as Tabelas

1. Copie o conteúdo do arquivo `POSTGRES_SCHEMA.sql` do seu projeto.
2. Acesse o banco com o novo usuário:
   ```bash
   psql -h localhost -d fretecerto_db -U jbbaggio81
   # Digite a senha: Rec4545@#/Fre
   ```
3. Cole o conteúdo SQL para criar as tabelas.

## Passo 4: Configurar o Servidor Node.js

Na pasta `server/`, instale as dependências:

```bash
cd /var/www/fretecerto-app/server
npm install express pg cors dotenv bcryptjs jsonwebtoken
npm install -g pm2
```

Inicie o servidor:
```bash
pm2 start index.js --name "fretecerto-api"
```

Agora o sistema usará este backend local em vez do Supabase.