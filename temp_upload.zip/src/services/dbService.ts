import { AdminStats, FinancialRecord, CreditPackage, Employee } from '../types';
import { supabase, isSupabaseConfigured } from './supabaseClient';
import { CREDIT_PACKAGES } from '../constants';
import { getStoredUser } from './authService';

export interface UserProfile {
  id: string;
  email: string;
  full_name?: string;
  credits: number;
  premium_credits: number;
  is_admin: boolean;
  is_root: boolean;
  is_fleet_manager: boolean;
  is_blocked?: boolean; 
  created_at: string;
}

// --- CONNECTION CHECK ---
export const checkDbConnection = async (): Promise<boolean> => {
    if (!isSupabaseConfigured()) return false;
    const { error } = await supabase.from('system_config').select('key').limit(1);
    return !error;
};

// --- ADMIN STATS ---
export const getAdminStats = async (): Promise<AdminStats> => {
  if (!isSupabaseConfigured()) return { totalUsers: 0, totalRevenue: 0, activeSimulations: 0, dailyActiveUsers: 0, recentTransactions: [] };
  
  try {
      const { count: totalUsers } = await supabase.from('profiles').select('*', { count: 'exact', head: true });
      const { data: transactions } = await supabase.from('transactions').select('*').order('date', { ascending: false }).limit(50);
      
      const totalRevenue = transactions?.reduce((acc, curr) => acc + (curr.amount || 0), 0) || 0;

      return {
          totalUsers: totalUsers || 0,
          totalRevenue: totalRevenue,
          activeSimulations: 0, 
          dailyActiveUsers: 0, 
          recentTransactions: (transactions as any[]) || []
      };
  } catch (e) {
      return { totalUsers: 0, totalRevenue: 0, activeSimulations: 0, dailyActiveUsers: 0, recentTransactions: [] };
  }
};

// --- USER MANAGEMENT ---
export const getAllProfiles = async (): Promise<UserProfile[]> => {
    if (!isSupabaseConfigured()) return [];
    const { data } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
    return data || [];
};

export const adminToggleBlockUser = async (userId: string, currentStatus: boolean): Promise<boolean> => {
    const { error } = await supabase.from('profiles').update({ is_blocked: !currentStatus }).eq('id', userId);
    return !error;
};

export const adminUpdateUserProfile = async (userId: string, updates: Partial<UserProfile>): Promise<boolean> => {
    const { error } = await supabase.from('profiles').update(updates).eq('id', userId);
    return !error;
};

export const adminResetPasswordMock = async (userId: string): Promise<boolean> => {
    return true; 
};

// --- SYSTEM CONFIG ---
export const getSystemConfig = async () => {
    if (!isSupabaseConfigured()) return {};
    const { data } = await supabase.from('system_config').select('*');
    const config: any = {};
    data?.forEach((row: any) => {
        config[row.key] = row.value;
    });
    return config;
};

export const saveSystemConfig = async (config: Record<string, string>) => {
    if (!isSupabaseConfigured()) return;
    const updates = Object.entries(config).map(([key, value]) => 
        supabase.from('system_config').upsert({ key, value })
    );
    await Promise.all(updates);
};

// --- FINANCIAL RECORDS (CLOUD ONLY) ---
export const getFinancialRecords = async (): Promise<FinancialRecord[]> => {
    const user = getStoredUser();
    if (!user || !user.id || !isSupabaseConfigured()) return [];

    try {
        const { data, error } = await supabase.from('financial_records').select('*').eq('user_id', user.id).order('date', { ascending: false });
        if (error) throw error;
        return data || [];
    } catch(e) {
        console.error("Failed to fetch financials:", e);
        return [];
    }
};

export const addFinancialRecord = async (record: Omit<FinancialRecord, 'id'>): Promise<FinancialRecord> => {
    const user = getStoredUser();
    if (!user || !user.id) throw new Error("Auth required");
    if (!isSupabaseConfigured()) throw new Error("Connection required");

    const { data, error } = await supabase.from('financial_records').insert({
        user_id: user.id,
        ...record
    }).select().single();

    if (error) throw error;
    return data;
};

export const updateFinancialStatus = async (id: string, status: 'paid' | 'pending') => {
    if (!isSupabaseConfigured()) return;
    await supabase.from('financial_records').update({ status }).eq('id', id);
};

// --- PLAN MANAGEMENT ---
export const getCreditPackages = async (): Promise<CreditPackage[]> => {
    if (!isSupabaseConfigured()) return CREDIT_PACKAGES;
    const { data } = await supabase.from('credit_packages').select('*').eq('is_active', true);
    return data && data.length > 0 ? data : CREDIT_PACKAGES;
};

export const getAllPackagesForAdmin = async (): Promise<CreditPackage[]> => {
    if (!isSupabaseConfigured()) return [];
    const { data } = await supabase.from('credit_packages').select('*');
    return data || [];
};

export const saveCreditPackage = async (pkg: Partial<CreditPackage>): Promise<{ error?: { message: string } }> => {
    const { error } = await supabase.from('credit_packages').upsert(pkg);
    return { error: error || undefined };
};

export const deleteCreditPackage = async (id: string) => {
    await supabase.from('credit_packages').delete().eq('id', id);
};

// --- EMPLOYEES ---
export const getEmployees = async (): Promise<Employee[]> => { 
    const user = getStoredUser();
    if (!user || !user.id || !isSupabaseConfigured()) return [];
    
    const { data } = await supabase.from('employees').select('*').eq('user_id', user.id);
    return data || []; 
};

export const addEmployee = async (employee: Omit<Employee, 'id'>) => {
    const user = getStoredUser();
    if (!user || !user.id) throw new Error("Auth required");
    if (!isSupabaseConfigured()) throw new Error("Connection required");
    
    await supabase.from('employees').insert({
        user_id: user.id,
        ...employee
    });
}; 

// --- BACKUP ---
export const generateBackup = async (type: string) => { 
    if (!isSupabaseConfigured()) return {};
    let table = '';
    if (type === 'USERS') table = 'profiles';
    if (type === 'VEHICLES') table = 'vehicles';
    if (type === 'CONFIG') table = 'system_config';
    
    if (table) {
        const { data } = await supabase.from(table).select('*');
        return data;
    }
    return {}; 
};

export const processPayment = async (amount: number, method: 'PIX' | 'CREDIT_CARD', userId?: string, userPhone?: string): Promise<boolean> => {
    if (!userId || !isSupabaseConfigured()) return false;
    await supabase.from('transactions').insert({
        user_id: userId,
        amount,
        method,
        status: 'completed'
    });
    return true;
};