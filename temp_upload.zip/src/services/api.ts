
// ARQUIVO DEPRECIADO
// A arquitetura migrou para Supabase Cloud (frontend conecta direto no DB as a Service).
// Não utilize este arquivo. Use 'supabaseClient.ts', 'authService.ts' ou 'dbService.ts'.

export const api = {
    get: async () => { throw new Error("API Local desativada. Use Supabase Client."); },
    post: async () => { throw new Error("API Local desativada. Use Supabase Client."); },
    put: async () => { throw new Error("API Local desativada. Use Supabase Client."); },
    delete: async () => { throw new Error("API Local desativada. Use Supabase Client."); }
};
