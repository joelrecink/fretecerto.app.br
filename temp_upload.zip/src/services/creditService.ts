import { UserCredits } from '../types';
import { DAILY_FREE_CREDITS } from '../constants';
import { getStoredUser } from './authService';
import { supabase } from './supabaseClient';

const getTodayString = () => new Date().toISOString().split('T')[0];

export const getStoredCredits = async (phoneNumber: string): Promise<UserCredits> => {
  const userSession = getStoredUser();
  const today = getTodayString();
  
  if (!userSession || !userSession.id) {
      return { freeCredits: 0, premiumCredits: 0, lastResetDate: today };
  }

  try {
      const { data, error } = await supabase
        .from('profiles')
        .select('credits, premium_credits, last_reset_date_str')
        .eq('id', userSession.id)
        .single();

      if (error || !data) {
          return { freeCredits: DAILY_FREE_CREDITS, premiumCredits: 0, lastResetDate: today };
      }

      let free = data.credits;
      const premium = data.premium_credits;
      const lastReset = data.last_reset_date_str;

      if (lastReset !== today) {
          free = DAILY_FREE_CREDITS;
          // Atualiza data do reset
          await supabase.from('profiles').update({ 
              credits: free, 
              last_reset_date_str: today 
          }).eq('id', userSession.id);
      }
      
      return {
          freeCredits: free,
          premiumCredits: premium,
          lastResetDate: today
      };

  } catch (e) {
      console.error("Credit Service Error:", e);
      return { freeCredits: 0, premiumCredits: 0, lastResetDate: today };
  }
};

export const hasCredit = (credits: UserCredits): boolean => {
  return credits.freeCredits > 0 || credits.premiumCredits > 0;
};

export const consumeCredit = async (currentCredits: UserCredits, phoneNumber: string): Promise<UserCredits> => {
  const userSession = getStoredUser();
  if (!userSession || !userSession.id) return currentCredits;

  const newCredits = { ...currentCredits };
  let updatePayload: any = {};

  if (newCredits.freeCredits > 0) {
    newCredits.freeCredits -= 1;
    updatePayload = { credits: newCredits.freeCredits };
  } else if (newCredits.premiumCredits > 0) {
    newCredits.premiumCredits -= 1;
    updatePayload = { premium_credits: newCredits.premiumCredits };
  } else {
      throw new Error("Saldo insuficiente.");
  }
  
  const { error } = await supabase.from('profiles').update(updatePayload).eq('id', userSession.id);
  if (error) throw new Error("Erro ao atualizar saldo.");
  
  return newCredits;
};

export const addPremiumCredits = async (amount: number, phoneNumber: string | undefined): Promise<UserCredits> => {
  const userSession = getStoredUser();
  if (!userSession || !userSession.id) throw new Error("Usuário não autenticado");
  
  const { data } = await supabase.from('profiles').select('premium_credits').eq('id', userSession.id).single();
  const current = data?.premium_credits || 0;
  const newBalance = current + amount;

  await supabase.from('profiles').update({ premium_credits: newBalance }).eq('id', userSession.id);
  
  return await getStoredCredits(phoneNumber || '');
};