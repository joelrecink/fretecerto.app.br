import { User, VehicleData, SavedVehicle, MaintenanceLog } from '../types';
import { supabase, isSupabaseConfigured } from './supabaseClient';

const USER_STORAGE_KEY = 'fretecerto_user_session';

// --- AUTHENTICATION ---

export const signInUser = async (email: string, password: string, rememberMe = true): Promise<User> => {
    if (!isSupabaseConfigured()) {
        throw new Error('Supabase não configurado. Verifique as variáveis de ambiente.');
    }

    const { data, error } = await supabase.auth.signInWithPassword({
        email: email,
        password: password,
    });

    if (error) {
        console.error("Supabase Login Error:", error);
        throw new Error(error.message === 'Invalid login credentials' ? 'E-mail ou senha incorretos.' : error.message);
    }

    if (!data.user) throw new Error('Erro inesperado na autenticação.');

    let profile = null;
    try {
        const { data: p } = await supabase.from('profiles').select('*').eq('id', data.user.id).single();
        profile = p;
    } catch (e) {
        console.warn("Profile fetch warning:", e);
    }

    if (profile?.is_blocked) {
        await supabase.auth.signOut();
        throw new Error('Conta bloqueada pelo administrador.');
    }

    const user: User = {
        email: email,
        isAuthenticated: true,
        isAdmin: profile?.is_admin || false,
        isRoot: profile?.is_root || false,
        isFleetManager: profile?.is_fleet_manager || false
    };

    const sessionData = { ...user, id: data.user.id };
    if (rememberMe) localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(sessionData));
    else sessionStorage.setItem(USER_STORAGE_KEY, JSON.stringify(sessionData));

    return user;
};

export const signUpUser = async (email: string, password: string, role: 'driver' | 'fleet' = 'driver', rememberMe = true): Promise<User> => {
    if (!isSupabaseConfigured()) throw new Error('Supabase desconectado.');

    const { data, error } = await supabase.auth.signUp({
        email: email,
        password: password,
        options: { data: { full_name: '', role: role } }
    });

    if (error) throw new Error(error.message);
    if (!data.user) throw new Error('Erro ao criar conta.');

    // Fetch profile created by trigger
    // Small delay might be needed for trigger to fire, but usually instant
    let profile = null;
    const { data: p } = await supabase.from('profiles').select('*').eq('id', data.user.id).single();
    profile = p;

    const user: User = {
        email: email,
        isAuthenticated: true,
        isAdmin: profile?.is_admin || false,
        isRoot: profile?.is_root || false,
        isFleetManager: profile?.is_fleet_manager || false
    };

    if (rememberMe) localStorage.setItem(USER_STORAGE_KEY, JSON.stringify({ ...user, id: data.user.id }));
    return user;
};

export const getStoredUser = (): (User & { id?: string }) | null => {
  try {
      const stored = localStorage.getItem(USER_STORAGE_KEY) || sessionStorage.getItem(USER_STORAGE_KEY);
      return stored ? JSON.parse(stored) : null;
  } catch {
      return null;
  }
};

export const logoutUser = async () => {
  if (isSupabaseConfigured()) {
      try { await supabase.auth.signOut(); } catch(e) {}
  }
  localStorage.removeItem(USER_STORAGE_KEY);
  sessionStorage.removeItem(USER_STORAGE_KEY);
};

export const resetPasswordRequest = async (email: string) => {
    if (!isSupabaseConfigured()) throw new Error("Supabase desconectado.");
    const { error } = await supabase.auth.resetPasswordForEmail(email);
    if (error) throw error;
};

// --- PREFERENCES & VEHICLES (CLOUD ONLY) ---

export const saveUserPreferences = async (email: string, data: VehicleData) => {
    localStorage.setItem(`fretecerto_prefs_${email}`, JSON.stringify(data));
};

export const getUserPreferences = async (email: string): Promise<VehicleData | null> => {
    const local = localStorage.getItem(`fretecerto_prefs_${email}`);
    return local ? JSON.parse(local) : null;
};

export const getUserVehicles = async (): Promise<SavedVehicle[]> => {
    if (!isSupabaseConfigured()) return [];
    
    const user = getStoredUser();
    if (!user || !user.id) return [];

    try {
        const { data, error } = await supabase.from('vehicles').select('*').eq('user_id', user.id);
        if (error) throw error;
        return data || [];
    } catch (e) { 
        console.error("Erro ao buscar veículos:", e);
        return []; 
    }
};

export const saveNewVehicle = async (vehicle: VehicleData): Promise<{ success: boolean; mode: 'cloud' }> => {
    if (!isSupabaseConfigured()) throw new Error('Conexão com banco de dados necessária.');
    
    const user = getStoredUser();
    if (!user || !user.id) throw new Error('AUTH_REQUIRED');

    const payload: any = {
        user_id: user.id,
        license_plate: vehicle.licensePlate?.toUpperCase(),
        model_name: `${vehicle.axles} Eixos - ${vehicle.cargoCapacity}T`,
        axles: vehicle.axles,
        fuel_consumption: vehicle.fuelConsumption,
        fuel_price: vehicle.fuelPrice,
        cargo_capacity: vehicle.cargoCapacity,
        maintenance_cost_per_km: vehicle.maintenanceCostPerKm,
        ref_tire_price_new: vehicle.refTirePriceNew,
        ref_tire_lifespan_new: vehicle.refTireLifespanNew,
        ref_tire_price_remold: vehicle.refTirePriceRemold,
        ref_tire_lifespan_remold: vehicle.refTireLifespanRemold,
        tire_steer_qty_new: vehicle.tireSteerQtyNew,
        tire_steer_qty_remold: vehicle.tireSteerQtyRemold,
        tire_drive_qty_new: vehicle.tireDriveQtyNew,
        tire_drive_qty_remold: vehicle.tireDriveQtyRemold,
        tire_trailer_qty_new: vehicle.tireTrailerQtyNew,
        tire_trailer_qty_remold: vehicle.tireTrailerQtyRemold,
        last_oil_change_km: vehicle.lastOilChangeKm,
        last_oil_change_date: vehicle.lastOilChangeDate,
        last_oil_change_cost: vehicle.lastOilChangeCost,
        oil_change_interval_km: vehicle.oilChangeIntervalKm,
        last_trans_oil_change_km: vehicle.lastTransOilChangeKm,
        last_trans_oil_change_date: vehicle.lastTransOilChangeDate,
        last_trans_oil_change_cost: vehicle.lastTransOilChangeCost,
        trans_oil_change_interval_km: vehicle.transOilChangeIntervalKm,
        last_filter_change_km: vehicle.lastFilterChangeKm,
        last_filter_change_date: vehicle.lastFilterChangeDate,
        last_filter_change_cost: vehicle.lastFilterChangeCost,
        filter_change_interval_km: vehicle.filterChangeIntervalKm,
        current_odometer: vehicle.currentOdometer,
        driver_salary_monthly: vehicle.driverSalaryMonthly,
        driver_salary_include_13th: vehicle.driverSalaryInclude13th,
        driver_commission_percentage: vehicle.driverCommissionPercentage,
        asset_value: vehicle.assetValue,
        annual_depreciation_rate: vehicle.annualDepreciationRate,
        insurance_yearly: vehicle.insuranceYearly,
        registration_yearly: vehicle.registrationYearly
    };

    const { data: existing } = await supabase.from('vehicles').select('id').eq('license_plate', payload.license_plate).eq('user_id', user.id).maybeSingle();
    
    if (existing) {
        const { error } = await supabase.from('vehicles').update(payload).eq('id', existing.id);
        if (error) throw error;
    } else {
        const { error } = await supabase.from('vehicles').insert(payload);
        if (error) throw error;
    }

    return { success: true, mode: 'cloud' };
};

export const addMaintenanceLog = async (log: Omit<MaintenanceLog, 'id'>): Promise<{ success: boolean; mode: 'cloud' }> => {
    if (!isSupabaseConfigured()) throw new Error('Conexão necessária.');
    const user = getStoredUser();
    if (!user || !user.id) throw new Error('AUTH_REQUIRED');

    const { error } = await supabase.from('maintenance_logs').insert({ user_id: user.id, ...log });
    if (error) throw error;

    return { success: true, mode: 'cloud' };
};

export const getMaintenanceHistory = async (licensePlate: string): Promise<MaintenanceLog[]> => {
    if (!isSupabaseConfigured()) return [];
    const user = getStoredUser();
    if (!user || !user.id) return [];

    const { data, error } = await supabase.from('maintenance_logs').select('*').eq('user_id', user.id).eq('license_plate', licensePlate).order('service_date', { ascending: false });
    
    if (error) {
        console.error("Fetch maintenance error:", error);
        return [];
    }
    return data;
};