
import React, { useState } from 'react';
import { VehicleData } from '../types';
import SpeechInput from './SpeechInput';
import { Fuel, Settings2, Clock, Weight, Percent, ArrowLeft, Save, AlertTriangle, CheckCircle, Loader2 } from 'lucide-react';
import Logo from './Logo';
import { saveNewVehicle, getStoredUser } from '../services/authService';

interface VehicleSetupProps {
  data: VehicleData;
  onUpdate: (data: VehicleData) => void;
  onNext: () => void;
  onBack: () => void;
  onLogin?: () => void;
}

const VehicleSetup: React.FC<VehicleSetupProps> = ({ data, onUpdate, onNext, onBack, onLogin }) => {
  const [loading, setLoading] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success'>('idle');

  const handleChange = (field: keyof VehicleData, value: any) => {
    if (field === 'driverName' || field === 'licensePlate') {
        onUpdate({ ...data, [field]: value });
        return;
    }

    if (typeof value === 'string') {
        let clean = value.trim();
        // Handle Brazilian format (1.000,00 -> 1000.00)
        if (clean.includes(',')) {
            clean = clean.replace(/\./g, '').replace(',', '.');
        } else if ((clean.match(/\./g) || []).length > 1) {
            clean = clean.replace(/\./g, '');
        }

        const numValue = parseFloat(clean);
        onUpdate({
            ...data,
            [field]: isNaN(numValue) ? 0 : numValue,
        });
    } else {
        onUpdate({ ...data, [field]: value });
    }
  };

  const handleSave = async () => {
      // STRICT PLATE VALIDATION
      if (!data.licensePlate || data.licensePlate.trim().length === 0) {
          alert("⚠️ PLACA NECESSÁRIA!\n\nVocê será redirecionado para a tela de Custos para cadastrar a placa do veículo.");
          onBack(); // Send them back to Costs to fix it
          return;
      }

      // STRICT AUTH VALIDATION
      const user = getStoredUser();
      if (!user || !user.id) {
          alert("🔒 CADASTRO OBRIGATÓRIO\n\nPara salvar dados do veículo e mantê-los seguros, é necessário fazer login.");
          if (onLogin) onLogin();
          return;
      }

      setLoading(true);
      try {
          const result = await saveNewVehicle(data);
          if (result.success) {
              setSaveStatus('success');
              setTimeout(() => setSaveStatus('idle'), 2000);
          } else {
              alert("Erro ao salvar.");
          }
      } catch (e: any) {
          if (e.message === 'AUTH_REQUIRED') {
              if (onLogin) onLogin();
          } else {
              alert("Erro ao salvar dados.");
          }
      } finally {
          setLoading(false);
      }
  };

  return (
    <div className="max-w-lg mx-auto bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 animate-fade-in pb-4">
      <div className="bg-slate-800 p-8 text-white relative">
        <h2 className="text-3xl font-bold flex items-center gap-4">
          <div className="bg-white/10 p-2 rounded-2xl border border-white/10">
            <Logo className="w-12 h-12" />
          </div>
          Operacional
        </h2>
        
        {/* Active Plate Indicator */}
        <div className="mt-4 flex items-center gap-2 bg-slate-900/50 p-2 rounded-lg border border-slate-700 w-fit">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Veículo Ativo:</span>
            {data.licensePlate ? (
                <span className="font-mono font-bold text-green-400">{data.licensePlate}</span>
            ) : (
                <span className="font-bold text-red-400 text-xs flex items-center gap-1"><AlertTriangle size={12}/> Sem Placa</span>
            )}
        </div>
      </div>

      <div className="p-8 space-y-8">
        
        <div className="grid grid-cols-1 gap-8">
            {/* Group Fuel Items */}
            <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100 space-y-6 relative hover:border-blue-300 transition-colors">
                <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                        <Fuel className="text-blue-600" />
                        <h3 className="text-xl font-bold text-blue-900">Combustível & Tempo</h3>
                    </div>
                    <button onClick={handleSave} className="text-blue-600 bg-white border border-blue-200 p-2 rounded-lg text-xs font-bold hover:bg-blue-50 transition-colors">
                        {saveStatus === 'success' ? <CheckCircle size={18}/> : <Save size={18}/>}
                    </button>
                </div>
                <SpeechInput
                  label="Consumo Médio (Km/L)"
                  value={data.fuelConsumption || ''}
                  onChange={(v) => handleChange('fuelConsumption', v)}
                  type="number"
                  placeholder="Ex: 2.5"
                />
                
                <SpeechInput
                  label="Preço do Diesel (Hoje)"
                  prefix="R$"
                  value={data.fuelPrice || ''}
                  onChange={(v) => handleChange('fuelPrice', v)}
                  type="number"
                  placeholder="Ex: 6,20"
                />

                <div className="pt-4 border-t border-blue-200 mt-2">
                   <div className="flex items-center gap-2 mb-4">
                      <Clock className="text-blue-600 w-5 h-5" />
                      <h4 className="text-lg font-bold text-blue-900">Jornada de Trabalho</h4>
                   </div>
                   <SpeechInput
                    label="Horas Rodadas por Dia"
                    value={data.drivingHoursPerDay || ''}
                    onChange={(v) => handleChange('drivingHoursPerDay', v)}
                    type="number"
                    placeholder="Ex: 9"
                   />
                </div>
            </div>

            <div className="space-y-6">
              
              <div>
                <div className="flex justify-between items-end mb-3">
                    <label className="text-lg font-semibold text-gray-800 block">Número de Eixos</label>
                    <button onClick={handleSave} className="text-slate-400 hover:text-slate-600"><Save size={16}/></button>
                </div>
                <div className="flex items-center gap-6 bg-gray-50 p-6 rounded-2xl border-2 border-gray-200">
                    <Settings2 className="text-gray-500 w-8 h-8" />
                    <div className="flex-1">
                        <input 
                        type="range" 
                        min="2" 
                        max="9" 
                        step="1" 
                        value={data.axles}
                        onChange={(e) => handleChange('axles', e.target.value)}
                        className="w-full h-3 bg-gray-300 rounded-lg appearance-none cursor-pointer accent-blue-600"
                        />
                        <div className="flex justify-between text-xs text-gray-500 mt-2 font-medium">
                            <span>2 Eixos</span>
                            <span>9 Eixos</span>
                        </div>
                    </div>
                    <div className="bg-slate-800 rounded-xl p-4 min-w-[80px] flex items-center justify-center shadow-inner border-2 border-slate-600">
                        <span className="text-4xl font-bold text-white text-center">{data.axles}</span>
                    </div>
                </div>
              </div>

              <div className="bg-gray-50 p-6 rounded-2xl border border-gray-200 relative hover:border-gray-300 transition-colors">
                  <div className="flex justify-between items-center mb-4">
                      <div className="flex items-center gap-2">
                          <Weight className="text-gray-600 w-6 h-6" />
                          <h3 className="text-lg font-bold text-gray-800">Capacidade de Carga</h3>
                      </div>
                      <button onClick={handleSave} className="text-gray-500 bg-white border border-gray-200 p-2 rounded-lg hover:bg-gray-100">
                         <Save size={18}/>
                      </button>
                  </div>
                  <SpeechInput
                    label="Carga (Toneladas)"
                    value={data.cargoCapacity || ''}
                    onChange={(v) => handleChange('cargoCapacity', v)}
                    type="number"
                    placeholder="Ex: 32"
                    prefix="Ton"
                  />
              </div>

              {/* Commission Only */}
              <div className="bg-purple-50 p-6 rounded-2xl border border-purple-100 space-y-6 relative hover:border-purple-300 transition-colors">
                 <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                        <Percent className="text-purple-600 w-6 h-6" />
                        <h3 className="text-lg font-bold text-purple-900">Comissão</h3>
                    </div>
                    <button onClick={handleSave} className="text-purple-600 bg-white border border-purple-200 p-2 rounded-lg hover:bg-purple-100">
                        <Save size={18}/>
                    </button>
                </div>
                <SpeechInput
                    label="Comissão do Motorista (%)"
                    value={data.driverCommissionPercentage || ''}
                    onChange={(v) => handleChange('driverCommissionPercentage', v)}
                    type="number"
                    placeholder="Ex: 10"
                    prefix="%"
                />
              </div>
            </div>
        </div>

        <div className="flex gap-4 mt-6">
            <button
              onClick={onBack}
              className="px-6 py-5 rounded-xl border-2 border-slate-200 text-slate-600 font-bold text-lg hover:bg-slate-50 transition-colors flex items-center justify-center"
            >
              <ArrowLeft size={24} />
            </button>
            <button
              onClick={onNext}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-5 rounded-xl shadow-lg transition-transform active:scale-[0.98] text-xl flex justify-center items-center gap-2"
            >
              Definir Rota <span className="text-blue-200">→</span>
            </button>
        </div>
      </div>
    </div>
  );
};

export default VehicleSetup;
