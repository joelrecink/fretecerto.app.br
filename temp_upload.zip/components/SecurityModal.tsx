
import React, { useState } from 'react';
import { X, Shield, Lock } from 'lucide-react';

interface SecurityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const SecurityModal: React.FC<SecurityModalProps> = ({ isOpen, onClose }) => {
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden relative">
         <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1"
         >
            <X size={24} />
         </button>

         <div className="p-6 text-center">
            <div className="flex justify-center mb-6">
                <div className="bg-orange-100 p-3 rounded-full text-orange-600">
                    <Shield size={32} />
                </div>
            </div>
            
            <h2 className="text-xl font-bold text-slate-800 mb-2">Modo Local Ativo</h2>
            <p className="text-sm text-slate-500 mb-6">
                A autenticação de dois fatores (2FA) requer um servidor backend. 
                Como você está rodando em <strong>Modo Local</strong> (Offline/PC), esta funcionalidade está desativada.
            </p>

            <button 
                onClick={onClose}
                className="w-full bg-slate-900 text-white font-bold py-3 rounded-xl hover:bg-black shadow-lg"
            >
                Entendido
            </button>
         </div>
      </div>
    </div>
  );
};

export default SecurityModal;
