
import React, { useState } from 'react';
import { Mail, Loader2, ArrowLeft, Lock, UserPlus, LogIn, MessageCircle, X, CheckCircle, ShieldCheck } from 'lucide-react';
import Logo from './Logo';
import { signInUser, signUpUser, resetPasswordRequest } from '../services/authService';
import { User } from '../types';

interface LoginScreenProps {
  onLoginSuccess: (user: User) => void;
  onCancel?: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess, onCancel }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState<'login' | 'register'>('login');
  
  // Recovery States
  const [showRecoveryModal, setShowRecoveryModal] = useState(false);
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
    setError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes('@')) {
      setError('Digite um e-mail válido.');
      return;
    }
    if (password.length < 6) {
      setError('A senha deve ter no mínimo 6 caracteres.');
      return;
    }
    setLoading(true);
    setError('');
    
    try {
      if (mode === 'login') {
        const user = await signInUser(email, password);
        onLoginSuccess(user);
      } else {
        // Register Flow
        const user = await signUpUser(email, password, 'driver');
        onLoginSuccess(user);
      }
    } catch (err: any) {
      setError(err.message || 'Ocorreu um erro. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  // --- RECOVERY LOGIC ---
  const handleRequestRecovery = async () => {
      if (!email.includes('@')) {
          alert('Digite seu e-mail no campo de login primeiro.');
          return;
      }
      setLoading(true);
      try {
          await resetPasswordRequest(email);
          alert(`Enviamos um link de redefinição para ${email}. Verifique sua caixa de entrada.`);
          setShowRecoveryModal(false);
      } catch (e: any) {
          alert(e.message);
      } finally {
          setLoading(false);
      }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-blue-50 to-slate-100 p-4 relative overflow-hidden font-sans">
      
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden animate-fade-in relative z-10">
        
        {onCancel && (
            <button 
                onClick={onCancel}
                className="absolute top-4 left-4 z-20 text-slate-400 hover:text-slate-600 p-2 rounded-full hover:bg-slate-100 transition-colors"
                title="Voltar"
            >
                <ArrowLeft size={24} />
            </button>
        )}

        <div className="pt-12 pb-6 px-8 text-center relative">
          <div className="flex justify-center mb-6">
            <Logo className="w-20 h-20" />
          </div>
          <h1 className="text-3xl font-black tracking-tight text-slate-900">
            {mode === 'login' ? 'Bem-vindo de volta!' : 'Crie sua conta grátis'}
          </h1>
          <p className="text-slate-500 text-sm mt-2 font-medium">
            {mode === 'login' ? 'Entre com seu e-mail e senha.' : 'Preencha seus dados para começar.'}
          </p>
        </div>

        <div className="p-8 pt-2">
            <form onSubmit={handleSubmit} className="space-y-6">
              
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 ml-1" htmlFor="email">E-mail</label>
                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-600 transition-colors">
                    <Mail size={20} />
                  </div>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={email}
                    onChange={handleEmailChange}
                    placeholder="seu@email.com"
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-xl text-lg font-semibold text-slate-900 placeholder:text-slate-400 focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2 ml-1">
                    <label className="block text-sm font-bold text-slate-700" htmlFor="password">Senha</label>
                    {mode === 'login' && (
                        <button 
                            type="button"
                            onClick={handleRequestRecovery}
                            className="text-xs font-bold text-blue-600 hover:text-blue-800 hover:underline"
                        >
                            Esqueci a senha
                        </button>
                    )}
                </div>
                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-600 transition-colors">
                    <Lock size={20} />
                  </div>
                  <input
                    id="password"
                    name="password"
                    type="password"
                    value={password}
                    onChange={(e) => { setPassword(e.target.value); setError(''); }}
                    placeholder="******"
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-xl text-lg font-semibold text-slate-900 placeholder:text-slate-400 focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                  />
                </div>
              </div>

              {error && (
                <div className="text-red-500 text-sm font-medium text-center bg-red-50 py-3 rounded-lg animate-pulse border border-red-100">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-200 transition-all active:scale-[0.98] flex items-center justify-center gap-2 text-lg"
              >
                {loading ? <Loader2 className="animate-spin" /> : (
                    mode === 'login' 
                    ? <><LogIn size={20} /> Entrar</> 
                    : <><UserPlus size={20} /> Criar Conta</>
                )}
              </button>
              
              <div className="text-center pt-2">
                  <button 
                    type="button"
                    onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(''); }}
                    className="text-slate-600 font-semibold text-sm hover:text-blue-600 hover:text-blue-600 hover:underline"
                  >
                    {mode === 'login' 
                        ? 'Não possui conta? Cadastre-se grátis' 
                        : 'Já possui conta? Faça Login'}
                  </button>
              </div>
            </form>
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;
