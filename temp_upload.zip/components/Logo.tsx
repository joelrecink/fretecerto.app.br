
import React from 'react';

const Logo = ({ className = "w-12 h-12" }: { className?: string }) => (
  <svg 
    viewBox="0 0 200 200" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg" 
    className={`${className} drop-shadow-md`}
  >
    <defs>
      <linearGradient id="skyGradient" x1="0" y1="0" x2="200" y2="200">
        <stop offset="0%" stopColor="#38bdf8" /> {/* Light Blue */}
        <stop offset="100%" stopColor="#2563eb" /> {/* Royal Blue */}
      </linearGradient>
      <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
        <feMerge>
            <feMergeNode in="coloredBlur"/>
            <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>

    {/* Background - Vibrant Sky Gradient */}
    <rect width="200" height="200" rx="45" fill="url(#skyGradient)" />
    
    {/* Sun/Energy Element - Subtle circle in corner */}
    <circle cx="160" cy="40" r="25" fill="#fde047" fillOpacity="0.4" />

    {/* The Road - Cheerful curved path in Amber/Orange */}
    <path 
      d="M-10 160 C 50 160, 80 130, 140 130 H 210" 
      stroke="#fbbf24" 
      strokeWidth="12" 
      strokeLinecap="round"
      fill="none"
    />
    <path 
      d="M-10 160 C 50 160, 80 130, 140 130 H 210" 
      stroke="#fff" 
      strokeWidth="2" 
      strokeDasharray="10 10" 
      strokeLinecap="round"
      fill="none"
      className="opacity-60"
    />

    {/* Truck - Modern and Fast (White) */}
    <g transform="translate(10, -5)">
        {/* Trailer */}
        <path d="M35 75 H 115 V 125 H 35 V 75 Z" fill="white" />
        {/* Cab */}
        <path d="M115 90 H 145 L 160 125 H 115 V 90 Z" fill="#e0f2fe" />
        {/* Window */}
        <path d="M118 92 H 142 L 150 110 H 118 V 92 Z" fill="#0ea5e9" />
        
        {/* Wheels */}
        <circle cx="65" cy="130" r="14" fill="#1e293b" stroke="#94a3b8" strokeWidth="3" />
        <circle cx="140" cy="130" r="14" fill="#1e293b" stroke="#94a3b8" strokeWidth="3" />
    </g>
    
    {/* "Certo" Checkmark - Vivid Lime Green with Outline */}
    <g transform="translate(0, -5)" filter="url(#glow)">
        <path 
        d="M135 45 L 155 65 L 190 25" 
        stroke="white" 
        strokeWidth="20" 
        strokeLinecap="round" 
        strokeLinejoin="round"
        />
        <path 
        d="M135 45 L 155 65 L 190 25" 
        stroke="#4ade80" 
        strokeWidth="12" 
        strokeLinecap="round" 
        strokeLinejoin="round"
        />
    </g>
  </svg>
);

export default Logo;
