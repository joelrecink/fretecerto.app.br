
import React, { useState, useEffect } from 'react';
import { SimulationResult, RouteData, RoutePoint } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { CheckCircle, XCircle, AlertTriangle, Map, Navigation, Wallet, ExternalLink, RefreshCw, Share2, Edit2, ChevronDown, ChevronUp, Save, List, Volume2, StopCircle, Plus, Trash2, MapPin, Wrench, Briefcase, Calculator } from 'lucide-react';
import { addFinancialRecord } from '../services/dbService';

// -------------------------------------------------------------------------------------------
// CONFIGURAÇÃO DA CHAVE DO GOOGLE MAPS
// -------------------------------------------------------------------------------------------
const getEnvVar = (key: string): string => {
  try {
    if (typeof process !== 'undefined' && process.env && process.env[key]) return process.env[key];
  } catch (e) {}
  return '';
};

const GOOGLE_MAPS_KEY = getEnvVar('API_KEY') || getEnvVar('VITE_API_KEY') || ''; 
// -------------------------------------------------------------------------------------------

interface DashboardProps {
  result: SimulationResult;
  route: RouteData;
  onReset: () => void;
  onRecalculate: (newRoute: RouteData) => void;
  isRecalculating?: boolean;
}

const Dashboard: React.FC<DashboardProps> = ({ result, route, onReset, onRecalculate, isRecalculating = false }) => {
  const [currentTollCost, setCurrentTollCost] = useState(result.estimatedTollCost);
  const [isEditingToll, setIsEditingToll] = useState(false);
  const [tempTollValue, setTempTollValue] = useState(result.estimatedTollCost.toString());
  
  const [speakingSection, setSpeakingSection] = useState<'none' | 'viability' | 'suggestions'>('none');
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);

  // Local state for waypoints editing
  const [waypoints, setWaypoints] = useState<RoutePoint[]>(route.waypoints || []);
  const [newWaypointAddress, setNewWaypointAddress] = useState('');
  const [showRouteEditor, setShowRouteEditor] = useState(false);

  useEffect(() => {
    setCurrentTollCost(result.estimatedTollCost);
    setTempTollValue(result.estimatedTollCost.toString());
  }, [result]);

  const maintCost = result.estimatedMaintenanceCost || 0; // Pneus, Óleo, Filtros (Variável)
  const fixedCost = result.estimatedFixedCost || 0; // Salário, Seguro, Deprec (Fixo rateado)

  const currentNetProfit = result.totalFreightIncome - result.estimatedFuelCost - currentTollCost - result.driverCommissionCost - maintCost - fixedCost;

  const data = [
    { name: 'Combustível', value: result.estimatedFuelCost, color: '#EF4444' }, 
    { name: 'Pedágios', value: currentTollCost, color: '#F59E0B' }, 
    { name: 'Comissão', value: result.driverCommissionCost, color: '#8B5CF6' },
    { name: 'Manutenção (Var)', value: maintCost, color: '#F97316' },
    { name: 'Custos Fixos', value: fixedCost, color: '#6366F1' },
  ];

  if (currentNetProfit > 0) {
    data.push({ name: 'Lucro Líquido', value: currentNetProfit, color: '#10B981' }); 
  }

  useEffect(() => {
    const loadVoices = () => {
        if ('speechSynthesis' in window) {
            const voices = window.speechSynthesis.getVoices();
            if (voices.length > 0) setAvailableVoices(voices);
        }
    };
    loadVoices();
    if ('speechSynthesis' in window && window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
    return () => { 
        if ('speechSynthesis' in window) window.speechSynthesis.cancel(); 
    };
  }, []);

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  const handleSaveToll = () => {
    // Robust parsing for "1.200,50"
    let clean = tempTollValue.trim();
    if (clean.includes(',')) {
        clean = clean.replace(/\./g, '').replace(',', '.');
    } else if ((clean.match(/\./g) || []).length > 1) {
        clean = clean.replace(/\./g, '');
    }
    
    const val = parseFloat(clean);
    if (!isNaN(val)) {
        setCurrentTollCost(val);
        setIsEditingToll(false);
    }
  };

  const handleSpeak = (text: string, section: 'viability' | 'suggestions') => {
    if (!('speechSynthesis' in window)) return;

    if (speakingSection === section) {
        window.speechSynthesis.cancel();
        setSpeakingSection('none');
        return;
    }
    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*#]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'pt-BR';
    const ptVoices = availableVoices.filter(v => v.lang.includes('pt-BR') || v.lang.includes('pt_BR'));
    const bestVoice = ptVoices.find(v => v.name.includes('Daniel') || v.name.includes('Male') || v.name.includes('Google')) || ptVoices[0];
    if (bestVoice) utterance.voice = bestVoice;
    utterance.pitch = 0.75; 
    utterance.rate = 0.95; 
    utterance.onend = () => setSpeakingSection('none');
    utterance.onerror = () => setSpeakingSection('none');
    setSpeakingSection(section);
    window.speechSynthesis.speak(utterance);
  };

  // --- ROBUST MAP LINK GENERATION ---
  const getGoogleMapsLink = (forEmbed = false) => {
    const validPickups = route.pickups.map(p => p.address?.trim()).filter(addr => addr && addr.length > 0);
    const validDeliveries = route.deliveries.map(d => d.address?.trim()).filter(addr => addr && addr.length > 0);
    const validWaypoints = waypoints.map(w => w.address?.trim()).filter(a => a && a.length > 0);
    
    const allPoints = [...validPickups, ...validDeliveries];
    if (allPoints.length < 2) return null;

    const origin = encodeURIComponent(allPoints[0]);
    const destination = encodeURIComponent(allPoints[allPoints.length - 1]);
    
    const intermediateStops = [
        ...validPickups.slice(1), 
        ...validWaypoints, 
        ...validDeliveries.slice(0, -1)
    ];

    if (forEmbed) {
        let url = `https://www.google.com/maps/embed/v1/directions?key=${GOOGLE_MAPS_KEY}&origin=${origin}&destination=${destination}`;
        if (intermediateStops.length > 0) {
            const stopsParam = intermediateStops.map(a => encodeURIComponent(a)).join('|');
            url += `&waypoints=${stopsParam}`;
        }
        return url;
    } else {
        let url = `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${destination}&travelmode=driving`;
        if (intermediateStops.length > 0) {
            const stopsParam = intermediateStops.map(a => encodeURIComponent(a)).join('|');
            url += `&waypoints=${stopsParam}`;
        }
        return url;
    }
  };

  const mapLink = getGoogleMapsLink(false);
  const embedUrl = getGoogleMapsLink(true);

  const handleShare = async () => {
    const textToShare = `🚛 FreteCerto: Lucro de ${formatCurrency(currentNetProfit)} na rota ${route.pickups[0].address} -> ${route.deliveries[0].address}`;
    if (navigator.share) {
      try { await navigator.share({ title: 'FreteCerto', text: textToShare }); } catch (error) {}
    } else {
      try { await navigator.clipboard.writeText(textToShare); alert('Copiado!'); } catch (err) {}
    }
  };

  const handleAddWaypoint = () => {
    if (!newWaypointAddress) return;
    const newPoint: RoutePoint = { id: Math.random().toString(36).substr(2, 9), type: 'waypoint', address: newWaypointAddress, value: 0 };
    setWaypoints([...waypoints, newPoint]);
    setNewWaypointAddress('');
  };

  const handleRemoveWaypoint = (id: string) => {
    setWaypoints(waypoints.filter(w => w.id !== id));
  };

  const triggerRecalculate = () => {
    onRecalculate({ ...route, waypoints: waypoints });
    setShowRouteEditor(false);
  };

  return (
    <div className="max-w-4xl mx-auto pb-10 space-y-8 animate-fade-in">
      
      {/* Header Summary */}
      <div className={`rounded-3xl p-8 text-white shadow-2xl transform transition-all ${
        result.viabilityScore === 'high' ? 'bg-gradient-to-br from-emerald-600 to-teal-800' :
        result.viabilityScore === 'medium' ? 'bg-gradient-to-br from-amber-500 to-orange-700' :
        'bg-gradient-to-br from-red-600 to-rose-800'
      }`}>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
                {result.viabilityScore === 'high' ? <CheckCircle className="w-10 h-10"/> :
                result.viabilityScore === 'medium' ? <AlertTriangle className="w-10 h-10"/> :
                <XCircle className="w-10 h-10"/>}
                <h2 className="text-4xl font-extrabold tracking-tight">
                    {result.viabilityScore === 'high' ? 'Alta Viabilidade' :
                     result.viabilityScore === 'medium' ? 'Viabilidade Média' : 'Baixa Viabilidade'}
                </h2>
            </div>
            
            <div className="flex flex-col gap-2">
                <button 
                    onClick={() => handleSpeak(result.viabilityMessage, 'viability')}
                    className="self-start flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur-sm px-3 py-1.5 rounded-full text-sm font-semibold transition-all"
                >
                     {speakingSection === 'viability' ? <><StopCircle size={16} className="animate-pulse" /> Parar Leitura</> : <><Volume2 size={16} /> Ouvir Análise</>}
                </button>
                <p className="text-lg opacity-90 leading-relaxed font-medium">{result.viabilityMessage}</p>
            </div>
          </div>
          
          <div className="bg-white/20 backdrop-blur-md rounded-2xl p-6 min-w-[200px] border border-white/30 shadow-lg">
            <p className="text-sm font-semibold uppercase tracking-wider opacity-80">Lucro Estimado</p>
            <p className="text-4xl font-black mt-1">{formatCurrency(currentNetProfit)}</p>
          </div>
        </div>
      </div>

      {/* Map Visualization & Route Editor */}
      <div className="bg-white rounded-3xl overflow-hidden shadow-xl border border-gray-100">
          <div className="flex justify-between items-center p-6 border-b border-gray-100">
             <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2"><Map className="text-blue-600" /> Mapa da Rota</h3>
             <button onClick={() => setShowRouteEditor(!showRouteEditor)} className={`text-sm font-bold flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${showRouteEditor ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}>
                <Edit2 size={16} /> {showRouteEditor ? 'Fechar Editor' : 'Modificar Trajeto'}
             </button>
          </div>
          
          {showRouteEditor && (
              <div className="bg-blue-50/50 p-6 border-b border-blue-100 animate-fade-in">
                  <h4 className="text-sm font-bold text-blue-800 uppercase mb-3">Adicionar Pontos de Passagem</h4>
                  <div className="flex flex-col md:flex-row gap-3 mb-4">
                      <input type="text" value={newWaypointAddress} onChange={(e) => setNewWaypointAddress(e.target.value)} placeholder="Ex: Via Fernão Dias..." className="flex-1 px-4 py-3 rounded-xl border border-blue-200 outline-none"/>
                      <button onClick={handleAddWaypoint} className="bg-blue-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2"><Plus size={18} /> Adicionar</button>
                  </div>
                  {waypoints.map((wp, idx) => (
                      <div key={wp.id} className="flex items-center justify-between bg-white p-3 rounded-lg border border-gray-200 mb-2">
                          <span className="text-gray-700 font-medium text-sm flex items-center gap-2"><span className="bg-blue-100 text-blue-600 text-[10px] font-bold px-2 py-0.5 rounded">VIA {idx + 1}</span>{wp.address}</span>
                          <button onClick={() => handleRemoveWaypoint(wp.id)} className="text-red-500 hover:text-red-700 p-1"><Trash2 size={16} /></button>
                      </div>
                  ))}
                  <div className="flex justify-end mt-4">
                      <button onClick={triggerRecalculate} disabled={isRecalculating} className="bg-green-600 text-white px-8 py-3 rounded-xl font-bold flex items-center gap-2 disabled:opacity-50 shadow-lg shadow-green-200 hover:bg-green-700 transition-colors">
                          {isRecalculating ? <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div> : <RefreshCw size={18} />} 
                          Recalcular Custos
                      </button>
                  </div>
              </div>
          )}

          <div className="w-full h-[400px] bg-slate-100 relative group">
             {embedUrl && GOOGLE_MAPS_KEY ? (
                 <iframe 
                    width="100%" 
                    height="100%" 
                    style={{ border: 0 }} 
                    loading="lazy" 
                    allowFullScreen 
                    src={embedUrl} 
                    title="Google Maps Route" 
                    className="relative z-10"
                 ></iframe>
             ) : (
                 <div className="flex flex-col items-center justify-center h-full text-gray-400 p-6 text-center bg-gray-100 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px]">
                    <div className="bg-white p-6 rounded-full shadow-sm mb-4">
                        <Map size={48} className="text-blue-500 opacity-80"/>
                    </div>
                    <p className="font-bold text-gray-700 text-xl mb-2">Visualização da Rota</p>
                    <p className="text-sm text-gray-500 max-w-md mb-6">
                        O mapa interativo não pôde ser carregado (Chave API ausente ou restrita). 
                        Você pode visualizar a rota completa diretamente no Google Maps.
                    </p>
                    <a href={mapLink || '#'} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 bg-blue-600 text-white px-8 py-4 rounded-xl font-bold shadow-lg shadow-blue-200 hover:bg-blue-700 transition-transform hover:scale-105 active:scale-95">
                        <ExternalLink size={20} /> Abrir no Google Maps
                    </a>
                 </div>
             )}
          </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Financial Breakdown */}
        <div className="bg-white rounded-3xl p-8 shadow-xl border border-gray-100">
           <h3 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2"><Wallet className="text-blue-600" /> Financeiro</h3>
           <div className="space-y-4 mb-8">
             <div className="flex justify-between items-center p-4 bg-green-50 rounded-xl border border-green-100">
                <span className="text-green-800 font-semibold">Receita Total</span>
                <span className="text-2xl font-bold text-green-700">{formatCurrency(result.totalFreightIncome)}</span>
             </div>
             
             <div className="flex justify-between items-center p-3 text-gray-600"><span>(-) Combustível</span><span className="font-semibold">{formatCurrency(result.estimatedFuelCost)}</span></div>
             <div className="flex justify-between items-center p-3 text-gray-600"><span>(-) Comissão</span><span className="font-semibold text-purple-600">{formatCurrency(result.driverCommissionCost)}</span></div>
             
             <div className="flex justify-between items-center p-3 text-gray-600 bg-orange-50/50 rounded-lg">
                 <span className="flex items-center gap-2">(-) Manutenção Variável<Wrench size={14}/></span>
                 <span className="font-semibold text-orange-600">{formatCurrency(maintCost)}</span>
             </div>
             
             <div className="flex justify-between items-center p-3 text-gray-600 bg-indigo-50/50 rounded-lg">
                 <span className="flex items-center gap-2">(-) Custos Fixos (Rateio)<Calculator size={14}/></span>
                 <span className="font-semibold text-indigo-600">{formatCurrency(fixedCost)}</span>
             </div>

             <div className="flex flex-col p-3 border-b border-gray-100 pb-4 bg-amber-50/50 rounded-lg">
                <div className="flex justify-between items-center w-full">
                    <span className="text-gray-600 flex items-center gap-2">(-) Pedágio <button onClick={() => setIsEditingToll(!isEditingToll)} className="text-blue-500 hover:text-blue-700 p-1"><Edit2 size={14} /></button></span>
                    {isEditingToll ? (
                        <div className="flex items-center gap-2"><span className="text-sm text-gray-500">R$</span><input type="text" value={tempTollValue} onChange={(e) => setTempTollValue(e.target.value)} className="w-20 p-1 text-right border border-blue-300 rounded text-sm focus:ring-2 focus:ring-blue-500"/><button onClick={handleSaveToll} className="text-green-600"><Save size={18} /></button></div>
                    ) : (
                        <span className="font-semibold text-amber-700">{formatCurrency(currentTollCost)}</span>
                    )}
                </div>
             </div>

             <div className="flex justify-between items-center pt-2">
                <span className="text-xl font-bold text-gray-800">Resultado Final</span>
                <span className={`text-2xl font-bold ${currentNetProfit >= 0 ? 'text-blue-600' : 'text-red-600'}`}>{formatCurrency(currentNetProfit)}</span>
             </div>
           </div>

           <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={data} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
                    {data.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                  </Pie>
                  <Tooltip formatter={(value: number) => formatCurrency(value)} />
                  <Legend verticalAlign="bottom" height={36}/>
                </PieChart>
              </ResponsiveContainer>
           </div>
        </div>

        {/* Route Details & Actions */}
        <div className="space-y-8">
            <div className="bg-white rounded-3xl p-8 shadow-xl border border-gray-100">
                <h3 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2"><Navigation className="text-blue-600" /> Detalhes</h3>
                <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-blue-50 p-4 rounded-xl text-center"><p className="text-blue-600 text-sm font-bold uppercase">Distância</p><p className="text-3xl font-black text-blue-900 mt-1">{result.totalDistanceKm} km</p></div>
                    <div className="bg-purple-50 p-4 rounded-xl text-center"><p className="text-purple-600 text-sm font-bold uppercase">Tempo</p><p className="text-3xl font-black text-purple-900 mt-1">{result.totalDurationDays} Dias</p></div>
                </div>

                <div className="bg-gray-50 rounded-xl p-5 border border-gray-200">
                    <div className="flex justify-between items-center mb-3 pb-2 border-b border-gray-200">
                        <h4 className="font-bold text-gray-700 flex items-center gap-2"><Map size={18} /> Sugestões IA</h4>
                        <button onClick={() => handleSpeak(result.routeSuggestions, 'suggestions')} className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold transition-all ${speakingSection === 'suggestions' ? 'bg-red-100 text-red-600 animate-pulse' : 'bg-blue-100 text-blue-700 hover:bg-blue-200'}`}>
                          {speakingSection === 'suggestions' ? <><StopCircle size={14} /> Parar</> : <><Volume2 size={14} /> Ouvir</>}
                        </button>
                    </div>
                    <p className="text-gray-600 leading-relaxed text-sm whitespace-pre-line">{result.routeSuggestions}</p>
                </div>

                 <div className="mt-6 flex flex-col gap-3">
                    {mapLink && (
                      <a href={mapLink} target="_blank" rel="noopener noreferrer" className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-200 font-bold py-4 rounded-xl transition-all active:scale-[0.98]">
                        <ExternalLink size={20} /> Abrir Rota no Google Maps
                      </a>
                    )}
                    
                    <button onClick={handleShare} className="w-full flex items-center justify-center gap-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border-2 border-indigo-200 font-bold py-4 rounded-xl transition-all active:scale-[0.98]">
                      <Share2 size={20} /> Compartilhar Resultado
                    </button>
                 </div>
            </div>
        </div>
      </div>

      <button onClick={onReset} className="w-full bg-slate-800 hover:bg-black text-white font-bold py-5 rounded-2xl shadow-lg transition-transform active:scale-[0.98] text-xl flex justify-center items-center gap-3">
        <RefreshCw size={24} /> Novo Cálculo
      </button>

    </div>
  );
};

export default Dashboard;
