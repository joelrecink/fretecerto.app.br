
import React from 'react';
import { VehicleData } from '../types';
import SpeechInput from './SpeechInput';
import Logo from './Logo';
import { User, LogIn, ArrowRight } from 'lucide-react';

interface DriverSetupProps {
  data: VehicleData;
  onUpdate: (data: VehicleData) => void;
  onNext: () => void;
  onLogin: () => void;
}

const DriverSetup: React.FC<DriverSetupProps> = ({ data, onUpdate, onNext, onLogin }) => {
  const handleChange = (field: keyof VehicleData, value: string) => {
    if (field === 'driverName') {
        onUpdate({ ...data, [field]: value });
    } else {
        // Numeric fields logic
        const normalized = value.replace(',', '.');
        const numValue = parseFloat(normalized);
        onUpdate({
            ...data,
            [field]: isNaN(numValue) ? 0 : numValue,
        });
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white rounded-3xl shadow-2xl overflow-hidden animate-fade-in relative z-10 border border-slate-100">
      
      {/* Brand Header - Clean & Centered */}
      <div className="pt-10 pb-4 px-8 text-center">
        <div className="flex justify-center mb-5">
          <div className="transform transition-transform hover:scale-105 duration-300">
            <Logo className="w-24 h-24" />
          </div>
        </div>
        <h1 className="text-3xl font-black tracking-tight text-slate-900 mb-1">
          Frete<span className="text-blue-600">Certo</span>
        </h1>
        <div className="flex items-center justify-center gap-3 text-slate-400 text-sm font-medium mt-2">
            <div className="h-px w-6 bg-slate-200"></div>
            <span className="uppercase tracking-wider text-xs">Identificação</span>
            <div className="h-px w-6 bg-slate-200"></div>
        </div>
      </div>

      <div className="p-8 pt-2 space-y-8">
        
        {/* Form Section */}
        <div className="space-y-6">
             <div>
                <div className="flex items-center gap-2 mb-3 text-slate-700 font-bold">
                    <div className="bg-blue-50 p-2 rounded-lg text-blue-600">
                        <User size={20} />
                    </div>
                    <h3>Dados do Motorista</h3>
                </div>
                
                <SpeechInput
                  label="Nome Completo"
                  value={data.driverName || ''}
                  onChange={(v) => handleChange('driverName', v)}
                  placeholder="Ex: João da Silva"
                  className="text-left"
                />
                <p className="text-xs text-slate-400 mt-2 pl-1">
                    Usado para personalizar seus relatórios de viagem.
                </p>
            </div>
        </div>

        {/* Actions Section */}
        <div className="space-y-4 pt-2">
            <button
                onClick={onNext}
                className="group w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-200 transition-all active:scale-[0.98] text-lg flex justify-center items-center gap-3"
            >
                <span>Começar</span>
                <div className="bg-white/20 p-1.5 rounded-full group-hover:bg-white/30 transition-colors">
                    <ArrowRight size={18} />
                </div>
            </button>

            <div className="relative flex py-3 items-center">
                <div className="flex-grow border-t border-slate-100"></div>
                <span className="flex-shrink-0 mx-4 text-slate-300 text-[10px] font-bold uppercase tracking-widest">Ou</span>
                <div className="flex-grow border-t border-slate-100"></div>
            </div>

            <button 
                onClick={onLogin}
                className="w-full flex items-center justify-center gap-2 text-slate-600 hover:text-blue-600 font-bold text-sm transition-all py-3.5 border-2 border-slate-100 hover:border-blue-100 rounded-xl hover:bg-blue-50 group"
            >
                <LogIn size={18} className="group-hover:scale-110 transition-transform text-slate-400 group-hover:text-blue-500"/>
                Já possui conta? Entrar
            </button>
        </div>
      </div>
      
      {/* Decorative Bottom Bar */}
      <div className="h-1.5 w-full bg-gradient-to-r from-blue-400 via-blue-600 to-indigo-600"></div>
    </div>
  );
};

export default DriverSetup;
