
import React from 'react';
import { UserCredits } from '../types';
import { Coins, Zap } from 'lucide-react';

interface CreditDisplayProps {
  credits: UserCredits;
  onBuyClick: () => void;
}

const CreditDisplay: React.FC<CreditDisplayProps> = ({ credits, onBuyClick }) => {
  const total = credits.freeCredits + credits.premiumCredits;
  const isLow = total === 0;

  return (
    <button 
      onClick={onBuyClick}
      className={`flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all shadow-sm ${
        isLow 
          ? 'bg-red-50 border-red-200 text-red-700 animate-pulse' 
          : 'bg-white border-blue-200 text-blue-800 hover:bg-blue-50'
      }`}
    >
      {credits.premiumCredits > 0 ? (
        <Coins size={16} className="text-amber-500" />
      ) : (
        <Zap size={16} className={isLow ? 'text-red-500' : 'text-blue-500'} />
      )}
      <span className="text-sm font-bold">
        {total} <span className="hidden xs:inline font-normal text-xs">créditos</span>
      </span>
      {isLow && (
        <span className="bg-red-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded ml-1">
            COMPRAR
        </span>
      )}
    </button>
  );
};

export default CreditDisplay;
