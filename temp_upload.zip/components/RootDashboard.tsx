import React, { useEffect, useState } from 'react';
import { AdminStats, CreditPackage } from '../types';
import { 
    getAdminStats, 
    getAllProfiles, 
    getAllPackagesForAdmin, 
    saveCreditPackage, 
    deleteCreditPackage, 
    getSystemConfig, 
    saveSystemConfig,
    generateBackup,
    checkDbConnection,
    adminToggleBlockUser,
    adminResetPasswordMock,
    adminUpdateUserProfile,
    UserProfile
} from '../services/dbService';
import { testTollGuruConnection, validateGeminiKey } from '../services/geminiService';
import { validateMercadoPagoCredentials, validateStripeCredentials } from '../services/paymentService';
import { validateTwilioCredentials, validateMessageBirdCredentials } from '../services/smsService';
import Logo from './Logo';
import { 
  LayoutDashboard, 
  Users, 
  Database, 
  Download, 
  HardDrive, 
  Settings, 
  Map, 
  Save, 
  PlusCircle, 
  Edit2, 
  Trash2, 
  CheckCircle, 
  MessageSquare, 
  ShoppingBag, 
  Loader2, 
  LogOut,
  CreditCard,
  Wifi,
  UserCheck,
  Ban,
  KeyRound,
  MessageCircle,
  Briefcase,
  Truck,
  Activity,
  Calendar,
  Search,
  Shield,
  Play,
  BrainCircuit,
  X,
  Coins
} from 'lucide-react';

interface RootDashboardProps {
  onLogout: () => void;
  onTestSystem?: () => void;
}

const RootDashboard: React.FC<RootDashboardProps> = ({ onLogout, onTestSystem }) => {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard'); 
  const [isConnected, setIsConnected] = useState<boolean>(true);

  const [users, setUsers] = useState<UserProfile[]>([]);
  const [userSearch, setUserSearch] = useState('');
  
  const [packages, setPackages] = useState<CreditPackage[]>([]);
  const [editingPackage, setEditingPackage] = useState<Partial<CreditPackage> | null>(null);

  // User Actions State
  const [resetModalUser, setResetModalUser] = useState<UserProfile | null>(null);
  const [tempPassword, setTempPassword] = useState('');
  const [editUserModal, setEditUserModal] = useState<UserProfile | null>(null); // New: Edit User Modal

  // Configs
  const [geminiKey, setGeminiKey] = useState('');
  const [mapsKey, setMapsKey] = useState('');

  const [tollProvider, setTollProvider] = useState<'TOLLGURU' | 'MAPLINK'>('TOLLGURU');
  const [tollguruKey, setTollguruKey] = useState('');
  
  const [smsProvider, setSmsProvider] = useState<'TWILIO' | 'MESSAGEBIRD'>('TWILIO');
  const [twilioSid, setTwilioSid] = useState('');
  const [twilioToken, setTwilioToken] = useState('');
  const [twilioPhone, setTwilioPhone] = useState(''); 
  const [msgBirdKey, setMsgBirdKey] = useState('');

  // Payment Configs
  const [paymentProvider, setPaymentProvider] = useState<'MERCADOPAGO' | 'STRIPE'>('MERCADOPAGO');
  const [mpAccessToken, setMpAccessToken] = useState('');
  const [stripeSecretKey, setStripeSecretKey] = useState('');
  
  // Backup original config for safe merge
  const [originalConfig, setOriginalConfig] = useState<Record<string, string>>({});

  const [testMessage, setTestMessage] = useState<{type: 'success'|'error', text: string} | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'success'>('idle');

  useEffect(() => {
    const init = async () => {
        // Parallel checks
        try {
            const [statsData, configData] = await Promise.all([
                getAdminStats(),
                getSystemConfig(),
            ]);

            setStats(statsData);
            setOriginalConfig(configData || {});
            
            if (configData) {
                if (configData.gemini_api_key) setGeminiKey(configData.gemini_api_key);
                if (configData.google_maps_key) setMapsKey(configData.google_maps_key);

                if (configData.toll_provider) setTollProvider(configData.toll_provider as any);
                if (configData.tollguru_key) setTollguruKey(configData.tollguru_key);
                
                if (configData.sms_provider) setSmsProvider(configData.sms_provider as any);
                if (configData.twilio_sid) setTwilioSid(configData.twilio_sid);
                if (configData.twilio_token) setTwilioToken(configData.twilio_token);
                if (configData.twilio_phone) setTwilioPhone(configData.twilio_phone);
                if (configData.msgbird_key) setMsgBirdKey(configData.msgbird_key);

                if (configData.payment_provider) setPaymentProvider(configData.payment_provider as any);
                if (configData.mp_access_token) setMpAccessToken(configData.mp_access_token);
                if (configData.stripe_secret_key) setStripeSecretKey(configData.stripe_secret_key);
            }
        } catch (e) {
            console.error("Dashboard Init Error", e);
        }
        setLoading(false);
    };
    init();
  }, []);

  useEffect(() => {
      if (activeTab === 'users') {
          setLoading(true);
          getAllProfiles().then((data) => {
              setUsers(data);
              setLoading(false);
          });
      }
      if (activeTab === 'plans') {
          getAllPackagesForAdmin().then(setPackages);
      }
  }, [activeTab]);

  const handleDownloadBackup = async (type: 'FULL' | 'USERS' | 'VEHICLES' | 'CONFIG') => {
      try {
          const data = await generateBackup(type);
          const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `fretecerto_backup_${type}_${new Date().toISOString()}.json`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          alert("Backup gerado!");
      } catch (e: any) { alert("Erro no backup: " + e.message); }
  };

  const handleSaveConfig = async () => {
      setSaveStatus('saving');
      const safeConfig = {
          ...originalConfig,
          gemini_api_key: geminiKey || originalConfig.gemini_api_key,
          google_maps_key: mapsKey || originalConfig.google_maps_key,

          toll_provider: tollProvider,
          tollguru_key: tollguruKey || originalConfig.tollguru_key,
          
          sms_provider: smsProvider,
          twilio_sid: twilioSid || originalConfig.twilio_sid,
          twilio_token: twilioToken || originalConfig.twilio_token,
          twilio_phone: twilioPhone || originalConfig.twilio_phone,
          msgbird_key: msgBirdKey || originalConfig.msgbird_key,

          payment_provider: paymentProvider,
          mp_access_token: mpAccessToken || originalConfig.mp_access_token,
          stripe_secret_key: stripeSecretKey || originalConfig.stripe_secret_key
      };
      await saveSystemConfig(safeConfig);
      setOriginalConfig(safeConfig as any);
      setSaveStatus('success');
      setTimeout(() => setSaveStatus('idle'), 3000);
  };

  const handleTestApi = async (type: 'AI' | 'TOLL' | 'SMS' | 'PAYMENT') => {
      setIsTesting(true);
      setTestMessage(null);
      let res = { success: false, message: 'Erro' };
      
      try {
        if (type === 'AI') res = await validateGeminiKey(geminiKey);
        if (type === 'TOLL') res = await testTollGuruConnection(tollguruKey);
        if (type === 'SMS') {
            if (smsProvider === 'TWILIO') res = await validateTwilioCredentials(twilioSid, twilioToken);
            else res = await validateMessageBirdCredentials(msgBirdKey);
        }
        if (type === 'PAYMENT') {
            if (paymentProvider === 'MERCADOPAGO') res = await validateMercadoPagoCredentials(mpAccessToken);
            else res = await validateStripeCredentials(stripeSecretKey);
        }
      } catch (error: any) {
          res = { success: false, message: error.message || 'Erro desconhecido' };
      }
      
      setTestMessage({ type: res.success ? 'success' : 'error', text: res.message });
      setIsTesting(false);
  };

  const handleNewPackage = () => {
      setEditingPackage({ label: '', price: 0, credits: 10, is_active: true });
  };
  
  const handleSavePackage = async () => {
      if (!editingPackage?.label) return alert('Nome inválido');
      const { error } = await saveCreditPackage(editingPackage);
      if (error) alert('Erro ao salvar: ' + error.message);
      else {
          setEditingPackage(null);
          getAllPackagesForAdmin().then(setPackages);
      }
  };

  // --- USER ACTIONS ---
  const toggleBlockUser = async (u: UserProfile) => {
      if (confirm(`Tem certeza que deseja ${u.is_blocked ? 'DESBLOQUEAR' : 'BLOQUEAR'} este usuário?`)) {
          await adminToggleBlockUser(u.id, !!u.is_blocked);
          getAllProfiles().then(setUsers);
      }
  };

  const initPasswordReset = (u: UserProfile) => {
      setResetModalUser(u);
      setTempPassword(Math.random().toString(36).slice(-6).toUpperCase());
  };

  const confirmPasswordReset = async () => {
      if (!resetModalUser) return;
      await adminResetPasswordMock(resetModalUser.id);
      
      const message = `Olá ${resetModalUser.full_name || 'Usuário'}, sua senha foi redefinida.\nNova Senha: *${tempPassword}*\nAcesse agora: https://fretecerto.app`;
      // Changed to Mailto since we use email now
      const url = `mailto:${resetModalUser.email}?subject=Nova Senha&body=${encodeURIComponent(message)}`;
      
      window.open(url, '_blank');
      setResetModalUser(null);
  };

  // --- EDIT USER LOGIC ---
  const handleSaveUser = async () => {
      if (!editUserModal) return;
      const success = await adminUpdateUserProfile(editUserModal.id, {
          full_name: editUserModal.full_name,
          credits: parseInt(editUserModal.credits.toString()),
          premium_credits: parseInt(editUserModal.premium_credits.toString()),
          is_admin: editUserModal.is_admin,
          is_root: editUserModal.is_root,
          is_fleet_manager: editUserModal.is_fleet_manager
      });

      if (success) {
          getAllProfiles().then(setUsers);
          setEditUserModal(null);
      } else {
          alert("Erro ao atualizar usuário.");
      }
  };

  const filteredUsers = users.filter(u => 
      u.email.includes(userSearch) || 
      (u.full_name || '').toLowerCase().includes(userSearch.toLowerCase())
  );

  if (loading && activeTab !== 'users') return <div className="flex justify-center items-center h-screen"><Loader2 className="animate-spin"/></div>;

  return (
    <div className="flex min-h-screen bg-slate-100 font-sans">
        <aside className="w-64 bg-slate-900 text-white p-4 flex flex-col gap-2 relative shadow-2xl z-10">
            <div className="p-4 mb-4 border-b border-slate-800 font-bold text-xl flex gap-2"><Logo className="w-8 h-8"/> SystemRoot</div>
            
            <button onClick={() => setActiveTab('dashboard')} className={`p-3 rounded-lg flex gap-3 transition-all ${activeTab==='dashboard'?'bg-red-600 font-bold text-white':'text-slate-400 hover:text-white hover:bg-slate-800'}`}><LayoutDashboard size={20}/> Visão Geral</button>
            <button onClick={() => setActiveTab('users')} className={`p-3 rounded-lg flex gap-3 transition-all ${activeTab==='users'?'bg-red-600 font-bold text-white':'text-slate-400 hover:text-white hover:bg-slate-800'}`}><Users size={20}/> Contas de Usuário</button>
            <button onClick={() => setActiveTab('plans')} className={`p-3 rounded-lg flex gap-3 transition-all ${activeTab==='plans'?'bg-red-600 font-bold text-white':'text-slate-400 hover:text-white hover:bg-slate-800'}`}><ShoppingBag size={20}/> Planos & Ofertas</button>
            <button onClick={() => setActiveTab('apis')} className={`p-3 rounded-lg flex gap-3 transition-all ${activeTab==='apis'?'bg-red-600 font-bold text-white':'text-slate-400 hover:text-white hover:bg-slate-800'}`}><Settings size={20}/> APIs & Config</button>
            <button onClick={() => setActiveTab('backups')} className={`p-3 rounded-lg flex gap-3 transition-all ${activeTab==='backups'?'bg-red-600 font-bold text-white':'text-slate-400 hover:text-white hover:bg-slate-800'}`}><Database size={20}/> Dados & Backup</button>
            
            <div className="mt-auto pt-4 border-t border-slate-800 pb-4">
                 <div className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold text-green-400 bg-green-900/20">
                     <Wifi size={14} />
                     Modo Local
                 </div>
            </div>

            {onTestSystem && (
                <button onClick={onTestSystem} className="p-3 text-green-400 flex gap-2 hover:bg-green-900/20 rounded font-bold transition-colors">
                    <Play size={20}/> Testar Calculadora
                </button>
            )}

            <button onClick={onLogout} className="p-3 text-red-400 flex gap-2 hover:bg-red-900/20 rounded font-bold"><LogOut size={20}/> Encerrar Sessão</button>
        </aside>

        <main className="flex-1 p-8 overflow-y-auto">
            {activeTab === 'dashboard' && (
                <div className="space-y-6 animate-fade-in">
                    <h1 className="text-2xl font-bold text-slate-800">Visão Geral</h1>
                    <div className="grid md:grid-cols-3 gap-6">
                         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                             <div className="flex items-center gap-2 mb-2 text-slate-500 font-bold uppercase text-xs"><Users size={16}/> Usuários</div>
                             <div className="text-4xl font-black text-slate-800">{stats?.totalUsers || 0}</div>
                         </div>
                         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                             <div className="flex items-center gap-2 mb-2 text-slate-500 font-bold uppercase text-xs"><CheckCircle size={16}/> Simulações</div>
                             <div className="text-4xl font-black text-slate-800">{stats?.activeSimulations || 0}</div>
                         </div>
                         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                             <div className="flex items-center gap-2 mb-2 text-slate-500 font-bold uppercase text-xs"><ShoppingBag size={16}/> Receita Total</div>
                             <div className="text-4xl font-black text-slate-800">R$ {stats?.totalRevenue.toFixed(2) || 0}</div>
                         </div>
                    </div>
                </div>
            )}

            {activeTab === 'backups' && (
                <div className="max-w-4xl space-y-6 animate-fade-in">
                    <h1 className="text-2xl font-bold text-slate-800">Backup e Exportação</h1>
                    <div className="grid md:grid-cols-2 gap-6">
                        <div className="bg-slate-800 text-white p-8 rounded-2xl shadow-lg">
                            <HardDrive size={32} className="text-green-400 mb-4"/>
                            <h3 className="text-xl font-bold mb-2">Backup Completo</h3>
                            <p className="text-slate-400 text-sm mb-6">Download de todas as tabelas (JSON).</p>
                            <button onClick={() => handleDownloadBackup('FULL')} className="w-full bg-green-600 py-3 rounded-xl font-bold flex justify-center gap-2 hover:bg-green-50"><Download/> Baixar Tudo</button>
                        </div>
                        <div className="space-y-4">
                            <button onClick={() => handleDownloadBackup('USERS')} className="w-full bg-white p-4 rounded-xl shadow-sm flex justify-between items-center hover:bg-blue-50 border border-slate-200"><span className="font-bold text-slate-700">Backup Usuários</span> <Download size={18} className="text-blue-500"/></button>
                            <button onClick={() => handleDownloadBackup('VEHICLES')} className="w-full bg-white p-4 rounded-xl shadow-sm flex justify-between items-center hover:bg-orange-50 border border-slate-200"><span className="font-bold text-slate-700">Backup Frota</span> <Download size={18} className="text-orange-500"/></button>
                            <button onClick={() => handleDownloadBackup('CONFIG')} className="w-full bg-white p-4 rounded-xl shadow-sm flex justify-between items-center hover:bg-purple-50 border border-slate-200"><span className="font-bold text-slate-700">Backup Configurações</span> <Download size={18} className="text-purple-500"/></button>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'apis' && (
                <div className="max-w-3xl space-y-6 animate-fade-in">
                    <div className="flex justify-between items-center">
                        <h1 className="text-2xl font-bold text-slate-800">Configurações & API</h1>
                        <button onClick={handleSaveConfig} className={`px-6 py-2 rounded-lg font-bold text-white flex items-center gap-2 ${saveStatus === 'success' ? 'bg-green-600' : 'bg-slate-900'}`}>
                            {saveStatus === 'saving' ? <Loader2 className="animate-spin"/> : <Save/>}
                            {saveStatus === 'success' ? 'Salvo!' : 'Salvar Alterações'}
                        </button>
                    </div>
                    
                    {testMessage && <div className={`p-4 rounded-xl font-bold ${testMessage.type==='success'?'bg-green-100 text-green-800':'bg-red-100 text-red-800'}`}>{testMessage.text}</div>}

                    <div className="grid gap-6">
                        {/* GOOGLE API SECTION */}
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                            <h3 className="font-bold mb-4 flex gap-2 text-slate-800"><BrainCircuit className="text-indigo-600"/> Inteligência Artificial & Mapas</h3>
                            <div className="space-y-4">
                                <div>
                                    <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Google Gemini API Key</label>
                                    <input className="w-full p-3 border rounded-xl bg-slate-50 font-mono text-sm" type="password" placeholder="AIzaSy..." value={geminiKey} onChange={e=>setGeminiKey(e.target.value)}/>
                                </div>
                                <div>
                                    <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Google Maps API Key (Optional)</label>
                                    <input className="w-full p-3 border rounded-xl bg-slate-50 font-mono text-sm" type="password" placeholder="AIzaSy..." value={mapsKey} onChange={e=>setMapsKey(e.target.value)}/>
                                </div>
                            </div>
                            <button onClick={() => handleTestApi('AI')} disabled={isTesting} className="mt-4 text-xs bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-lg font-bold text-slate-600 flex items-center gap-1"><Activity size={12}/> Validar Chave Gemini</button>
                        </div>

                        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                            <h3 className="font-bold mb-4 flex gap-2 text-slate-800"><MessageSquare className="text-green-600"/> Provedor SMS</h3>
                            <div className="grid grid-cols-2 gap-4 mb-4">
                                <button onClick={() => setSmsProvider('TWILIO')} className={`p-3 border rounded-xl font-bold text-sm ${smsProvider==='TWILIO'?'bg-green-50 border-green-500 text-green-700':'text-slate-500'}`}>Twilio</button>
                                <button onClick={() => setSmsProvider('MESSAGEBIRD')} className={`p-3 border rounded-xl font-bold text-sm ${smsProvider==='MESSAGEBIRD'?'bg-green-50 border-green-500 text-green-700':'text-slate-500'}`}>MessageBird</button>
                            </div>
                            {smsProvider === 'TWILIO' && (
                                <div className="space-y-2">
                                    <input className="w-full p-3 border rounded-xl bg-slate-50" placeholder="Account SID" value={twilioSid} onChange={e=>setTwilioSid(e.target.value)}/>
                                    <input className="w-full p-3 border rounded-xl bg-slate-50" type="password" placeholder="Auth Token" value={twilioToken} onChange={e=>setTwilioToken(e.target.value)}/>
                                    <input className="w-full p-3 border rounded-xl bg-slate-50" placeholder="Número Twilio (From) ex: +1555..." value={twilioPhone} onChange={e=>setTwilioPhone(e.target.value)}/>
                                </div>
                            )}
                            <button onClick={() => handleTestApi('SMS')} disabled={isTesting} className="mt-4 text-xs bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-lg font-bold text-slate-600 flex items-center gap-1"><Activity size={12}/> Testar Conexão SMS</button>
                        </div>

                        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                            <h3 className="font-bold mb-4 flex gap-2 text-slate-800"><Map className="text-blue-600"/> Roteirização (TollGuru)</h3>
                            <input className="w-full p-3 border rounded-xl bg-slate-50" type="password" placeholder="API Key (x-api-key)" value={tollguruKey} onChange={e=>setTollguruKey(e.target.value)}/>
                            <button onClick={() => handleTestApi('TOLL')} disabled={isTesting} className="mt-4 text-xs bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-lg font-bold text-slate-600 flex items-center gap-1"><Activity size={12}/> Validar Chave</button>
                        </div>

                        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                            <h3 className="font-bold mb-4 flex gap-2 text-slate-800"><CreditCard className="text-purple-600"/> Gateway de Pagamento</h3>
                            <div className="grid grid-cols-2 gap-4 mb-4">
                                <button onClick={() => setPaymentProvider('MERCADOPAGO')} className={`p-3 border rounded-xl font-bold text-sm ${paymentProvider==='MERCADOPAGO'?'bg-purple-50 border-purple-500 text-purple-700':'text-slate-500'}`}>Mercado Pago</button>
                                <button onClick={() => setPaymentProvider('STRIPE')} className={`p-3 border rounded-xl font-bold text-sm ${paymentProvider==='STRIPE'?'bg-purple-50 border-purple-500 text-purple-700':'text-slate-500'}`}>Stripe</button>
                            </div>
                            {paymentProvider === 'MERCADOPAGO' && (
                                <input className="w-full p-3 border rounded-xl bg-slate-50" type="password" placeholder="Access Token (APP_USR...)" value={mpAccessToken} onChange={e=>setMpAccessToken(e.target.value)}/>
                            )}
                            {paymentProvider === 'STRIPE' && (
                                <input className="w-full p-3 border rounded-xl bg-slate-50" type="password" placeholder="Secret Key (sk_live...)" value={stripeSecretKey} onChange={e=>setStripeSecretKey(e.target.value)}/>
                            )}
                            <button onClick={() => handleTestApi('PAYMENT')} disabled={isTesting} className="mt-4 text-xs bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-lg font-bold text-slate-600 flex items-center gap-1"><Activity size={12}/> Validar Credenciais</button>
                        </div>
                    </div>
                </div>
            )}
            
            {activeTab === 'plans' && (
                <div className="space-y-6 animate-fade-in">
                    <div className="flex justify-between items-center"><h1 className="text-2xl font-bold text-slate-800">Planos & Pacotes</h1><button onClick={handleNewPackage} className="bg-blue-600 text-white px-4 py-2 rounded-lg font-bold flex gap-2 hover:bg-blue-700"><PlusCircle size={20}/> Novo Plano</button></div>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {packages.map(p => (
                            <div key={p.id} className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 relative group">
                                <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button onClick={()=>setEditingPackage(p)} className="text-blue-600 bg-blue-50 p-1 rounded hover:bg-blue-100"><Edit2 size={16}/></button>
                                    <button onClick={()=>deleteCreditPackage(p.id).then(()=>getAllPackagesForAdmin().then(setPackages))} className="text-red-600 bg-red-50 p-1 rounded hover:bg-red-100"><Trash2 size={16}/></button>
                                </div>
                                <div className="mb-2">
                                    <span className="bg-blue-100 text-blue-700 text-xs font-bold px-2 py-1 rounded uppercase">{p.credits} Créditos</span>
                                </div>
                                <h3 className="font-bold text-xl text-slate-800">{p.label}</h3>
                                <div className="text-2xl font-black text-slate-900 mt-2">R$ {p.price.toFixed(2)}</div>
                                <div className="mt-4 space-y-1">
                                    {p.features?.map((f, i) => <div key={i} className="text-xs text-slate-500 flex items-center gap-1"><CheckCircle size={10} className="text-green-500"/> {f}</div>)}
                                </div>
                            </div>
                        ))}
                    </div>
                    {editingPackage && (
                        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
                            <div className="bg-white p-8 rounded-2xl w-full max-w-md space-y-4 shadow-2xl">
                                <h3 className="font-bold text-xl text-slate-800">Editar Plano</h3>
                                <div className="space-y-3">
                                    <input className="w-full p-3 border rounded-xl" placeholder="Nome do Pacote" value={editingPackage.label} onChange={e=>setEditingPackage({...editingPackage, label: e.target.value})}/>
                                    <div className="grid grid-cols-2 gap-3">
                                        <input className="w-full p-3 border rounded-xl" type="number" placeholder="Preço (R$)" value={editingPackage.price} onChange={e=>setEditingPackage({...editingPackage, price: parseFloat(e.target.value)})}/>
                                        <input className="w-full p-3 border rounded-xl" type="number" placeholder="Qtd. Créditos" value={editingPackage.credits} onChange={e=>setEditingPackage({...editingPackage, credits: parseInt(e.target.value)})}/>
                                    </div>
                                    <textarea className="w-full p-3 border rounded-xl text-sm" placeholder="Descrição" value={editingPackage.description} onChange={e=>setEditingPackage({...editingPackage, description: e.target.value})} />
                                </div>
                                <div className="flex gap-3 pt-2">
                                    <button onClick={()=>setEditingPackage(null)} className="flex-1 bg-slate-100 text-slate-600 p-3 rounded-xl font-bold hover:bg-slate-200">Cancelar</button>
                                    <button onClick={handleSavePackage} className="flex-1 bg-blue-600 text-white p-3 rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-200">Salvar Plano</button>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            )}

            {activeTab === 'users' && (
                <div className="space-y-6 animate-fade-in pb-20">
                    <div className="flex justify-between items-center flex-wrap gap-4">
                        <h1 className="text-2xl font-bold text-slate-800">Gestão de Usuários</h1>
                        <div className="relative">
                            <input 
                                className="pl-10 pr-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500 outline-none text-sm w-64"
                                placeholder="Buscar por nome ou email..."
                                value={userSearch}
                                onChange={e => setUserSearch(e.target.value)}
                            />
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                        </div>
                    </div>

                    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                        {loading ? (
                            <div className="p-10 flex justify-center"><Loader2 className="animate-spin text-blue-600"/></div>
                        ) : (
                            <table className="w-full">
                                <thead className="bg-slate-50 text-left border-b border-slate-200">
                                    <tr>
                                        <th className="p-4 font-bold text-slate-600 text-xs uppercase tracking-wider">Usuário</th>
                                        <th className="p-4 font-bold text-slate-600 text-xs uppercase tracking-wider">Tipo de Conta</th>
                                        <th className="p-4 font-bold text-slate-600 text-xs uppercase tracking-wider">Saldo de Créditos</th>
                                        <th className="p-4 font-bold text-slate-600 text-xs uppercase tracking-wider">Frequência</th>
                                        <th className="p-4 font-bold text-slate-600 text-xs uppercase tracking-wider text-right">Ações</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                    {filteredUsers.map(u => (
                                        <tr key={u.id} className={`hover:bg-slate-50 transition-colors ${u.is_blocked ? 'bg-red-50/50' : ''}`}>
                                            <td className="p-4">
                                                <div className="flex items-center gap-3">
                                                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white ${u.is_blocked ? 'bg-red-400' : 'bg-blue-50'}`}>
                                                        {u.full_name ? u.full_name.charAt(0).toUpperCase() : <Users size={18}/>}
                                                    </div>
                                                    <div>
                                                        <p className={`font-bold text-sm ${u.is_blocked ? 'text-red-600' : 'text-slate-800'}`}>
                                                            {u.full_name || 'Sem Nome'}
                                                        </p>
                                                        <p className="text-xs text-slate-500">{u.email}</p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="p-4">
                                                {u.is_root ? (
                                                    <span className="inline-flex items-center gap-1 bg-red-100 text-red-700 px-2 py-1 rounded text-xs font-bold"><Shield size={12}/> ROOT</span>
                                                ) : u.is_admin ? (
                                                    <span className="inline-flex items-center gap-1 bg-purple-100 text-purple-700 px-2 py-1 rounded text-xs font-bold"><Shield size={12}/> ADMIN</span>
                                                ) : u.is_fleet_manager ? (
                                                    <span className="inline-flex items-center gap-1 bg-indigo-100 text-indigo-700 px-2 py-1 rounded text-xs font-bold"><Briefcase size={12}/> FROTA</span>
                                                ) : (
                                                    <span className="inline-flex items-center gap-1 bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs font-bold"><Truck size={12}/> MOTORISTA</span>
                                                )}
                                            </td>
                                            <td className="p-4">
                                                <div className="flex flex-col gap-1">
                                                    <span className="text-xs font-bold text-slate-700 flex items-center gap-1"><span className="w-2 h-2 bg-blue-500 rounded-full"></span> {u.credits} Grátis</span>
                                                    <span className="text-xs font-bold text-amber-600 flex items-center gap-1"><span className="w-2 h-2 bg-amber-500 rounded-full"></span> {u.premium_credits} Premium</span>
                                                </div>
                                            </td>
                                            <td className="p-4">
                                                <div className="text-xs text-slate-500 space-y-1">
                                                    <p className="flex items-center gap-1"><Calendar size={12}/> Criado: {new Date(u.created_at).toLocaleDateString()}</p>
                                                </div>
                                            </td>
                                            <td className="p-4 text-right">
                                                <div className="flex justify-end gap-2">
                                                    <button 
                                                        onClick={() => setEditUserModal(u)}
                                                        className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                                                        title="Editar Dados Completos"
                                                    >
                                                        <Edit2 size={18}/>
                                                    </button>
                                                    <button 
                                                        onClick={() => initPasswordReset(u)}
                                                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                                                        title="Redefinir Senha"
                                                    >
                                                        <KeyRound size={18}/>
                                                    </button>
                                                    <button 
                                                        onClick={() => toggleBlockUser(u)}
                                                        className={`p-2 rounded-lg transition-colors ${u.is_blocked ? 'text-green-600 hover:bg-green-50' : 'text-red-400 hover:bg-red-50 hover:text-red-600'}`}
                                                        title={u.is_blocked ? "Desbloquear" : "Bloquear"}
                                                    >
                                                        {u.is_blocked ? <UserCheck size={18}/> : <Ban size={18}/>}
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                    {filteredUsers.length === 0 && (
                                        <tr>
                                            <td colSpan={5} className="p-8 text-center text-slate-400">Nenhum usuário encontrado.</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        )}
                    </div>

                    {/* Password Reset Modal */}
                    {resetModalUser && (
                        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
                            <div className="bg-white p-8 rounded-2xl w-full max-w-sm shadow-2xl text-center space-y-6">
                                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto text-blue-600 mb-4">
                                    <KeyRound size={32}/>
                                </div>
                                <div>
                                    <h3 className="text-xl font-black text-slate-900">Refazer Senha</h3>
                                    <p className="text-sm text-slate-500 mt-2">
                                        Será gerada uma nova senha para <strong>{resetModalUser.full_name}</strong> e enviada via Email.
                                    </p>
                                </div>
                                
                                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                                    <p className="text-xs uppercase font-bold text-slate-400 mb-1">Nova Senha Temporária</p>
                                    <p className="text-2xl font-mono font-bold text-slate-800 tracking-widest select-all">{tempPassword}</p>
                                </div>

                                <div className="flex flex-col gap-3">
                                    <button 
                                        onClick={confirmPasswordReset}
                                        className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 rounded-xl shadow-lg transition-transform active:scale-[0.98] flex items-center justify-center gap-2"
                                    >
                                        <MessageCircle size={20}/> Confirmar e Enviar
                                    </button>
                                    <button 
                                        onClick={() => setResetModalUser(null)}
                                        className="w-full text-slate-500 font-bold py-3 hover:text-slate-800"
                                    >
                                        Cancelar
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* EDIT USER FULL MODAL */}
                    {editUserModal && (
                        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
                            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
                                <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                                    <div>
                                        <h3 className="font-bold text-xl text-slate-800">Editar Perfil</h3>
                                        <p className="text-sm text-slate-500">ID: {editUserModal.id.substring(0, 8)}...</p>
                                    </div>
                                    <button onClick={() => setEditUserModal(null)} className="text-slate-400 hover:text-slate-600 p-1"><X/></button>
                                </div>
                                
                                <div className="p-6 space-y-6 overflow-y-auto">
                                    <div className="space-y-4">
                                        <h4 className="font-bold text-sm text-slate-400 uppercase tracking-wide">Dados Básicos</h4>
                                        <div className="grid grid-cols-2 gap-4">
                                            <div className="col-span-2">
                                                <label className="block text-xs font-bold text-slate-500 mb-1">Nome Completo</label>
                                                <input 
                                                    className="w-full p-3 border rounded-xl bg-white" 
                                                    value={editUserModal.full_name || ''}
                                                    onChange={e => setEditUserModal({...editUserModal, full_name: e.target.value})}
                                                />
                                            </div>
                                            <div className="col-span-2">
                                                <label className="block text-xs font-bold text-slate-500 mb-1">Email (Somente Leitura)</label>
                                                <input 
                                                    className="w-full p-3 border rounded-xl bg-slate-100 text-slate-500" 
                                                    value={editUserModal.email}
                                                    disabled
                                                />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="space-y-4 pt-4 border-t border-slate-100">
                                        <h4 className="font-bold text-sm text-amber-600 uppercase tracking-wide flex items-center gap-2"><Coins size={14}/> Gestão de Créditos</h4>
                                        <div className="grid grid-cols-2 gap-4">
                                            <div>
                                                <label className="block text-xs font-bold text-slate-500 mb-1">Créditos Diários (Grátis)</label>
                                                <input 
                                                    type="number"
                                                    className="w-full p-3 border rounded-xl"
                                                    value={editUserModal.credits}
                                                    onChange={e => setEditUserModal({...editUserModal, credits: parseInt(e.target.value) || 0})}
                                                />
                                            </div>
                                            <div>
                                                <label className="block text-xs font-bold text-slate-500 mb-1">Créditos Premium (Pagos)</label>
                                                <input 
                                                    type="number"
                                                    className="w-full p-3 border rounded-xl bg-amber-50 border-amber-200"
                                                    value={editUserModal.premium_credits}
                                                    onChange={e => setEditUserModal({...editUserModal, premium_credits: parseInt(e.target.value) || 0})}
                                                />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="space-y-4 pt-4 border-t border-slate-100">
                                        <h4 className="font-bold text-sm text-purple-600 uppercase tracking-wide flex items-center gap-2"><Shield size={14}/> Permissões e Acesso</h4>
                                        <div className="space-y-2">
                                            <label className="flex items-center gap-3 p-3 border rounded-xl hover:bg-slate-50 cursor-pointer">
                                                <input type="checkbox" checked={!!editUserModal.is_fleet_manager} onChange={e => setEditUserModal({...editUserModal, is_fleet_manager: e.target.checked})} className="w-5 h-5 text-purple-600"/>
                                                <span className="font-bold text-slate-700">Gestor de Frota / Transportadora</span>
                                            </label>
                                            <label className="flex items-center gap-3 p-3 border rounded-xl hover:bg-slate-50 cursor-pointer">
                                                <input type="checkbox" checked={!!editUserModal.is_admin} onChange={e => setEditUserModal({...editUserModal, is_admin: e.target.checked})} className="w-5 h-5 text-purple-600"/>
                                                <span className="font-bold text-slate-700">Administrador do Sistema</span>
                                            </label>
                                            <label className="flex items-center gap-3 p-3 border border-red-200 bg-red-50 rounded-xl cursor-pointer">
                                                <input type="checkbox" checked={!!editUserModal.is_root} onChange={e => setEditUserModal({...editUserModal, is_root: e.target.checked})} className="w-5 h-5 text-red-600"/>
                                                <span className="font-bold text-red-700">Super Usuário (ROOT)</span>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div className="p-6 border-t border-slate-100 bg-slate-50 flex gap-3">
                                    <button onClick={() => setEditUserModal(null)} className="flex-1 py-3 text-slate-500 font-bold hover:text-slate-800 transition-colors">Cancelar</button>
                                    <button onClick={handleSaveUser} className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 shadow-lg transition-colors">Salvar Alterações</button>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            )}
        </main>
    </div>
  );
};

export default RootDashboard;