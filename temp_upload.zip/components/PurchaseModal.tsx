
import React, { useState, useEffect } from 'react';
import { X, Check, CreditCard, Coins, QrCode, Smartphone, Loader2, Lock, Zap, Star, Copy, ShieldCheck } from 'lucide-react';
import { DAILY_FREE_CREDITS } from '../constants';
import { processPayment, getCreditPackages } from '../services/dbService';
import { CreditPackage } from '../types';
import { getStoredUser } from '../services/authService';

interface PurchaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPurchase: (amount: number) => void;
}

type PaymentStep = 'select_package' | 'select_method' | 'processing' | 'success';

const PurchaseModal: React.FC<PurchaseModalProps> = ({ isOpen, onClose, onPurchase }) => {
  const [step, setStep] = useState<PaymentStep>('select_package');
  const [selectedPkg, setSelectedPkg] = useState<CreditPackage | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'PIX' | 'CREDIT_CARD'>('PIX');
  const [pixCopied, setPixCopied] = useState(false);
  
  // Fake Card State for UI
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  
  // State for dynamic packages
  const [packages, setPackages] = useState<CreditPackage[]>([]);
  const [loadingPackages, setLoadingPackages] = useState(true);

  // Load packages when modal opens
  useEffect(() => {
    if (isOpen) {
        setLoadingPackages(true);
        getCreditPackages().then(data => {
            setPackages(data);
            setLoadingPackages(false);
        });
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSelectPackage = (pkg: CreditPackage) => {
    setSelectedPkg(pkg);
    setStep('select_method');
  };

  const handleConfirmPayment = async () => {
    if (!selectedPkg) return;
    
    // Validate Card if Credit Card selected
    if (paymentMethod === 'CREDIT_CARD') {
        if (cardNumber.length < 13 || cardCvv.length < 3) {
            alert("Verifique os dados do cartão.");
            return;
        }
    }

    setStep('processing');
    
    // Simulate API call to Stripe or Mercado Pago
    // In production, this would call your Edge Function
    await new Promise(r => setTimeout(r, 2000));
    
    const user = getStoredUser();
    if (user && user.id) {
        await processPayment(selectedPkg.price, paymentMethod, user.id, user.email);
    }
    
    onPurchase(selectedPkg.credits);
    setStep('success');
    setTimeout(() => {
        handleClose();
    }, 2500);
  };

  const handleClose = () => {
    onClose();
    setTimeout(() => {
        setStep('select_package');
        setSelectedPkg(null);
        setCardNumber('');
        setCardName('');
        setCardExpiry('');
        setCardCvv('');
    }, 300);
  };

  const copyPixCode = () => {
      // Fake PIX code for demo
      const fakePix = "00020126580014br.gov.bcb.pix0136123e4567-e89b-12d3-a456-426614174000520400005303986540410.005802BR5913FRETE CERTO6009SAO PAULO62070503***6304E2CA";
      navigator.clipboard.writeText(fakePix);
      setPixCopied(true);
      setTimeout(() => setPixCopied(false), 2000);
  };

  const renderContent = () => {
    switch (step) {
        case 'select_package':
            return (
                <div className="space-y-6">
                     <div className="text-center mb-2">
                        <h2 className="text-2xl font-bold text-slate-900">Precisa de mais cálculos?</h2>
                        <p className="text-slate-500 text-sm mt-1">
                            Você tem {DAILY_FREE_CREDITS} créditos grátis todos os dias. <br/>
                            <span className="font-semibold text-slate-700">Se não for suficiente, veja nossos planos.</span>
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* FREE PLAN CARD (Always Static) */}
                        <div className="border-2 border-slate-200 rounded-2xl p-6 flex flex-col justify-between hover:border-slate-300 transition-colors bg-slate-50">
                            <div>
                                <div className="flex items-center gap-2 mb-2">
                                    <Zap className="text-blue-500 fill-blue-500" size={24} />
                                    <h3 className="font-bold text-lg text-slate-800">Grátis</h3>
                                </div>
                                <p className="text-3xl font-black text-slate-900 mb-1">R$ 0,00</p>
                                <p className="text-xs text-slate-500 uppercase tracking-wide font-bold mb-4">Para sempre</p>
                                
                                <ul className="space-y-3 text-sm text-slate-600 mb-6">
                                    <li className="flex items-start gap-2">
                                        <Check size={16} className="text-green-500 mt-0.5 shrink-0" />
                                        <span><strong>{DAILY_FREE_CREDITS} Créditos</strong> Diários</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                        <Check size={16} className="text-green-500 mt-0.5 shrink-0" />
                                        <span>Renova à meia-noite</span>
                                    </li>
                                </ul>
                            </div>
                            <button 
                                onClick={handleClose}
                                className="w-full py-3 rounded-xl border border-slate-300 font-bold text-slate-600 hover:bg-white hover:text-slate-800 transition-colors"
                            >
                                Manter Grátis
                            </button>
                        </div>

                        {/* DYNAMIC PACKAGES */}
                        {loadingPackages ? (
                            <div className="flex flex-col items-center justify-center p-6 border-2 border-slate-100 rounded-2xl">
                                <Loader2 className="animate-spin text-blue-500" />
                                <span className="text-xs text-slate-400 mt-2">Carregando planos...</span>
                            </div>
                        ) : packages.map(pkg => (
                            <div key={pkg.id} className={`border-2 rounded-2xl p-6 flex flex-col justify-between shadow-xl relative bg-white transform transition-transform md:hover:scale-105 ${pkg.is_recommended ? 'border-blue-600 shadow-blue-100' : 'border-slate-200 shadow-slate-100'}`}>
                                {pkg.is_recommended && (
                                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                                        Recomendado
                                    </div>
                                )}
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Star className={`fill-current ${pkg.is_recommended ? 'text-amber-400' : 'text-slate-300'}`} size={24} />
                                        <h3 className="font-bold text-lg text-slate-800">{pkg.label}</h3>
                                    </div>
                                    <p className="text-3xl font-black text-slate-900 mb-1">
                                        R$ {pkg.price.toFixed(2).replace('.',',')}
                                    </p>
                                    <p className="text-xs text-slate-500 uppercase tracking-wide font-bold mb-4">{pkg.credits} Créditos</p>
                                    
                                    <ul className="space-y-3 text-sm text-slate-600 mb-6">
                                        {pkg.features?.map((feat, i) => (
                                            <li key={i} className="flex items-start gap-2">
                                                <Check size={16} className="text-blue-600 mt-0.5 shrink-0" />
                                                <span>{feat}</span>
                                            </li>
                                        ))}
                                        {!pkg.features?.length && (
                                            <li className="flex items-start gap-2">
                                                <Check size={16} className="text-blue-600 mt-0.5 shrink-0" />
                                                <span>Pacote de {pkg.credits} créditos</span>
                                            </li>
                                        )}
                                    </ul>
                                </div>
                                <button 
                                    onClick={() => handleSelectPackage(pkg)}
                                    className={`w-full py-3 rounded-xl font-bold transition-transform active:scale-95 shadow-lg ${pkg.is_recommended ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-blue-200' : 'bg-slate-800 text-white hover:bg-black shadow-slate-200'}`}
                                >
                                    Comprar
                                </button>
                            </div>
                        ))}
                    </div>
                    
                    <p className="text-center text-xs text-slate-400 mt-4">
                        Cancele a qualquer momento. Sem fidelidade.
                    </p>
                </div>
            );

        case 'select_method':
            return (
                <div className="space-y-6 animate-fade-in">
                    <div className="text-center">
                         <h3 className="text-xl font-bold text-slate-900">Confirmar Compra</h3>
                         <p className="text-slate-500 text-sm mt-1">Pacote: <span className="font-bold">{selectedPkg?.label}</span></p>
                         <p className="text-blue-600 font-bold text-2xl mt-1">R$ {selectedPkg?.price.toFixed(2).replace('.', ',')}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <button 
                            onClick={() => setPaymentMethod('PIX')}
                            className={`p-4 rounded-xl border-2 flex flex-col items-center gap-2 transition-all ${paymentMethod === 'PIX' ? 'border-green-500 bg-green-50 text-green-700 ring-2 ring-green-200' : 'border-slate-200 hover:border-slate-300'}`}
                        >
                            <QrCode size={32} />
                            <span className="font-bold text-sm">PIX</span>
                            {paymentMethod === 'PIX' && <Check size={16} className="text-green-600" />}
                        </button>

                        <button 
                            onClick={() => setPaymentMethod('CREDIT_CARD')}
                            className={`p-4 rounded-xl border-2 flex flex-col items-center gap-2 transition-all ${paymentMethod === 'CREDIT_CARD' ? 'border-blue-500 bg-blue-50 text-blue-700 ring-2 ring-blue-200' : 'border-slate-200 hover:border-slate-300'}`}
                        >
                            <CreditCard size={32} />
                            <span className="font-bold text-sm">Cartão</span>
                            {paymentMethod === 'CREDIT_CARD' && <Check size={16} className="text-blue-600" />}
                        </button>
                    </div>

                    {paymentMethod === 'PIX' && (
                        <div className="bg-slate-50 p-6 rounded-2xl flex flex-col items-center gap-4 text-center border border-slate-200">
                            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                                <QrCode size={96} className="text-slate-900" />
                            </div>
                            <div className="text-sm text-slate-600 w-full">
                                <p className="font-bold text-slate-800 mb-1">Pague com PIX</p>
                                <p className="mb-4 text-xs">Aprovação imediata. Escaneie o QR Code ou use a chave abaixo.</p>
                                
                                <div className="flex gap-2">
                                    <input 
                                        type="text" 
                                        readOnly 
                                        value="00020126580014br.gov.bcb.pix0136123e4567-e89b-12d3..." 
                                        className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-500 outline-none"
                                    />
                                    <button 
                                        onClick={copyPixCode}
                                        className="bg-slate-200 hover:bg-slate-300 text-slate-700 p-2 rounded-lg transition-colors"
                                        title="Copiar Código"
                                    >
                                        {pixCopied ? <Check size={16} className="text-green-600"/> : <Copy size={16}/>}
                                    </button>
                                </div>
                                {pixCopied && <p className="text-[10px] text-green-600 font-bold mt-1">Código copiado!</p>}
                            </div>
                        </div>
                    )}

                    {paymentMethod === 'CREDIT_CARD' && (
                         <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 space-y-3">
                             <div className="flex justify-between items-center mb-2">
                                 <span className="text-xs font-bold text-slate-500 uppercase">Dados do Cartão</span>
                                 <div className="flex gap-1">
                                     <div className="w-6 h-4 bg-slate-200 rounded"></div>
                                     <div className="w-6 h-4 bg-slate-200 rounded"></div>
                                 </div>
                             </div>
                             
                             <input 
                                type="text" 
                                placeholder="Número do Cartão"
                                value={cardNumber}
                                onChange={(e) => setCardNumber(e.target.value.replace(/\D/g, '').slice(0, 16))}
                                className="w-full px-3 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                             />
                             
                             <div className="grid grid-cols-2 gap-3">
                                 <input 
                                    type="text" 
                                    placeholder="Validade (MM/AA)"
                                    value={cardExpiry}
                                    onChange={(e) => setCardExpiry(e.target.value)}
                                    className="w-full px-3 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                                 />
                                 <input 
                                    type="text" 
                                    placeholder="CVV"
                                    maxLength={4}
                                    value={cardCvv}
                                    onChange={(e) => setCardCvv(e.target.value)}
                                    className="w-full px-3 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                                 />
                             </div>
                             
                             <input 
                                type="text" 
                                placeholder="Nome Impresso no Cartão"
                                value={cardName}
                                onChange={(e) => setCardName(e.target.value.toUpperCase())}
                                className="w-full px-3 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                             />
                         </div>
                    )}

                    <button 
                        onClick={handleConfirmPayment}
                        className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-4 rounded-xl shadow-lg transition-transform active:scale-[0.98] flex items-center justify-center gap-2"
                    >
                        <ShieldCheck size={20} />
                        Pagar R$ {selectedPkg?.price.toFixed(2).replace('.', ',')}
                    </button>
                    
                    <button onClick={() => setStep('select_package')} className="w-full text-slate-500 text-sm font-medium hover:text-slate-700">
                        Voltar
                    </button>
                </div>
            );

        case 'processing':
            return (
                <div className="flex flex-col items-center justify-center py-10 animate-fade-in text-center">
                    <div className="relative mb-6">
                        <div className="absolute inset-0 bg-blue-200 rounded-full animate-ping opacity-25"></div>
                        <div className="bg-blue-100 p-4 rounded-full relative z-10">
                            <Loader2 size={48} className="text-blue-600 animate-spin" />
                        </div>
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 mb-2">Processando Pagamento...</h3>
                    <p className="text-slate-500">Estamos validando a transação.</p>
                </div>
            );

        case 'success':
            return (
                <div className="flex flex-col items-center justify-center py-10 animate-fade-in text-center">
                    <div className="bg-green-100 p-4 rounded-full mb-6 animate-bounce">
                        <Check size={48} className="text-green-600" />
                    </div>
                    <h3 className="text-2xl font-bold text-green-700 mb-2">Pagamento Confirmado!</h3>
                    <p className="text-slate-600">Seus créditos já estão disponíveis para uso.</p>
                </div>
            );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-3xl overflow-hidden relative max-h-[90vh] overflow-y-auto">
        <button 
            onClick={handleClose}
            className="absolute top-4 right-4 p-2 bg-slate-100 hover:bg-slate-200 rounded-full text-slate-600 transition-colors z-20"
        >
            <X size={20} />
        </button>

        <div className="p-8">
            {renderContent()}
        </div>

        <div className="p-4 text-center border-t border-slate-100 bg-slate-50">
             <p className="text-[10px] text-slate-400 flex items-center justify-center gap-1">
                <Lock size={10} /> Ambiente Seguro • Mercado Pago & Stripe
             </p>
        </div>
      </div>
    </div>
  );
};

export default PurchaseModal;
