
import React from 'react';
import { RouteData, RoutePoint, VehicleData } from '../types';
import SpeechInput from './SpeechInput';
import { Plus, MapPin, DollarSign, ArrowDown, Trash2, Package, Truck, ArrowRight, Calculator, FileCheck, ArrowLeft, Scale, AlertTriangle } from 'lucide-react';

interface RoutePlannerProps {
  step: 'pickup' | 'delivery';
  data: RouteData;
  vehicle: VehicleData; // Needed for cargo capacity calculation
  onUpdate: (data: RouteData) => void;
  onNext: () => void;
  onBack: () => void;
  onAnalyze: () => void;
  isLoading: boolean;
}

const RoutePlanner: React.FC<RoutePlannerProps> = ({ step, data, vehicle, onUpdate, onNext, onBack, onAnalyze, isLoading }) => {
  
  // Calculate total weight used so far
  const totalWeightUsed = data.pickups.reduce((sum, p) => sum + (p.weight || 0), 0);
  const maxCapacity = vehicle.cargoCapacity || 1;
  const isOverweight = totalWeightUsed > maxCapacity;
  const remainingCapacity = maxCapacity - totalWeightUsed;

  const updatePoint = (listType: 'pickups' | 'deliveries', id: string, field: keyof RoutePoint, value: any) => {
    const newList = data[listType].map(p => {
      if (p.id === id) {
        return { ...p, [field]: value };
      }
      return p;
    });
    onUpdate({ ...data, [listType]: newList });
  };

  // Robust parser
  const parseNum = (value: string): number => {
      let clean = value.trim();
      if (clean.includes(',')) {
          clean = clean.replace(/\./g, '').replace(',', '.');
      } else if ((clean.match(/\./g) || []).length > 1) {
          clean = clean.replace(/\./g, '');
      }
      const numValue = parseFloat(clean);
      return isNaN(numValue) ? 0 : numValue;
  };

  const handleNumericUpdate = (listType: 'pickups' | 'deliveries', id: string, field: 'value' | 'weight', value: string) => {
    updatePoint(listType, id, field, parseNum(value));
  };

  // When Weight changes: Recalculate Total Value based on existing Price/Ton
  const handleWeightChange = (id: string, weightStr: string) => {
    const weight = parseNum(weightStr);
    
    // Find current point to get current value
    const point = data.pickups.find(p => p.id === id);
    if (!point) return;

    let newValue = point.value;
    if (point.weight && point.weight > 0 && point.value > 0) {
        const pricePerTon = point.value / point.weight;
        newValue = pricePerTon * weight;
    }

    // Update both
    const newList = data.pickups.map(p => {
        if (p.id === id) {
            return { ...p, weight: weight, value: newValue };
        }
        return p;
    });
    onUpdate({ ...data, pickups: newList });
  };

  // When Price Per Ton changes: Update Total Value (Value = Weight * PricePerTon)
  const handlePerTonUpdate = (id: string, perTonValue: string) => {
    const pricePerTon = parseNum(perTonValue);
    
    const point = data.pickups.find(p => p.id === id);
    if (!point) return;

    const weight = point.weight || 0;

    if (!isNaN(pricePerTon)) {
        const totalFreight = pricePerTon * weight;
        updatePoint('pickups', id, 'value', totalFreight);
    }
  };

  // When Total Value changes: Just update Value (Price/Ton is derived visually)
  const handleTotalValueUpdate = (id: string, totalValueStr: string) => {
      handleNumericUpdate('pickups', id, 'value', totalValueStr);
  };

  const addPoint = (listType: 'pickups' | 'deliveries') => {
    const newPoint: RoutePoint = {
      id: Math.random().toString(36).substr(2, 9),
      type: listType === 'pickups' ? 'pickup' : 'delivery',
      address: '',
      value: 0,
      weight: 0 // Initialize weight
    };
    onUpdate({ ...data, [listType]: [...data[listType], newPoint] });
  };

  const removePoint = (listType: 'pickups' | 'deliveries', id: string) => {
    if (data[listType].length <= 1 && listType === 'pickups') return; // Keep at least one start
    const newList = data[listType].filter(p => p.id !== id);
    onUpdate({ ...data, [listType]: newList });
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 md:space-y-8 pb-48">
      
      {/* Pickups Section */}
      {step === 'pickup' && (
        <section className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="bg-green-50 p-4 md:p-6 border-l-8 border-green-600">
                <div className="flex justify-between items-start">
                    <div>
                        <h2 className="text-xl md:text-2xl font-bold text-green-900 flex items-center gap-3">
                        <div className="bg-green-600 text-white p-2 rounded-lg"><Package size={20} className="md:w-6 md:h-6" /></div>
                        Carregamento e Carga
                        </h2>
                        <p className="text-green-800 text-sm md:text-lg mt-1 font-medium opacity-80">Distribua a carga entre os pontos.</p>
                    </div>
                </div>
            </div>

            <div className="space-y-4 md:space-y-6 p-4 md:pb-6">
                {data.pickups.map((point, index) => {
                    // Calculate display value for Per Ton derived from Total / specific Weight
                    const currentTotal = point.value || 0;
                    const currentWeight = point.weight || 0;
                    
                    const calculatedPerTon = (currentTotal > 0 && currentWeight > 0) 
                        ? (currentTotal / currentWeight).toFixed(2).replace('.', ',')
                        : '';

                    return (
                    <div key={point.id} className="bg-gray-50 p-4 md:p-6 rounded-2xl border-2 border-gray-200 transition-all hover:border-green-300 hover:shadow-md">
                        
                        {/* Card Header: Index & Remove Action */}
                        <div className="flex items-center justify-between mb-4">
                            <div className="bg-green-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold border-2 border-green-700 shadow-sm">
                                {index + 1}
                            </div>
                            {data.pickups.length > 1 && (
                                <button 
                                    onClick={() => removePoint('pickups', point.id)}
                                    className="bg-red-100 text-red-600 p-2 rounded-lg hover:bg-red-200 transition-colors flex items-center gap-1 text-sm font-semibold"
                                    title="Remover este ponto"
                                >
                                    <Trash2 size={18} /> <span className="hidden xs:inline">Remover</span>
                                </button>
                            )}
                        </div>

                        <div className="space-y-4">
                            <SpeechInput
                                label="Endereço de Coleta"
                                value={point.address}
                                onChange={(v) => updatePoint('pickups', point.id, 'address', v)}
                                placeholder="Ex: Fazenda Santa Luzia, MT"
                            />
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                {/* Weight Field */}
                                <SpeechInput
                                    label="Peso (Ton)"
                                    prefix="Ton"
                                    type="number"
                                    value={point.weight || ''}
                                    onChange={(v) => handleWeightChange(point.id, v)}
                                    placeholder="0"
                                    className="md:col-span-1"
                                />

                                {/* Price Per Ton Field */}
                                <div className="relative md:col-span-1">
                                     {point.weight && point.weight > 0 ? (
                                        <SpeechInput
                                            label="Valor por Ton"
                                            prefix="R$"
                                            type="number"
                                            value={calculatedPerTon === '0,00' ? '' : calculatedPerTon}
                                            onChange={(v) => handlePerTonUpdate(point.id, v)}
                                            placeholder="0,00"
                                        />
                                     ) : (
                                         <div className="opacity-50 cursor-not-allowed">
                                            <label className="text-base md:text-lg font-semibold text-gray-500">Valor por Ton</label>
                                            <div className="mt-1 p-3 border-2 border-gray-200 rounded-xl bg-gray-100 text-gray-400 text-xs">
                                                Informe o peso primeiro.
                                            </div>
                                         </div>
                                     )}
                                </div>

                                {/* Total Freight Field */}
                                <SpeechInput
                                    label="Valor Total"
                                    prefix="R$"
                                    type="number"
                                    value={point.value || ''}
                                    onChange={(v) => handleTotalValueUpdate(point.id, v)}
                                    placeholder="0,00"
                                    className="md:col-span-1"
                                />
                            </div>
                        </div>
                    </div>
                )})}
                
                <button
                onClick={() => addPoint('pickups')}
                className="w-full py-3 md:py-4 border-2 border-dashed border-green-300 bg-green-50 rounded-xl text-green-700 hover:bg-green-100 hover:border-green-400 font-bold text-base md:text-lg transition-all flex items-center justify-center gap-2"
                >
                <Plus size={20} className="md:w-6 md:h-6" /> Adicionar coleta
                </button>
            </div>
        </section>
      )}

      {/* Deliveries Section */}
      {step === 'delivery' && (
        <section className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden animate-fade-in">
            <div className="bg-blue-50 p-4 md:p-6 border-l-8 border-blue-600">
                <h2 className="text-xl md:text-2xl font-bold text-blue-900 flex items-center gap-3">
                <div className="bg-blue-600 text-white p-2 rounded-lg"><Truck size={20} className="md:w-6 md:h-6" /></div>
                Entrega
                </h2>
                <p className="text-blue-800 text-sm md:text-lg mt-1 font-medium opacity-80">Onde você vai deixar a carga?</p>
            </div>

            <div className="space-y-4 md:space-y-6 p-4 md:pb-6">
                {data.deliveries.map((point, index) => (
                <div key={point.id} className="bg-gray-50 p-4 md:p-6 rounded-2xl border-2 border-gray-200 transition-all hover:border-blue-300 hover:shadow-md">
                    
                    {/* Card Header: Index & Remove Action */}
                    <div className="flex items-center justify-between mb-4">
                        <div className="bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold border-2 border-blue-700 shadow-sm">
                            {index + 1}
                        </div>
                        {data.deliveries.length > 1 && (
                            <button 
                                onClick={() => removePoint('deliveries', point.id)}
                                className="bg-red-100 text-red-600 p-2 rounded-lg hover:bg-red-200 transition-colors flex items-center gap-1 text-sm font-semibold"
                                title="Remover este ponto"
                            >
                                <Trash2 size={18} /> <span className="hidden xs:inline">Remover</span>
                            </button>
                        )}
                    </div>

                    <div className="grid grid-cols-1 gap-4 md:gap-6">
                        <SpeechInput
                            label="Endereço de Entrega"
                            value={point.address}
                            onChange={(v) => updatePoint('deliveries', point.id, 'address', v)}
                            placeholder="Ex: Porto de Santos, SP"
                        />
                        <SpeechInput
                            label="Custo/Valor Adicional"
                            prefix="R$"
                            type="number"
                            value={point.value || ''}
                            onChange={(v) => handleNumericUpdate('deliveries', point.id, 'value', v)}
                            placeholder="0,00"
                        />
                    </div>
                </div>
                ))}

                <button
                onClick={() => addPoint('deliveries')}
                className="w-full py-3 md:py-4 border-2 border-dashed border-blue-300 bg-blue-50 rounded-xl text-blue-700 hover:bg-blue-100 hover:border-blue-400 font-bold text-base md:text-lg transition-all flex items-center justify-center gap-2"
                >
                <Plus size={20} className="md:w-6 md:h-6" /> Adicionar entrega
                </button>
            </div>
        </section>
      )}

      {/* Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-sm border-t border-gray-200 z-50 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)]">
        
        {/* Capacity Progress Bar - Moved to Bottom Fixed Area */}
        {step === 'pickup' && vehicle.cargoCapacity > 0 && (
            <div className="max-w-3xl mx-auto pt-3 px-4">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <div className="flex justify-between text-xs font-bold mb-1.5">
                        <span className="text-slate-700 flex items-center gap-1"><Scale size={14}/> Capacidade Utilizada</span>
                        <span className={`${isOverweight ? 'text-red-600' : 'text-green-700'}`}>
                            {totalWeightUsed} / {maxCapacity} Ton
                        </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                        <div 
                            className={`h-full transition-all duration-500 rounded-full ${isOverweight ? 'bg-red-500 stripe-animate' : 'bg-green-500'}`}
                            style={{ width: `${Math.min((totalWeightUsed / maxCapacity) * 100, 100)}%` }}
                        ></div>
                    </div>
                    {isOverweight && (
                        <div className="flex items-center gap-2 mt-2 text-red-600 font-bold text-xs animate-pulse">
                            <AlertTriangle size={14} />
                            Excesso de {(totalWeightUsed - maxCapacity).toFixed(1)} toneladas!
                        </div>
                    )}
                    {!isOverweight && remainingCapacity > 0 && (
                        <p className="text-[10px] text-green-700 mt-1 font-medium text-right">
                            Disponível: {remainingCapacity.toFixed(1)} ton
                        </p>
                    )}
                </div>
            </div>
        )}

        <div className="max-w-3xl mx-auto flex gap-4 p-4">
            <button
               onClick={onBack}
               className="px-6 py-4 rounded-xl border-2 border-slate-200 text-slate-600 font-bold text-lg hover:bg-slate-50 transition-colors flex items-center justify-center"
            >
               <ArrowLeft size={24} />
            </button>
          
          {step === 'pickup' ? (
             <button
               onClick={onNext}
               disabled={isOverweight}
               className={`flex-1 font-bold py-4 md:py-5 rounded-xl md:rounded-2xl shadow-xl flex items-center justify-center gap-3 text-lg md:text-xl transition-all active:scale-[0.98] ${
                   isOverweight 
                   ? 'bg-slate-300 text-slate-500 cursor-not-allowed' 
                   : 'bg-blue-600 hover:bg-blue-700 text-white'
               }`}
             >
               {isOverweight ? 'Excesso de Peso!' : <>Continuar para Entrega <ArrowRight size={24} /></>}
             </button>
          ) : (
             <button
                onClick={onNext} 
                className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 md:py-5 rounded-xl md:rounded-2xl shadow-xl flex items-center justify-center gap-3 text-lg md:text-xl transition-all active:scale-[0.98]"
             >
                <FileCheck size={24} /> REVISAR DADOS
             </button>
          )}
        </div>
      </div>

    </div>
  );
};

export default RoutePlanner;
