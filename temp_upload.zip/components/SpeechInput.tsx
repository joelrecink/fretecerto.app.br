
import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff } from 'lucide-react';

interface SpeechInputProps {
  label: string;
  value: string | number;
  onChange: (value: string) => void;
  type?: 'text' | 'number';
  placeholder?: string;
  className?: string;
  prefix?: string;
}

const SpeechInput: React.FC<SpeechInputProps> = ({
  label,
  value,
  onChange,
  type = 'text',
  placeholder,
  className = '',
  prefix,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [inputValue, setInputValue] = useState<string>(value.toString());
  const [recognition, setRecognition] = useState<any>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync internal state with prop value
  useEffect(() => {
    const stringVal = value === 0 && inputValue === '' ? '' : value.toString();
    
    if (type === 'number') {
        const currentFloat = parseFloat(inputValue.replace(',', '.'));
        const newFloat = parseFloat(stringVal);
        
        if (currentFloat !== newFloat && !isNaN(newFloat)) {
           setInputValue(stringVal);
        }
    } else {
        if (inputValue !== stringVal) {
            setInputValue(stringVal);
        }
    }
  }, [value, type]);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = false;
      recognitionInstance.lang = 'pt-BR';
      recognitionInstance.interimResults = false;

      recognitionInstance.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        
        if (type === 'number') {
           let cleaned = transcript.replace(/[^\d.,]/g, '');
           if (cleaned.includes(',')) {
             cleaned = cleaned.replace(/\./g, '');
             cleaned = cleaned.replace(',', '.');
           } else if ((cleaned.match(/\./g) || []).length > 1) {
             cleaned = cleaned.replace(/\./g, '');
           }
           
           onChange(cleaned);
           setInputValue(cleaned);
        } else {
           onChange(transcript);
           setInputValue(transcript);
        }
        setIsListening(false);
      };

      recognitionInstance.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        setIsListening(false);
      };

      recognitionInstance.onend = () => {
        setIsListening(false);
      };

      setRecognition(recognitionInstance);
    }
  }, [onChange, type]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVal = e.target.value;
    setInputValue(newVal);
    
    if (type === 'number') {
        if (/^[0-9.,]*$/.test(newVal)) {
            const normalized = newVal.replace(',', '.');
            onChange(normalized);
        }
    } else {
        onChange(newVal);
    }
  };

  const toggleListening = () => {
    if (!recognition) {
      alert("Navegador não suporta reconhecimento de voz.");
      return;
    }

    if (isListening) {
      recognition.stop();
    } else {
      recognition.start();
      setIsListening(true);
    }
  };

  return (
    <div className={`flex flex-col gap-1 md:gap-2 ${className}`}>
      <label className="text-base md:text-lg font-bold text-slate-700">{label}</label>
      <div className="relative group">
        {prefix && (
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-base md:text-lg font-medium z-10 pointer-events-none select-none">
                {prefix}
            </div>
        )}
        <input
          ref={inputRef}
          type="text"
          inputMode={type === 'number' ? 'decimal' : 'text'}
          value={inputValue}
          onChange={handleInputChange}
          placeholder={placeholder}
          className={`w-full ${prefix ? 'pl-12' : 'pl-4'} pr-12 md:pr-14 py-3 md:py-4 text-lg border border-slate-300 bg-white text-slate-900 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all shadow-sm placeholder-slate-400 hover:border-slate-400`}
        />
        <button
          type="button"
          onClick={toggleListening}
          className={`absolute right-2 md:right-3 top-1/2 -translate-y-1/2 p-2 md:p-3 rounded-full transition-colors ${
            isListening ? 'bg-red-100 text-red-600 animate-pulse' : 'text-slate-400 hover:text-blue-600 hover:bg-slate-100'
          }`}
          title="Falar para preencher"
        >
          {isListening ? <MicOff size={20} className="md:w-6 md:h-6" /> : <Mic size={20} className="md:w-6 md:h-6" />}
        </button>
      </div>
    </div>
  );
};

export default SpeechInput;
