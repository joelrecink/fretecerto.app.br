
import React, { useState, useEffect } from 'react';
import { VehicleData, SavedVehicle, MaintenanceLog } from '../types';
import SpeechInput from './SpeechInput';
import { Truck, Wrench, Save, Droplet, ArrowLeft, ArrowRight, CheckCircle, Loader2, Calendar, MapPin, History, X, Disc, Search, PlusCircle, Signal, DollarSign, Calculator, Receipt, Shield, Briefcase, FileCheck, CircleDashed, Circle, AlertTriangle, ShoppingCart, Tag, Store, CalendarDays, Layers, Filter, RefreshCw } from 'lucide-react';
import Logo from './Logo';
import { saveNewVehicle, getUserVehicles, addMaintenanceLog, getMaintenanceHistory, getStoredUser } from '../services/authService';
import { syncVehicleTelemetry } from '../services/telemetryService';
import { getFipeBrands, getFipeModels, getFipeYears, getFipePrice, parseFipeValue, FipeBrand, FipeModel, FipeYear } from '../services/fipeService';
import { addFinancialRecord } from '../services/dbService';

interface VehicleCostsProps {
  data: VehicleData;
  onUpdate: (data: VehicleData) => void;
  onNext: () => void;
  onBack: () => void;
  onLogin?: () => void; // Added for redirection
}

const VehicleCosts: React.FC<VehicleCostsProps> = ({ data, onUpdate, onNext, onBack, onLogin }) => {
  const [loading, setLoading] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [savedVehicles, setSavedVehicles] = useState<SavedVehicle[]>([]);
  const [showVehicleList, setShowVehicleList] = useState(false);
  
  // Tire Purchase Logic
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);
  const [purchaseType, setPurchaseType] = useState<'new' | 'remold'>('new');
  const [purchaseLoading, setPurchaseLoading] = useState(false);
  const [purchaseQty, setPurchaseQty] = useState<string>('0');
  const [purchasePrice, setPurchasePrice] = useState<string>('0');
  const [purchaseSupplier, setPurchaseSupplier] = useState<string>('');
  const [purchaseDate, setPurchaseDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // General Maintenance Logic (Oil/Filters)
  const [showMaintModal, setShowMaintModal] = useState(false);
  const [maintType, setMaintType] = useState<'ENGINE_OIL' | 'TRANS_OIL' | 'FILTERS' | null>(null);
  const [maintLoading, setMaintLoading] = useState(false);
  const [maintCost, setMaintCost] = useState<string>('0');
  const [maintKm, setMaintKm] = useState<string>('0');
  const [maintDate, setMaintDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [maintLocation, setMaintLocation] = useState<string>('');
  
  // Validation State
  const [plateError, setPlateError] = useState(false);

  // Real-time calculated metrics
  const [dailyFixedCost, setDailyFixedCost] = useState(0);
  const [variableCostPerKm, setVariableCostPerKm] = useState(0);
  const [costBreakdown, setCostBreakdown] = useState({ tires: 0, maintenance: 0 });

  // FIPE Modal State
  const [showFipeModal, setShowFipeModal] = useState(false);
  const [fipeLoading, setFipeLoading] = useState(false);
  const [fipeStep, setFipeStep] = useState<'brand' | 'model' | 'year' | 'result'>('brand');
  const [brands, setBrands] = useState<FipeBrand[]>([]);
  const [models, setModels] = useState<FipeModel[]>([]);
  const [years, setYears] = useState<FipeYear[]>([]);
  const [selectedBrand, setSelectedBrand] = useState<FipeBrand | null>(null);
  const [selectedModel, setSelectedModel] = useState<FipeModel | null>(null);
  const [fipeResult, setFipeResult] = useState<{ priceStr: string; value: number } | null>(null);

  useEffect(() => {
    loadVehicles();
    if (data.licensePlate) {
        setPlateError(false);
    }
  }, [data.licensePlate]);

  // Recalculate Dashboard metrics whenever relevant data changes
  useEffect(() => {
      calculateMetrics();
  }, [data]);

  // Helper to safely parse numbers from various formats (e.g. "3.500,00" or 3500)
  const safeFloat = (val: any): number => {
      if (typeof val === 'number') return val;
      if (!val) return 0;
      if (typeof val === 'string') {
          let clean = val.trim();
          // If input has comma, assume Brazilian format (1.000,00): Remove dots, replace comma with dot
          if (clean.includes(',')) {
              clean = clean.replace(/\./g, '').replace(',', '.');
          } 
          // If it has multiple dots (1.000.000), it's likely thousands separators without comma
          else if ((clean.match(/\./g) || []).length > 1) {
              clean = clean.replace(/\./g, '');
          }
          
          const parsed = parseFloat(clean);
          return isNaN(parsed) ? 0 : parsed;
      }
      return 0;
  };

  const calculateMetrics = () => {
      // 1. Calculate Daily Fixed Costs
      const assetValue = safeFloat(data.assetValue);
      const depreciationRate = safeFloat(data.annualDepreciationRate) || 15;
      const yearlyDepreciation = assetValue * (depreciationRate / 100);
      
      let monthlySalary = safeFloat(data.driverSalaryMonthly);
      let annualSalary = monthlySalary * 12;
      if (data.driverSalaryInclude13th) {
          annualSalary += monthlySalary;
      }
      
      const insuranceYearly = safeFloat(data.insuranceYearly);
      const registrationYearly = safeFloat(data.registrationYearly);

      const yearlyFixed = 
        yearlyDepreciation + 
        annualSalary +
        insuranceYearly + 
        registrationYearly;

      setDailyFixedCost(yearlyFixed / 365);

      // 2. Calculate Variable Cost per KM (MAINTENANCE ONLY - NO FUEL)
      let totalTireCostPerKm = 0;
      
      const priceNew = safeFloat(data.refTirePriceNew) || 0;
      const lifeNew = safeFloat(data.refTireLifespanNew) || 1;
      
      const priceRemold = safeFloat(data.refTirePriceRemold) || 0;
      const lifeRemold = safeFloat(data.refTireLifespanRemold) || 1;

      // Function to get per-axle cost/km based on mix
      const getAxleCost = (qtyNewRaw: any, qtyRemoldRaw: any) => {
          const qtyNew = safeFloat(qtyNewRaw);
          const qtyRemold = safeFloat(qtyRemoldRaw);
          
          let cost = 0;
          if (lifeNew > 0) cost += (qtyNew * priceNew) / lifeNew;
          if (lifeRemold > 0) cost += (qtyRemold * priceRemold) / lifeRemold;
          return cost;
      };

      totalTireCostPerKm += getAxleCost(data.tireSteerQtyNew, data.tireSteerQtyRemold);
      totalTireCostPerKm += getAxleCost(data.tireDriveQtyNew, data.tireDriveQtyRemold);
      totalTireCostPerKm += getAxleCost(data.tireTrailerQtyNew, data.tireTrailerQtyRemold);

      let fluidAndFilterCost = 0;
      
      // Engine Oil (Cárter)
      const oilCost = safeFloat(data.lastOilChangeCost);
      const oilInterval = safeFloat(data.oilChangeIntervalKm);
      if (oilCost > 0 && oilInterval > 0) fluidAndFilterCost += oilCost / oilInterval;
      
      // Trans Oil
      const transCost = safeFloat(data.lastTransOilChangeCost);
      const transInterval = safeFloat(data.transOilChangeIntervalKm);
      if (transCost > 0 && transInterval > 0) fluidAndFilterCost += transCost / transInterval;
      
      // Filters
      const filterCost = safeFloat(data.lastFilterChangeCost);
      const filterInterval = safeFloat(data.filterChangeIntervalKm);
      if (filterCost > 0 && filterInterval > 0) fluidAndFilterCost += filterCost / filterInterval;

      // EXCLUDING FUEL from this specific dashboard as per user request (Real Data / Asset Focus)
      setVariableCostPerKm(totalTireCostPerKm + fluidAndFilterCost);
      
      // Set breakdown for tooltip
      setCostBreakdown({
          tires: totalTireCostPerKm,
          maintenance: fluidAndFilterCost
      });
  };

  const loadVehicles = async () => {
      const vehicles = await getUserVehicles();
      setSavedVehicles(vehicles);
  };

  const handleSelectVehicle = (v: SavedVehicle) => {
      onUpdate({
          ...data,
          ...v,
          telemetryProvider: v.telemetry_provider as any,
          tireSteerQtyNew: v.tire_steer_qty_new,
          tireSteerQtyRemold: v.tire_steer_qty_remold,
          tireDriveQtyNew: v.tire_drive_qty_new,
          tireDriveQtyRemold: v.tire_drive_qty_remold,
          tireTrailerQtyNew: v.tire_trailer_qty_new,
          tireTrailerQtyRemold: v.tire_trailer_qty_remold,
          
          refTirePriceNew: v.ref_tire_price_new,
          refTireLifespanNew: v.ref_tire_lifespan_new,
          refTirePriceRemold: v.ref_tire_price_remold,
          refTireLifespanRemold: v.ref_tire_lifespan_remold,

          lastOilChangeKm: v.last_oil_change_km,
          lastOilChangeDate: v.last_oil_change_date,
          lastOilChangeCost: v.last_oil_change_cost,
          oilChangeIntervalKm: v.oil_change_interval_km,
          
          lastFilterChangeKm: v.last_filter_change_km,
          lastFilterChangeCost: v.last_filter_change_cost,
          filterChangeIntervalKm: v.filter_change_interval_km
      });
      setShowVehicleList(false);
  };

  const checkAuth = (): boolean => {
      const user = getStoredUser();
      if (!user || !user.id) {
          alert("🔒 SEGURANÇA: CADASTRO OBRIGATÓRIO\n\nPara salvar veículos na garagem e vincular placas, você precisa estar logado.\n\nIsso impede que outras pessoas acessem os dados do seu caminhão. Você será redirecionado para o cadastro.");
          if (onLogin) onLogin();
          return false;
      }
      return true;
  };

  const handleSaveVehicle = async () => {
      // 1. STRICT VALIDATION: Plate is mandatory
      if (!data.licensePlate || data.licensePlate.trim().length === 0) {
          setPlateError(true);
          alert("⚠️ A PLACA É OBRIGATÓRIA!\n\nTodos os custos e manutenções são vinculados à placa do veículo. Por favor, preencha a placa antes de salvar.");
          window.scrollTo({ top: 0, behavior: 'smooth' });
          return;
      }

      // 2. SECURITY CHECK: Auth mandatory
      if (!checkAuth()) return;

      setLoading(true);
      setSaveSuccess(false);
      try {
        const result = await saveNewVehicle(data);
        if (result.success) {
            await loadVehicles();
            setSaveSuccess(true);
            setTimeout(() => setSaveSuccess(false), 3000);
        } else {
            alert("Erro ao salvar veículo. Tente novamente.");
        }
      } catch (e: any) {
        if (e.message === 'AUTH_REQUIRED') {
            checkAuth(); // Trigger redirect again if caught
        } else {
            console.error(e);
            alert("Erro ao processar salvamento.");
        }
      } finally {
        setLoading(false);
      }
  };

  // --- TIRE PURCHASE LOGIC ---
  const openPurchaseModal = (type: 'new' | 'remold') => {
      setPurchaseType(type);
      setPurchaseQty('');
      setPurchaseSupplier('');
      setPurchaseDate(new Date().toISOString().split('T')[0]);
      setPurchasePrice(type === 'new' ? (data.refTirePriceNew?.toString() || '') : (data.refTirePriceRemold?.toString() || ''));
      setShowPurchaseModal(true);
  };

  const getNum = (val: string | number | undefined): number => {
      return safeFloat(val);
  };

  const handleRegisterPurchase = async () => {
      if (!checkAuth()) return;

      if (!data.licensePlate || data.licensePlate.trim() === '') {
          setPlateError(true);
          setShowPurchaseModal(false); // Close modal to show the error on main screen
          alert("⚠️ PLACA OBRIGATÓRIA!\n\nVocê será redirecionado para o campo de placa. Preencha e salve o veículo antes de registrar compras.");
          window.scrollTo({ top: 0, behavior: 'smooth' }); // Redirect user to top
          return;
      }
      
      const qty = getNum(purchaseQty);
      const unitPrice = getNum(purchasePrice);
      
      if (qty <= 0) return alert("Informe uma quantidade válida.");
      if (unitPrice <= 0) return alert("Informe um preço unitário válido.");
      if (!purchaseSupplier) return alert("Informe o fornecedor.");

      const totalCost = qty * unitPrice;
      const typeLabel = purchaseType === 'new' ? 'Pneus NOVOS' : 'Pneus REMOLD';
      const safePlate = data.licensePlate.toUpperCase().trim();

      // Weighted Average Calculation
      const currentRefPrice = safeFloat(purchaseType === 'new' ? data.refTirePriceNew : data.refTirePriceRemold);
      const installedQty = purchaseType === 'new' 
        ? (safeFloat(data.tireSteerQtyNew) + safeFloat(data.tireDriveQtyNew) + safeFloat(data.tireTrailerQtyNew))
        : (safeFloat(data.tireSteerQtyRemold) + safeFloat(data.tireDriveQtyRemold) + safeFloat(data.tireTrailerQtyRemold));
        
      let newAveragePrice = unitPrice;
      if (installedQty > 0) {
          newAveragePrice = ((currentRefPrice * installedQty) + (unitPrice * qty)) / (installedQty + qty);
      }

      setPurchaseLoading(true);
      try {
          await addFinancialRecord({
              type: 'EXPENSE',
              category: 'MAINTENANCE',
              description: `COMPRA PNEUS: ${qty}x ${typeLabel} - ${purchaseSupplier}`,
              amount: totalCost,
              date: purchaseDate,
              status: 'paid',
              vehicle_plate: safePlate,
              document_number: `PNEU-${Math.floor(Math.random()*10000)}` 
          });
          
          await addMaintenanceLog({
              license_plate: safePlate,
              service_type: 'TIRE_PURCHASE',
              odometer: data.currentOdometer || 0,
              cost: totalCost,
              location: purchaseSupplier,
              service_date: new Date().toISOString()
          });
          
          const updateField = purchaseType === 'new' ? 'refTirePriceNew' : 'refTirePriceRemold';
          const updatedData = { 
              ...data, 
              [updateField]: parseFloat(newAveragePrice.toFixed(2)),
              licensePlate: safePlate 
          };
          
          onUpdate(updatedData);
          await saveNewVehicle(updatedData);

          alert(`✅ Compra Registrada!\nPreço Médio Atualizado para R$ ${newAveragePrice.toFixed(2)}`);
          setShowPurchaseModal(false);
          
      } catch (e: any) {
          if (e.message === 'AUTH_REQUIRED') checkAuth();
          else alert(`Erro: ${e.message}`);
      } finally {
          setPurchaseLoading(false);
      }
  };

  // --- MAINTENANCE REGISTRY LOGIC (Oil/Filters) ---
  const openMaintModal = (type: 'ENGINE_OIL' | 'TRANS_OIL' | 'FILTERS') => {
      setMaintType(type);
      setMaintDate(new Date().toISOString().split('T')[0]);
      setMaintKm((data.currentOdometer || 0).toString());
      setMaintCost('');
      setMaintLocation('');
      setShowMaintModal(true);
  };

  const handleRegisterMaintenance = async () => {
      if (!checkAuth()) return;

      if (!data.licensePlate || data.licensePlate.trim() === '') {
          setPlateError(true);
          setShowMaintModal(false); // Close modal
          alert("⚠️ PLACA OBRIGATÓRIA!\n\nVocê será redirecionado para o campo de placa. Preencha e salve o veículo antes de registrar manutenção.");
          window.scrollTo({ top: 0, behavior: 'smooth' }); // Redirect user to top
          return;
      }
      if (!maintLocation) return alert("Informe o Fornecedor/Local.");
      
      const cost = getNum(maintCost);
      const km = getNum(maintKm);

      if (cost <= 0) return alert("Informe o custo.");
      if (km <= 0) return alert("Informe a quilometragem.");

      setMaintLoading(true);
      const safePlate = data.licensePlate.toUpperCase().trim();
      let category = 'MAINTENANCE';
      let description = '';
      let serviceType = '';

      // Prepare data based on type
      let updatedData = { ...data, licensePlate: safePlate };

      if (maintType === 'ENGINE_OIL') {
          description = `TROCA ÓLEO MOTOR (CÁRTER)`;
          serviceType = 'OIL_CHANGE';
          updatedData.lastOilChangeCost = cost;
          updatedData.lastOilChangeDate = maintDate;
          updatedData.lastOilChangeKm = km;
          updatedData.lastOilChangeLocation = maintLocation;
      } else if (maintType === 'TRANS_OIL') {
          description = `TROCA ÓLEO TRANSMISSÃO`;
          serviceType = 'TRANS_OIL_CHANGE';
          updatedData.lastTransOilChangeCost = cost;
          updatedData.lastTransOilChangeDate = maintDate;
          updatedData.lastTransOilChangeKm = km;
      } else if (maintType === 'FILTERS') {
          description = `TROCA KIT FILTROS`;
          serviceType = 'FILTER_CHANGE';
          updatedData.lastFilterChangeCost = cost;
          updatedData.lastFilterChangeDate = maintDate;
          updatedData.lastFilterChangeKm = km;
      }

      // Ensure odometer is updated if the service km is higher
      if (km > (updatedData.currentOdometer || 0)) {
          updatedData.currentOdometer = km;
      }

      try {
          // 1. Financial Record
          await addFinancialRecord({
              type: 'EXPENSE',
              category: 'MAINTENANCE',
              description: `${description} - ${maintLocation}`,
              amount: cost,
              date: maintDate,
              status: 'paid',
              vehicle_plate: safePlate,
              document_number: `SERV-${Math.floor(Math.random()*10000)}` 
          });

          // 2. Maintenance Log
          await addMaintenanceLog({
              license_plate: safePlate,
              service_type: serviceType,
              odometer: km,
              cost: cost,
              location: maintLocation,
              service_date: maintDate
          });

          // 3. Update Vehicle State & Garage
          onUpdate(updatedData);
          await saveNewVehicle(updatedData);

          alert("✅ Manutenção Registrada com Sucesso!");
          setShowMaintModal(false);

      } catch (e: any) {
          if (e.message === 'AUTH_REQUIRED') checkAuth();
          else alert(`Erro: ${e.message}`);
      } finally {
          setMaintLoading(false);
      }
  };

  const handleChange = (field: keyof VehicleData, value: any) => {
     if (typeof value === 'string') {
        let clean = value.trim();
        // Robust handling for BR format (e.g. 3.500,00) before parsing
        if (clean.includes(',')) {
            clean = clean.replace(/\./g, '').replace(',', '.');
        }
        
        const numValue = parseFloat(clean);
        onUpdate({ ...data, [field]: isNaN(numValue) ? 0 : numValue });
     } else {
        onUpdate({ ...data, [field]: value });
     }
  };

  // --- FIPE LOGIC ---
  const handleOpenFipe = async () => {
      setFipeLoading(true);
      setShowFipeModal(true);
      const b = await getFipeBrands();
      setBrands(b);
      setFipeStep('brand');
      setFipeLoading(false);
  };

  const handleSelectBrand = async (brand: FipeBrand) => {
      setFipeLoading(true);
      setSelectedBrand(brand);
      const m = await getFipeModels(brand.codigo);
      setModels(m);
      setFipeStep('model');
      setFipeLoading(false);
  };

  const handleSelectModel = async (model: FipeModel) => {
      setFipeLoading(true);
      setSelectedModel(model);
      const y = await getFipeYears(selectedBrand!.codigo, model.codigo);
      setYears(y);
      setFipeStep('year');
      setFipeLoading(false);
  };

  const handleSelectYear = async (year: FipeYear) => {
      setFipeLoading(true);
      const res = await getFipePrice(selectedBrand!.codigo, selectedModel!.codigo, year.codigo);
      if (res) {
          setFipeResult({
              priceStr: res.valor,
              value: parseFipeValue(res.valor)
          });
          setFipeStep('result');
      }
      setFipeLoading(false);
  };

  const applyFipeValue = () => {
      if (fipeResult) {
          onUpdate({ ...data, assetValue: fipeResult.value });
          setShowFipeModal(false);
      }
  };

  // --- REMODELED TIRE CARD (SPLIT MIX) ---
  const TireGroup = ({ 
    title, 
    qtyNewField,
    qtyRemoldField,
    iconColor
  }: { 
    title: string; 
    qtyNewField: keyof VehicleData;
    qtyRemoldField: keyof VehicleData;
    iconColor: string;
  }) => {
      const qNew = safeFloat(data[qtyNewField]);
      const qRem = safeFloat(data[qtyRemoldField]);
      
      const costNew = qNew * (safeFloat(data.refTirePriceNew) || 0);
      const costRem = qRem * (safeFloat(data.refTirePriceRemold) || 0);
      const totalInvestment = costNew + costRem;

      // Calc CPK for this axle
      let cpk = 0;
      const lifeNew = safeFloat(data.refTireLifespanNew) || 1;
      const lifeRem = safeFloat(data.refTireLifespanRemold) || 1;
      
      if (data.refTireLifespanNew) cpk += costNew / lifeNew;
      if (data.refTireLifespanRemold) cpk += costRem / lifeRem;

      return (
        <div className="bg-white p-5 rounded-2xl border-2 border-slate-100 shadow-sm hover:border-blue-100 transition-colors group">
            <div className="flex justify-between items-center mb-5 border-b border-slate-50 pb-3">
                <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-xl ${iconColor} bg-opacity-10 text-opacity-100`}>
                        <CircleDashed className={iconColor.replace('bg-', 'text-')} size={20} />
                    </div>
                    <div>
                        <h4 className="font-bold text-slate-700 text-lg leading-tight">{title}</h4>
                        <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                           Total: {qNew + qRem} Pneus
                        </span>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div className="bg-blue-50/50 p-3 rounded-xl border border-blue-100">
                    <p className="text-[10px] font-bold text-blue-600 uppercase mb-2 text-center">Novos</p>
                    <SpeechInput 
                        label="" 
                        value={qNew} 
                        onChange={(v) => handleChange(qtyNewField, v)} 
                        type="number" 
                        placeholder="Qtd"
                        className="text-center"
                    />
                </div>
                <div className="bg-orange-50/50 p-3 rounded-xl border border-orange-100">
                    <p className="text-[10px] font-bold text-orange-600 uppercase mb-2 text-center">Remold</p>
                    <SpeechInput 
                        label="" 
                        value={qRem} 
                        onChange={(v) => handleChange(qtyRemoldField, v)} 
                        type="number" 
                        placeholder="Qtd"
                        className="text-center"
                    />
                </div>
            </div>
            
            <div className="mt-4 flex justify-between items-end border-t border-slate-50 pt-2">
                 <div className="text-left">
                    <p className="text-[10px] text-slate-400 font-bold uppercase">Custo / Km (Eixo)</p>
                    <p className="text-sm font-bold text-slate-600">R$ {cpk.toFixed(4)}</p>
                </div>
                <div className="text-right">
                    <p className="text-[10px] text-slate-400 font-bold uppercase">Valor Investido</p>
                    <p className="text-lg font-black text-slate-700">R$ {totalInvestment.toFixed(2)}</p>
                </div>
            </div>
        </div>
      );
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 pb-24 animate-fade-in">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-8 rounded-3xl shadow-xl flex items-center justify-between relative overflow-hidden">
             <div className="absolute right-0 top-0 w-32 h-32 bg-white/5 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>
            <div className="relative z-10">
                <h2 className="text-3xl font-bold flex items-center gap-3">
                    <Wrench className="text-blue-400" /> Custos & Manutenção
                </h2>
                <p className="text-slate-400 text-base mt-1">Centralize custos fixos, pneus e manutenções.</p>
            </div>
            <div className="bg-white/10 p-3 rounded-2xl relative z-10">
                 <Logo className="w-12 h-12" />
            </div>
        </div>

        {/* Vehicle ID & Dashboard */}
        <div className={`bg-white rounded-2xl shadow-sm border overflow-hidden transition-colors duration-300 ${plateError ? 'border-red-500 ring-4 ring-red-100' : 'border-slate-200'}`}>
             <div className="p-8 border-b border-slate-100">
                <div className="flex justify-between items-start mb-6">
                    <div className="flex items-center gap-3 text-slate-800 font-bold text-xl">
                        <div className="bg-blue-50 p-2 rounded-lg text-blue-600"><Truck size={24} /></div>
                        <span>Veículo & Resumo</span>
                    </div>
                    <button onClick={() => setShowVehicleList(true)} className="text-xs bg-blue-50 text-blue-700 font-bold px-4 py-2 rounded-xl hover:bg-blue-100 transition-colors">Abrir Garagem ({savedVehicles.length})</button>
                </div>

                <div className="flex flex-col md:flex-row gap-4 items-end">
                    <div className="flex-1 w-full relative group">
                        {plateError && (
                            <div className="absolute -top-6 left-1 text-xs font-bold text-red-600 flex items-center gap-1 animate-bounce">
                                <AlertTriangle size={12} /> PLACA OBRIGATÓRIA PARA SALVAR
                            </div>
                        )}
                        <SpeechInput 
                            label="Placa do Veículo (Obrigatório)" 
                            value={data.licensePlate || ''} 
                            onChange={(v) => {
                                onUpdate({ ...data, licensePlate: v.toUpperCase() });
                                if(v) setPlateError(false);
                            }} 
                            placeholder="ABC-1234"
                            className={`${plateError ? "text-red-600" : ""} pr-[100px]`}
                        />
                        
                        <div className="absolute right-2 top-[42px] z-10">
                            <button 
                                onClick={handleSaveVehicle} 
                                disabled={loading} 
                                className={`h-[42px] px-4 rounded-lg font-bold flex items-center gap-2 transition-all shadow-sm ${
                                    saveSuccess 
                                    ? 'bg-green-500 text-white' 
                                    : plateError 
                                        ? 'bg-red-500 text-white animate-pulse' 
                                        : 'bg-slate-800 text-white hover:bg-black'
                                }`}
                                title="Salvar Veículo"
                            >
                                {loading ? (
                                    <Loader2 className="animate-spin" size={18} />
                                ) : saveSuccess ? (
                                    <CheckCircle size={18} />
                                ) : (
                                    <Save size={18} />
                                )}
                                <span className="text-sm hidden sm:inline">{saveSuccess ? 'Salvo!' : 'Salvar'}</span>
                            </button>
                        </div>
                    </div>
                </div>
             </div>

             <div className="grid grid-cols-2 divide-x divide-slate-100 bg-slate-50">
                 <div className="p-6 text-center hover:bg-slate-100 transition-colors cursor-default">
                     <p className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-1">Custo Fixo / Dia</p>
                     <p className="text-3xl font-black text-slate-800">R$ {dailyFixedCost.toFixed(2)}</p>
                     <p className="text-[10px] text-slate-500 mt-1 font-medium bg-white inline-block px-2 py-0.5 rounded border border-slate-200">Salário • Seguro • IPVA • Deprec.</p>
                 </div>
                 <div className="p-6 text-center hover:bg-slate-100 transition-colors cursor-default group relative">
                     <p className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-1">Custo Variável / Km</p>
                     <p className="text-3xl font-black text-orange-600">R$ {variableCostPerKm.toFixed(2)}</p>
                     <p className="text-[10px] text-slate-500 mt-1 font-medium bg-white inline-block px-2 py-0.5 rounded border border-slate-200">Pneus • Óleos • Filtros</p>
                     
                     {/* Breakdown Tooltip */}
                     <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 bg-slate-800 text-white text-xs p-3 rounded-xl shadow-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none w-48 z-10 border border-slate-700">
                        <div className="flex justify-between border-b border-slate-700 pb-1 mb-1"><span>Pneus:</span> <span className="font-bold">R$ {costBreakdown.tires.toFixed(3)}</span></div>
                        <div className="flex justify-between"><span>Manut:</span> <span className="font-bold">R$ {costBreakdown.maintenance.toFixed(3)}</span></div>
                     </div>
                 </div>
             </div>
        </div>

        {/* TIRES MANAGEMENT */}
        <div className="space-y-4">
            <div className="flex justify-between items-center mb-4 px-2">
                <h3 className="text-xl font-bold text-slate-800 flex items-center gap-3">
                    <div className="bg-slate-100 p-2 rounded-lg text-slate-600"><Disc size={24} /></div>
                    Gestão de Pneus
                </h3>
                <button onClick={handleSaveVehicle} className="text-slate-600 bg-slate-50 border border-slate-200 p-2 rounded-lg flex items-center gap-2 text-xs font-bold hover:bg-slate-100 transition-colors">
                    <Save size={18}/> Salvar
                </button>
            </div>

            <div className="bg-blue-50/50 p-6 rounded-2xl border border-blue-100">
                <div className="flex items-center gap-2 mb-4">
                    <Tag size={18} className="text-blue-600" />
                    <h4 className="font-bold text-blue-900 text-sm uppercase">Tabela de Referência e Compra</h4>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* New Tires */}
                    <div className="bg-white p-4 rounded-xl border border-blue-100 flex flex-col justify-between">
                         <div>
                            <div className="flex items-center gap-2 mb-3 text-blue-700 font-bold uppercase text-xs">
                                <span className="w-2 h-2 rounded-full bg-blue-500"></span> Pneu Novo
                            </div>
                            <div className="space-y-3 mb-4">
                                <SpeechInput 
                                    label="Preço Médio (R$)" 
                                    prefix="R$" 
                                    value={data.refTirePriceNew || ''} 
                                    onChange={(v) => handleChange('refTirePriceNew', v)} 
                                    type="number" 
                                    placeholder="3500.00"
                                />
                                <SpeechInput 
                                    label="Vida Útil (KM)" 
                                    value={data.refTireLifespanNew || ''} 
                                    onChange={(v) => handleChange('refTireLifespanNew', v)} 
                                    type="number" 
                                    placeholder="100000"
                                />
                            </div>
                         </div>
                         <button 
                            onClick={() => openPurchaseModal('new')}
                            className="w-full bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold py-3 rounded-lg flex items-center justify-center gap-2 text-sm border border-blue-200 transition-colors"
                         >
                             <ShoppingCart size={16} /> Comprar Novos
                         </button>
                    </div>

                    {/* Remold Tires */}
                    <div className="bg-white p-4 rounded-xl border border-orange-100 flex flex-col justify-between">
                         <div>
                            <div className="flex items-center gap-2 mb-3 text-orange-700 font-bold uppercase text-xs">
                                <span className="w-2 h-2 rounded-full bg-orange-500"></span> Pneu Remold
                            </div>
                            <div className="space-y-3 mb-4">
                                <SpeechInput 
                                    label="Preço Médio (R$)" 
                                    prefix="R$" 
                                    value={data.refTirePriceRemold || ''} 
                                    onChange={(v) => handleChange('refTirePriceRemold', v)} 
                                    type="number" 
                                    placeholder="1800.00"
                                />
                                <SpeechInput 
                                    label="Vida Útil (KM)" 
                                    value={data.refTireLifespanRemold || ''} 
                                    onChange={(v) => handleChange('refTireLifespanRemold', v)} 
                                    type="number" 
                                    placeholder="60000"
                                />
                            </div>
                         </div>
                         <button 
                            onClick={() => openPurchaseModal('remold')}
                            className="w-full bg-orange-50 hover:bg-orange-100 text-orange-700 font-bold py-3 rounded-lg flex items-center justify-center gap-2 text-sm border border-orange-200 transition-colors"
                         >
                             <ShoppingCart size={16} /> Comprar Remold
                         </button>
                    </div>
                </div>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <TireGroup title="Eixo Direcional" iconColor="bg-blue-600" qtyNewField="tireSteerQtyNew" qtyRemoldField="tireSteerQtyRemold" />
                <TireGroup title="Eixo Tração" iconColor="bg-purple-600" qtyNewField="tireDriveQtyNew" qtyRemoldField="tireDriveQtyRemold" />
                <TireGroup title="Carreta / Reboque" iconColor="bg-orange-600" qtyNewField="tireTrailerQtyNew" qtyRemoldField="tireTrailerQtyRemold" />
            </div>
        </div>

        {/* Value & Depreciation */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 relative">
             <div className="flex justify-between items-center mb-6">
                <h3 className="font-bold text-slate-800 flex items-center gap-3 text-xl">
                    <div className="bg-green-100 p-2 rounded-lg text-green-600"><DollarSign size={24} /></div>
                    Valor e Depreciação
                </h3>
                <div className="flex gap-2">
                    <button onClick={handleOpenFipe} className="text-xs flex items-center gap-2 bg-green-600 text-white font-bold px-3 py-2 rounded-lg hover:bg-green-700 shadow-md shadow-green-200 transition-transform active:scale-95">
                        <Search size={14}/> Consultar FIPE
                    </button>
                    <button onClick={handleSaveVehicle} className="text-green-600 bg-green-50 border border-green-200 p-2 rounded-lg flex items-center gap-2 text-xs font-bold hover:bg-green-100 transition-colors">
                        <Save size={18}/> Salvar
                    </button>
                </div>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <SpeechInput label="Valor do Veículo (R$)" prefix="R$" value={data.assetValue || ''} onChange={(v) => handleChange('assetValue', v)} type="number" placeholder="0.00"/>
                 <div>
                    <SpeechInput label="Depreciação Anual (%)" prefix="%" value={data.annualDepreciationRate || ''} onChange={(v) => handleChange('annualDepreciationRate', v)} type="number" placeholder="15"/>
                    <p className="text-xs text-slate-400 mt-2 font-medium">
                        Impacto dia: <span className="text-slate-600 font-bold">R$ {(((data.assetValue || 0) * ((data.annualDepreciationRate || 15) / 100)) / 365).toFixed(2)}</span>
                    </p>
                 </div>
             </div>
        </div>

        {/* FLUIDS & MAINTENANCE */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 relative">
             <div className="flex justify-between items-center mb-8">
                <h3 className="font-bold text-slate-800 flex items-center gap-3 text-xl">
                    <div className="bg-blue-100 p-2 rounded-lg text-blue-600"><Droplet size={24} /></div>
                    Lubrificação & Manutenção
                </h3>
                <button onClick={handleSaveVehicle} className="text-blue-600 bg-blue-50 border border-blue-200 p-2 rounded-lg flex items-center gap-2 text-xs font-bold hover:bg-blue-100 transition-colors">
                    <Save size={18}/> Salvar
                </button>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                 {/* Engine Oil (Cárter) */}
                 <div className="space-y-4 relative">
                     <h4 className="font-bold text-slate-600 text-sm uppercase border-b-2 border-slate-100 pb-2 flex items-center gap-2"><Circle size={10} className="text-slate-400 fill-slate-400"/> Óleo Motor (Cárter)</h4>
                     <SpeechInput label="Intervalo de Troca (km)" value={data.oilChangeIntervalKm || ''} onChange={(v) => handleChange('oilChangeIntervalKm', v)} type="number" placeholder="Ex: 20000"/>
                     <SpeechInput label="Custo da Troca (R$)" prefix="R$" value={data.lastOilChangeCost || ''} onChange={(v) => handleChange('lastOilChangeCost', v)} type="number" placeholder="0.00"/>
                     
                     <div className="p-3 bg-slate-50 rounded-xl text-xs text-slate-600 space-y-2 border border-slate-100">
                        <div className="flex justify-between items-center">
                            <p className="font-bold text-slate-400 uppercase text-[10px]">Último Registro</p>
                            <button onClick={() => openMaintModal('ENGINE_OIL')} className="text-[10px] bg-blue-600 text-white px-2 py-1 rounded font-bold hover:bg-blue-700 flex items-center gap-1">
                                <RefreshCw size={10} /> Registrar Troca
                            </button>
                        </div>
                        <div className="flex justify-between"><span>Data:</span> <span className="font-bold">{data.lastOilChangeDate ? new Date(data.lastOilChangeDate).toLocaleDateString() : '-'}</span></div>
                        <div className="flex justify-between"><span>KM:</span> <span className="font-bold">{data.lastOilChangeKm || '-'}</span></div>
                     </div>
                 </div>

                 {/* Transmission Oil */}
                 <div className="space-y-4 relative">
                     <h4 className="font-bold text-slate-600 text-sm uppercase border-b-2 border-slate-100 pb-2 flex items-center gap-2"><Circle size={10} className="text-slate-400 fill-slate-400"/> Óleo Transmissão</h4>
                     <SpeechInput label="Intervalo de Troca (km)" value={data.transOilChangeIntervalKm || ''} onChange={(v) => handleChange('transOilChangeIntervalKm', v)} type="number" placeholder="Ex: 100000"/>
                     <SpeechInput label="Custo da Troca (R$)" prefix="R$" value={data.lastTransOilChangeCost || ''} onChange={(v) => handleChange('lastTransOilChangeCost', v)} type="number" placeholder="0.00"/>
                     
                     <div className="p-3 bg-slate-50 rounded-xl text-xs text-slate-600 space-y-2 border border-slate-100">
                        <div className="flex justify-between items-center">
                            <p className="font-bold text-slate-400 uppercase text-[10px]">Último Registro</p>
                            <button onClick={() => openMaintModal('TRANS_OIL')} className="text-[10px] bg-blue-600 text-white px-2 py-1 rounded font-bold hover:bg-blue-700 flex items-center gap-1">
                                <RefreshCw size={10} /> Registrar Troca
                            </button>
                        </div>
                        <div className="flex justify-between"><span>Data:</span> <span className="font-bold">{data.lastTransOilChangeDate ? new Date(data.lastTransOilChangeDate).toLocaleDateString() : '-'}</span></div>
                        <div className="flex justify-between"><span>KM:</span> <span className="font-bold">{data.lastTransOilChangeKm || '-'}</span></div>
                     </div>
                 </div>

                 {/* Filters */}
                 <div className="space-y-4 relative">
                     <h4 className="font-bold text-slate-600 text-sm uppercase border-b-2 border-slate-100 pb-2 flex items-center gap-2"><Filter size={10} className="text-slate-400 fill-slate-400"/> Kit de Filtros</h4>
                     <SpeechInput label="Intervalo de Troca (km)" value={data.filterChangeIntervalKm || ''} onChange={(v) => handleChange('filterChangeIntervalKm', v)} type="number" placeholder="Ex: 20000"/>
                     <SpeechInput label="Custo do Kit (R$)" prefix="R$" value={data.lastFilterChangeCost || ''} onChange={(v) => handleChange('lastFilterChangeCost', v)} type="number" placeholder="0.00"/>
                     
                     <div className="p-3 bg-slate-50 rounded-xl text-xs text-slate-600 space-y-2 border border-slate-100">
                        <div className="flex justify-between items-center">
                            <p className="font-bold text-slate-400 uppercase text-[10px]">Último Registro</p>
                            <button onClick={() => openMaintModal('FILTERS')} className="text-[10px] bg-blue-600 text-white px-2 py-1 rounded font-bold hover:bg-blue-700 flex items-center gap-1">
                                <RefreshCw size={10} /> Registrar Troca
                            </button>
                        </div>
                        <div className="flex justify-between"><span>Data:</span> <span className="font-bold">{data.lastFilterChangeDate ? new Date(data.lastFilterChangeDate).toLocaleDateString() : '-'}</span></div>
                        <div className="flex justify-between"><span>KM:</span> <span className="font-bold">{data.lastFilterChangeKm || '-'}</span></div>
                     </div>
                 </div>
             </div>
        </div>

        {/* FIXED COSTS (Salary, Insurance, IPVA) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* SALARY */}
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 relative md:col-span-2">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="font-bold text-slate-800 flex items-center gap-3 text-xl">
                        <div className="bg-purple-100 p-2 rounded-lg text-purple-600"><Briefcase size={24} /></div>
                        Motorista & Salário
                    </h3>
                    <button onClick={handleSaveVehicle} className="text-purple-600 bg-purple-50 border border-purple-200 p-2 rounded-lg flex items-center gap-2 text-xs font-bold hover:bg-purple-100 transition-colors">
                        <Save size={18}/> Salvar
                    </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                        <SpeechInput label="Salário Base Mensal (R$)" prefix="R$" value={data.driverSalaryMonthly || ''} onChange={(v) => handleChange('driverSalaryMonthly', v)} type="number" placeholder="0.00"/>
                        <p className="text-xs text-slate-400 mt-2 font-medium">
                             Custo diário (Salário + Encargos): <span className="text-slate-600 font-bold">R$ {(((data.driverSalaryMonthly || 0) * (data.driverSalaryInclude13th ? 13 : 12)) / 365).toFixed(2)}</span>
                        </p>
                        
                        <div className="mt-4 flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => onUpdate({...data, driverSalaryInclude13th: !data.driverSalaryInclude13th})}>
                             <div className={`w-5 h-5 rounded border flex items-center justify-center ${data.driverSalaryInclude13th ? 'bg-purple-600 border-purple-600' : 'bg-white border-slate-300'}`}>
                                {data.driverSalaryInclude13th && <CheckCircle size={14} className="text-white"/>}
                             </div>
                             <span className="text-sm font-bold text-slate-600 select-none">Incluir provisionamento de 13º Salário</span>
                        </div>
                    </div>
                    <div>
                        <label className="text-lg font-bold text-slate-700 block mb-2">Comissão Adicional (%)</label>
                        <div className="flex items-center gap-3 p-4 bg-purple-50 rounded-xl border border-purple-100 group-focus-within:ring-2 ring-purple-200 transition-all">
                             <input 
                                type="number"
                                value={data.driverCommissionPercentage || ''} 
                                onChange={(e) => handleChange('driverCommissionPercentage', e.target.value)}
                                className="bg-transparent font-black text-purple-700 outline-none w-20 text-2xl"
                                placeholder="0"
                             />
                             <span className="text-purple-400 font-bold">% do Frete Bruto</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* INSURANCE */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 relative hover:border-blue-300 transition-colors">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-slate-800 flex items-center gap-2 text-lg">
                        <div className="bg-blue-100 p-1.5 rounded-lg text-blue-600"><Shield size={18} /></div>
                        Seguro Veicular
                    </h3>
                    <button onClick={handleSaveVehicle} className="text-blue-600 bg-blue-50 border border-blue-200 p-2 rounded-lg text-xs font-bold hover:bg-blue-100">
                        <Save size={18}/>
                    </button>
                </div>
                <SpeechInput label="Custo Anual (R$)" prefix="R$" value={data.insuranceYearly || ''} onChange={(v) => handleChange('insuranceYearly', v)} type="number" placeholder="0.00"/>
                <p className="text-xs text-slate-400 mt-2 font-medium">Impacto dia: <span className="text-slate-600 font-bold">R$ {((data.insuranceYearly || 0) / 365).toFixed(2)}</span></p>
            </div>

            {/* IPVA/TAXES */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 relative hover:border-orange-300 transition-colors">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-slate-800 flex items-center gap-2 text-lg">
                        <div className="bg-orange-100 p-1.5 rounded-lg text-orange-600"><FileCheck size={18} /></div>
                        IPVA & Licenciamento
                    </h3>
                    <button onClick={handleSaveVehicle} className="text-orange-600 bg-orange-50 border border-orange-200 p-2 rounded-lg text-xs font-bold hover:bg-orange-100">
                        <Save size={18}/>
                    </button>
                </div>
                <SpeechInput label="Custo Anual (R$)" prefix="R$" value={data.registrationYearly || ''} onChange={(v) => handleChange('registrationYearly', v)} type="number" placeholder="0.00"/>
                <p className="text-xs text-slate-400 mt-2 font-medium">Impacto dia: <span className="text-slate-600 font-bold">R$ {((data.registrationYearly || 0) / 365).toFixed(2)}</span></p>
            </div>
        </div>

        {/* Navigation */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/95 backdrop-blur-md border-t border-gray-200 z-50 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)]">
            <div className="max-w-3xl mx-auto flex gap-4">
                <button
                onClick={onBack}
                className="px-6 py-4 rounded-xl border-2 border-slate-200 text-slate-600 font-bold text-lg hover:bg-slate-50 transition-colors flex items-center justify-center"
                >
                <ArrowLeft size={24} />
                </button>
                <button
                onClick={onNext}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-lg transition-transform active:scale-[0.98] text-xl flex justify-center items-center gap-2"
                >
                Próximo <ArrowRight size={24} />
                </button>
            </div>
        </div>

        {/* --- MODALS --- */}
        {/* ... (Existing Modals remain unchanged visually, but logic inside them handles safePlate correctly) ... */}
        
        {/* MAINTENANCE REGISTRY MODAL */}
        {showMaintModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
                <div className="bg-white rounded-3xl shadow-2xl w-full max-w-sm p-0 overflow-hidden">
                    <div className="bg-slate-900 p-6 text-white text-center">
                        <div className="bg-white/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto text-white mb-4">
                            <Droplet size={32}/>
                        </div>
                        <h3 className="text-xl font-bold">Registrar Manutenção</h3>
                        <p className="text-slate-300 text-sm mt-1">
                            {maintType === 'ENGINE_OIL' && 'Troca de Óleo Motor'}
                            {maintType === 'TRANS_OIL' && 'Troca de Óleo Transmissão'}
                            {maintType === 'FILTERS' && 'Troca de Filtros'}
                        </p>
                    </div>
                    
                    <div className="p-6 space-y-4">
                        <div className="grid grid-cols-2 gap-3">
                             <div className="col-span-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Fornecedor/Local</label>
                                <div className="relative">
                                    <Store className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                                    <input 
                                        type="text"
                                        value={maintLocation}
                                        onChange={(e) => setMaintLocation(e.target.value)}
                                        placeholder="Nome da Oficina"
                                        className="w-full pl-10 pr-3 py-3 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-blue-500"
                                    />
                                </div>
                             </div>
                             <div className="col-span-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Data</label>
                                <div className="relative">
                                    <CalendarDays className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                                    <input 
                                        type="date"
                                        value={maintDate}
                                        onChange={(e) => setMaintDate(e.target.value)}
                                        className="w-full pl-10 pr-3 py-3 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-blue-500"
                                    />
                                </div>
                             </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Hodômetro (KM)</label>
                                <input 
                                    type="number"
                                    value={maintKm}
                                    onChange={(e) => setMaintKm(e.target.value)}
                                    placeholder="0"
                                    className="w-full px-3 py-3 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Custo Total (R$)</label>
                                <input 
                                    type="number"
                                    value={maintCost}
                                    onChange={(e) => setMaintCost(e.target.value)}
                                    placeholder="0.00"
                                    className="w-full px-3 py-3 border border-slate-200 rounded-xl text-sm font-bold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                        </div>

                        <div className="flex gap-3 pt-2">
                            <button onClick={() => setShowMaintModal(false)} className="flex-1 py-3 text-slate-500 font-bold bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors">Cancelar</button>
                            <button 
                                onClick={handleRegisterMaintenance} 
                                disabled={maintLoading}
                                className="flex-1 py-3 text-white font-bold bg-green-600 rounded-xl hover:bg-green-700 shadow-lg shadow-green-200 transition-colors flex items-center justify-center gap-2"
                            >
                                {maintLoading ? <Loader2 className="animate-spin" size={18}/> : "Confirmar"}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {showVehicleList && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[80vh] overflow-hidden flex flex-col">
                    <div className="p-4 border-b border-slate-100 flex justify-between items-center">
                        <h3 className="font-bold text-lg text-slate-800">Meus Veículos</h3>
                        <button onClick={() => setShowVehicleList(false)} className="text-slate-400 hover:text-slate-600"><X size={24}/></button>
                    </div>
                    <div className="overflow-y-auto p-4 space-y-3 flex-1">
                        {savedVehicles.map((v) => (
                            <button 
                                key={v.id} 
                                onClick={() => handleSelectVehicle(v)}
                                className="w-full text-left bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-200 p-4 rounded-xl transition-all group"
                            >
                                <div className="flex justify-between items-center mb-1">
                                    <span className="font-bold text-slate-800 text-lg">{v.license_plate}</span>
                                    <span className="text-xs bg-white px-2 py-1 rounded text-slate-500 font-bold border border-slate-100">{v.axles} Eixos</span>
                                </div>
                                <p className="text-sm text-slate-500 group-hover:text-blue-600">{v.model_name}</p>
                            </button>
                        ))}
                        {savedVehicles.length === 0 && <p className="text-center text-slate-400 py-8">Nenhum veículo salvo.</p>}
                    </div>
                </div>
            </div>
        )}

        {showPurchaseModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
                <div className="bg-white rounded-3xl shadow-2xl w-full max-w-sm p-0 overflow-hidden">
                    <div className="bg-slate-900 p-6 text-white text-center">
                        <div className="bg-white/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto text-white mb-4">
                            <ShoppingCart size={32}/>
                        </div>
                        <h3 className="text-xl font-bold">Registrar Compra</h3>
                        <p className="text-slate-300 text-sm mt-1">Estoque e Histórico</p>
                    </div>
                    
                    <div className="p-6 space-y-4">
                        <div className="grid grid-cols-2 gap-3">
                             <div className="col-span-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Fornecedor</label>
                                <div className="relative">
                                    <Store className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                                    <input 
                                        type="text"
                                        value={purchaseSupplier}
                                        onChange={(e) => setPurchaseSupplier(e.target.value)}
                                        placeholder="Nome da Loja/Fornecedor"
                                        className="w-full pl-10 pr-3 py-3 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-blue-500"
                                    />
                                </div>
                             </div>
                             <div className="col-span-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Data da Compra</label>
                                <div className="relative">
                                    <CalendarDays className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                                    <input 
                                        type="date"
                                        value={purchaseDate}
                                        onChange={(e) => setPurchaseDate(e.target.value)}
                                        className="w-full pl-10 pr-3 py-3 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-blue-500"
                                    />
                                </div>
                             </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Quantidade</label>
                                <input 
                                    type="number"
                                    value={purchaseQty}
                                    onChange={(e) => setPurchaseQty(e.target.value)}
                                    placeholder="0"
                                    className="w-full px-3 py-3 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Preço Unit. (R$)</label>
                                <input 
                                    type="number"
                                    value={purchasePrice}
                                    onChange={(e) => setPurchasePrice(e.target.value)}
                                    placeholder="0.00"
                                    className="w-full px-3 py-3 border border-slate-200 rounded-xl text-sm font-bold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                        </div>

                        <div className="bg-slate-50 p-4 rounded-xl flex justify-between items-center border border-slate-100">
                             <span className="text-xs font-bold text-slate-500 uppercase">Total Estimado</span>
                             <span className="text-xl font-black text-green-600">
                                 R$ {((parseFloat(purchaseQty)||0) * (parseFloat(purchasePrice)||0)).toFixed(2)}
                             </span>
                        </div>

                        <div className="flex gap-3 pt-2">
                            <button onClick={() => setShowPurchaseModal(false)} className="flex-1 py-3 text-slate-500 font-bold bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors">Cancelar</button>
                            <button 
                                onClick={handleRegisterPurchase} 
                                disabled={purchaseLoading}
                                className="flex-1 py-3 text-white font-bold bg-green-600 rounded-xl hover:bg-green-700 shadow-lg shadow-green-200 transition-colors flex items-center justify-center gap-2"
                            >
                                {purchaseLoading ? <Loader2 className="animate-spin" size={18}/> : "Confirmar"}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {showFipeModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[80vh] flex flex-col">
                     <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-green-50 rounded-t-2xl">
                        <h3 className="font-bold text-lg text-green-800">Consulta FIPE</h3>
                        <button onClick={() => setShowFipeModal(false)} className="text-green-800 hover:bg-green-100 p-1 rounded-full"><X size={24}/></button>
                    </div>
                    
                    <div className="p-4 flex-1 overflow-y-auto">
                        {fipeLoading && (
                            <div className="flex justify-center py-10"><Loader2 className="animate-spin text-green-600" size={32}/></div>
                        )}

                        {!fipeLoading && fipeStep === 'brand' && (
                            <div className="space-y-2">
                                <p className="text-sm font-bold text-slate-500 mb-2">Selecione a Marca:</p>
                                {brands.map(b => (
                                    <button key={b.codigo} onClick={() => handleSelectBrand(b)} className="w-full text-left p-3 hover:bg-slate-50 border-b border-slate-100 text-slate-700 font-medium">
                                        {b.nome}
                                    </button>
                                ))}
                            </div>
                        )}

                        {!fipeLoading && fipeStep === 'model' && (
                            <div className="space-y-2">
                                <button onClick={() => setFipeStep('brand')} className="text-xs text-blue-600 font-bold mb-2 flex items-center gap-1"><ArrowLeft size={12}/> Voltar</button>
                                <p className="text-sm font-bold text-slate-500 mb-2">Selecione o Modelo:</p>
                                {models.map(m => (
                                    <button key={m.codigo} onClick={() => handleSelectModel(m)} className="w-full text-left p-3 hover:bg-slate-50 border-b border-slate-100 text-slate-700 font-medium text-sm">
                                        {m.nome}
                                    </button>
                                ))}
                            </div>
                        )}

                        {!fipeLoading && fipeStep === 'year' && (
                             <div className="space-y-2">
                                <button onClick={() => setFipeStep('model')} className="text-xs text-blue-600 font-bold mb-2 flex items-center gap-1"><ArrowLeft size={12}/> Voltar</button>
                                <p className="text-sm font-bold text-slate-500 mb-2">Selecione o Ano:</p>
                                {years.map(y => (
                                    <button key={y.codigo} onClick={() => handleSelectYear(y)} className="w-full text-left p-3 hover:bg-slate-50 border-b border-slate-100 text-slate-700 font-medium">
                                        {y.nome}
                                    </button>
                                ))}
                            </div>
                        )}

                        {!fipeLoading && fipeStep === 'result' && fipeResult && (
                            <div className="text-center py-6 space-y-6">
                                <div>
                                    <p className="text-sm text-slate-500 font-medium">Preço Médio</p>
                                    <p className="text-3xl font-black text-green-600">{fipeResult.priceStr}</p>
                                </div>
                                <div className="bg-slate-50 p-4 rounded-xl text-sm text-slate-600 text-left space-y-1">
                                    <p><strong>Marca:</strong> {selectedBrand?.nome}</p>
                                    <p><strong>Modelo:</strong> {selectedModel?.nome}</p>
                                </div>
                                <button 
                                    onClick={applyFipeValue}
                                    className="w-full bg-green-600 text-white font-bold py-3 rounded-xl shadow-lg hover:bg-green-700 transition-colors"
                                >
                                    Usar este valor
                                </button>
                                <button onClick={() => setFipeStep('brand')} className="text-sm text-slate-400 hover:text-slate-600">Nova Consulta</button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default VehicleCosts;
