
import React, { useEffect, useState } from 'react';
import { AdminStats } from '../types';
import { getAdminStats } from '../services/dbService';
import Logo from './Logo';
import { 
  LayoutDashboard, 
  Users, 
  DollarSign, 
  Activity, 
  TrendingUp, 
  CreditCard,
  Search,
  LogOut,
  ArrowUpRight,
  Server,
  PieChart,
  Truck,
  Play
} from 'lucide-react';
import { ResponsiveContainer, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar, Legend } from 'recharts';

interface AdminDashboardProps {
  onLogout: () => void;
  onOpenFleet: () => void;
  onTestCalculator: () => void; // New prop for testing
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onLogout, onOpenFleet, onTestCalculator }) => {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);

  // CUSTOS ESTIMADOS POR API (BRL)
  const COST_GEMINI_PER_REQ = 0.02; // Muito barato
  const COST_MAPS_PER_REQ = 0.15;   // Custo médio Google Maps/Places
  const TOTAL_COST_PER_SIMULATION = COST_GEMINI_PER_REQ + COST_MAPS_PER_REQ;

  useEffect(() => {
    getAdminStats().then(data => {
      setStats(data);
      setLoading(false);
    });
  }, []);

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  const formatDate = (isoString: string) => {
    const date = new Date(isoString);
    return date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) + ' - ' + date.toLocaleDateString('pt-BR');
  }

  // Fake chart data
  const revenueData = [
    { name: 'Seg', receita: 1400, custo_api: 200 },
    { name: 'Ter', receita: 2100, custo_api: 350 },
    { name: 'Qua', receita: 1800, custo_api: 280 },
    { name: 'Qui', receita: 2800, custo_api: 400 },
    { name: 'Sex', receita: 3500, custo_api: 500 },
    { name: 'Sab', receita: 2000, custo_api: 150 },
    { name: 'Dom', receita: 1100, custo_api: 100 },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-slate-900"></div>
      </div>
    );
  }

  // Financial Calcs
  const totalRevenue = stats?.totalRevenue || 0;
  const totalSimulations = stats?.activeSimulations || 0; 
  const estimatedApiCost = totalSimulations * TOTAL_COST_PER_SIMULATION; 
  const netMargin = totalRevenue - estimatedApiCost;
  const marginPercentage = totalRevenue > 0 ? (netMargin / totalRevenue) * 100 : 0;

  return (
    <div className="min-h-screen bg-slate-100 font-sans flex flex-col md:flex-row">
      
      {/* Sidebar */}
      <aside className="bg-slate-900 text-white w-full md:w-64 flex-shrink-0">
        <div className="p-6 flex items-center gap-3 border-b border-slate-800">
           <Logo className="w-8 h-8" />
           <span className="font-bold text-xl tracking-tight">Admin<span className="text-blue-500">Panel</span></span>
        </div>
        
        <nav className="p-4 space-y-2">
            <a href="#" className="flex items-center gap-3 bg-blue-600 text-white px-4 py-3 rounded-xl font-medium shadow-lg shadow-blue-900/50">
                <LayoutDashboard size={20} /> Visão Geral
            </a>
            <a href="#" className="flex items-center gap-3 text-slate-400 hover:text-white hover:bg-slate-800 px-4 py-3 rounded-xl font-medium transition-colors">
                <Users size={20} /> Usuários
            </a>
            <a href="#" className="flex items-center gap-3 text-slate-400 hover:text-white hover:bg-slate-800 px-4 py-3 rounded-xl font-medium transition-colors">
                <PieChart size={20} /> Custos de API
            </a>
             <a href="#" className="flex items-center gap-3 text-slate-400 hover:text-white hover:bg-slate-800 px-4 py-3 rounded-xl font-medium transition-colors">
                <Activity size={20} /> Logs do Sistema
            </a>
        </nav>

        <div className="p-4 mt-auto">
             <button 
                onClick={onLogout}
                className="w-full flex items-center gap-2 text-red-400 hover:text-red-300 hover:bg-red-900/20 px-4 py-3 rounded-xl transition-colors text-sm font-bold"
             >
                <LogOut size={18} /> Sair do Admin
             </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto">
         
         {/* Top Bar */}
         <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-4">
            <div>
                <h1 className="text-2xl font-bold text-slate-800">Performance do Negócio</h1>
                <p className="text-slate-500">Análise de custos vs receita em tempo real.</p>
            </div>
            
            <button 
                onClick={onTestCalculator}
                className="bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all active:scale-95"
            >
                <Play size={20} />
                Testar Calculadora
            </button>
         </div>

         {/* Profitability Analysis Cards */}
         <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
             <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-6 text-white shadow-lg">
                <div className="flex items-center gap-2 mb-4 text-slate-300">
                    <Server size={20} />
                    <span className="text-sm font-bold uppercase">Custo Estimado de API</span>
                </div>
                <div className="flex justify-between items-end">
                    <div>
                        <span className="text-3xl font-bold text-red-400">{formatCurrency(estimatedApiCost)}</span>
                        <p className="text-xs text-slate-400 mt-1">Baseado em {totalSimulations} chamadas</p>
                    </div>
                    <div className="text-right">
                        <span className="text-xs block text-slate-500">Médio/Simulação</span>
                        <span className="font-bold text-slate-200">{formatCurrency(TOTAL_COST_PER_SIMULATION)}</span>
                    </div>
                </div>
             </div>

             <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                <div className="flex items-center gap-2 mb-4 text-slate-500">
                    <DollarSign size={20} />
                    <span className="text-sm font-bold uppercase">Receita Bruta</span>
                </div>
                <div className="flex justify-between items-end">
                    <span className="text-3xl font-bold text-slate-800">{formatCurrency(totalRevenue)}</span>
                    <span className="bg-green-100 text-green-700 px-2 py-1 rounded-lg text-xs font-bold">+12% vs. anterior</span>
                </div>
             </div>

             <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                <div className="flex items-center gap-2 mb-4 text-slate-500">
                    <TrendingUp size={20} />
                    <span className="text-sm font-bold uppercase">Margem Líquida</span>
                </div>
                <div className="flex justify-between items-end">
                    <div>
                        <span className={`text-3xl font-bold ${netMargin > 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {formatCurrency(netMargin)}
                        </span>
                        <p className="text-xs text-slate-400 mt-1">Lucro real da operação</p>
                    </div>
                    <div className="text-right">
                        <span className="text-xs block text-slate-500">Margem %</span>
                        <span className={`font-bold ${marginPercentage > 50 ? 'text-green-600' : 'text-orange-500'}`}>
                            {marginPercentage.toFixed(1)}%
                        </span>
                    </div>
                </div>
             </div>
         </div>

         {/* KPI Cards */}
         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <div className="flex justify-between items-start mb-4">
                    <div className="p-3 bg-purple-100 text-purple-600 rounded-xl"><Users size={24}/></div>
                    <span className="text-xs font-bold text-green-600 flex items-center gap-1">+5% <ArrowUpRight size={12}/></span>
                </div>
                <h3 className="text-3xl font-bold text-slate-800">{stats?.totalUsers}</h3>
                <p className="text-slate-500 text-sm">Usuários Totais</p>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <div className="flex justify-between items-start mb-4">
                    <div className="p-3 bg-green-100 text-green-600 rounded-xl"><Activity size={24}/></div>
                    <span className="text-xs font-bold text-green-600 flex items-center gap-1">+24% <ArrowUpRight size={12}/></span>
                </div>
                <h3 className="text-3xl font-bold text-slate-800">{stats?.activeSimulations}</h3>
                <p className="text-slate-500 text-sm">Simulações Hoje</p>
            </div>
             <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <div className="flex justify-between items-start mb-4">
                    <div className="p-3 bg-orange-100 text-orange-600 rounded-xl"><TrendingUp size={24}/></div>
                    <span className="text-xs font-bold text-slate-400">Tempo Real</span>
                </div>
                <h3 className="text-3xl font-bold text-slate-800">{stats?.dailyActiveUsers}</h3>
                <p className="text-slate-500 text-sm">Online Agora</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                 <div className="flex justify-between items-start mb-4">
                    <div className="p-3 bg-blue-100 text-blue-600 rounded-xl"><CreditCard size={24}/></div>
                </div>
                <h3 className="text-3xl font-bold text-slate-800">Plano Pro</h3>
                <p className="text-slate-500 text-sm">Assinatura mais vendida</p>
            </div>
         </div>

         <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Chart Area */}
            <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <h3 className="text-lg font-bold text-slate-800 mb-6">Receita vs. Custo API (7 dias)</h3>
                <div className="h-80 w-full">
                    <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0} debounce={50}>
                        <BarChart data={revenueData}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0"/>
                            <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b'}} dy={10} />
                            <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                            <Tooltip 
                                cursor={{fill: '#f1f5f9'}}
                                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                            />
                            <Legend />
                            <Bar dataKey="receita" name="Receita" fill="#2563eb" radius={[4, 4, 0, 0]} />
                            <Bar dataKey="custo_api" name="Custo API" fill="#ef4444" radius={[4, 4, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Recent Transactions */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-lg font-bold text-slate-800">Transações Recentes</h3>
                    <button className="text-blue-600 text-sm font-bold hover:underline">Ver todas</button>
                </div>
                <div className="space-y-4">
                    {stats?.recentTransactions.map(tx => (
                        <div key={tx.id} className="flex items-center justify-between p-3 hover:bg-slate-50 rounded-xl transition-colors">
                            <div className="flex items-center gap-3">
                                <div className={`p-2 rounded-lg ${tx.method === 'PIX' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}`}>
                                    <CreditCard size={16} />
                                </div>
                                <div>
                                    <p className="text-sm font-bold text-slate-800">{tx.userEmail}</p>
                                    <p className="text-xs text-slate-500">{tx.method} • {formatDate(tx.date)}</p>
                                </div>
                            </div>
                            <span className="font-bold text-green-600">+{formatCurrency(tx.amount)}</span>
                        </div>
                    ))}
                    {(!stats?.recentTransactions || stats.recentTransactions.length === 0) && (
                        <p className="text-slate-400 text-sm text-center py-4">Nenhuma transação recente.</p>
                    )}
                </div>
            </div>
         </div>

      </main>
    </div>
  );
};

export default AdminDashboard;
