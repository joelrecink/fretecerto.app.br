
import React, { useState, useEffect } from 'react';
import Logo from './Logo';
import { 
  LayoutDashboard, 
  Truck, 
  Users, 
  FileText, 
  AlertTriangle, 
  PieChart, 
  LogOut, 
  Plus, 
  TrendingUp, 
  TrendingDown, 
  DollarSign,
  Briefcase,
  Signal,
  BrainCircuit,
  Lock,
  Menu,
  X,
  CheckCircle,
  Circle
} from 'lucide-react';
import { ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid, Legend, AreaChart, Area } from 'recharts';
import { SavedVehicle, Employee, FinancialRecord, UserCredits } from '../types';
import { getUserVehicles, getStoredUser } from '../services/authService';
import { syncVehicleTelemetry } from '../services/telemetryService';
import { getFinancialRecords, addFinancialRecord, getEmployees, addEmployee, updateFinancialStatus } from '../services/dbService';
import { getStoredCredits, hasCredit, consumeCredit } from '../services/creditService';
import { analyzeFleetIntelligence } from '../services/geminiService'; // Import real AI service

interface FleetDashboardProps {
  onBack: () => void;
}

const FleetDashboard: React.FC<FleetDashboardProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'fleet' | 'hr' | 'finance'>('overview');
  
  const [vehicles, setVehicles] = useState<SavedVehicle[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [financials, setFinancials] = useState<FinancialRecord[]>([]);
  const [credits, setCredits] = useState<UserCredits>({ freeCredits: 0, premiumCredits: 0, lastResetDate: '' });

  // Form States
  const [showAddFinance, setShowAddFinance] = useState(false);
  const [newExpense, setNewExpense] = useState<Partial<FinancialRecord>>({ type: 'EXPENSE', category: 'MAINTENANCE', date: new Date().toISOString().split('T')[0], status: 'pending' });
  
  // AI Insights State
  const [showAiModal, setShowAiModal] = useState(false);
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);

  // Mobile Menu State
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
      loadData();
  }, []);

  const loadData = async () => {
      const v = await getUserVehicles();
      const f = await getFinancialRecords();
      const e = await getEmployees();
      setVehicles(v);
      setFinancials(f);
      setEmployees(e);
      
      // Update credits
      const user = getStoredUser();
      if (user) {
          const c = await getStoredCredits(user.phoneNumber);
          setCredits(c);
      }
  };

  const formatCurrency = (val: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  const calculateTotals = () => {
      const income = financials.filter(f => f.type === 'INCOME').reduce((acc, curr) => acc + curr.amount, 0);
      const expense = financials.filter(f => f.type === 'EXPENSE').reduce((acc, curr) => acc + curr.amount, 0);
      return { income, expense, balance: income - expense };
  };

  const totals = calculateTotals();

  const handleAddFinancial = async () => {
      if (!newExpense.description || !newExpense.amount) return alert("Preencha descrição e valor");
      await addFinancialRecord({
          type: newExpense.type || 'EXPENSE',
          category: newExpense.category || 'OTHER',
          description: newExpense.description,
          amount: parseFloat(newExpense.amount.toString()),
          date: newExpense.date || new Date().toISOString(),
          status: newExpense.status || 'pending',
          document_number: newExpense.document_number,
          vehicle_plate: newExpense.vehicle_plate
      });
      await loadData();
      setShowAddFinance(false);
      setNewExpense({ type: 'EXPENSE', category: 'MAINTENANCE', date: new Date().toISOString().split('T')[0], status: 'pending' });
  };

  const handleToggleStatus = async (record: FinancialRecord) => {
      const newStatus = record.status === 'pending' ? 'paid' : 'pending';
      const action = record.status === 'pending' ? 'Liquidar' : 'Reabrir';
      
      if (confirm(`Deseja realmente ${action} este lançamento?`)) {
          await updateFinancialStatus(record.id, newStatus);
          await loadData();
      }
  };

  const handleSyncTelemetry = async (plate: string) => {
      alert(`Sincronizando telemetria para ${plate}...`);
      await syncVehicleTelemetry('mock', plate);
      alert("Dados atualizados!");
  };

  const handleGenerateAiReport = async () => {
      const user = getStoredUser();
      if (!user) return;
      
      if (!hasCredit(credits)) {
          alert("Você precisa de créditos para gerar o Relatório de Inteligência.");
          return;
      }

      setLoadingAi(true);
      
      try {
        // CALL REAL AI SERVICE
        const report = await analyzeFleetIntelligence(financials, vehicles, employees);

        setAiReport(report);
        setShowAiModal(true);
        
        // Consume Credit
        const newCredits = await consumeCredit(credits, user.phoneNumber);
        setCredits(newCredits);

      } catch (e) {
          alert("Erro ao gerar relatório. Verifique sua conexão.");
      } finally {
          setLoadingAi(false);
      }
  };

  // Mock Chart Data based on real financials if possible, else default
  const chartData = [
      { name: 'Jan', receita: 15000, despesa: 12000 },
      { name: 'Fev', receita: totals.income || 18000, despesa: totals.expense || 11500 },
  ];

  return (
    <div className="flex flex-col md:flex-row h-screen bg-slate-100 font-sans overflow-hidden">
        
        {/* Desktop Sidebar */}
        <aside className="hidden md:flex w-64 bg-slate-900 text-white flex-col shadow-2xl z-20">
            <div className="p-6 flex items-center gap-3 border-b border-slate-800">
                <Logo className="w-8 h-8"/>
                <div className="leading-tight">
                    <h2 className="font-bold text-lg">Centro de Custo</h2>
                    <p className="text-xs text-slate-400">ERP Logístico</p>
                </div>
            </div>

            <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
                <button onClick={() => setActiveTab('overview')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'overview' ? 'bg-blue-600 shadow-lg shadow-blue-900/50 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                    <LayoutDashboard size={20}/> Visão Geral
                </button>
                <button onClick={() => setActiveTab('fleet')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'fleet' ? 'bg-blue-600 shadow-lg shadow-blue-900/50 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                    <Truck size={20}/> Frota & Telemetria
                </button>
                <button onClick={() => setActiveTab('hr')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'hr' ? 'bg-blue-600 shadow-lg shadow-blue-900/50 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                    <Users size={20}/> RH & Funcionários
                </button>
                <button onClick={() => setActiveTab('finance')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'finance' ? 'bg-blue-600 shadow-lg shadow-blue-900/50 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                    <FileText size={20}/> Financeiro & Notas
                </button>
            </nav>

            <div className="p-4 border-t border-slate-800">
                <div className="mb-4 px-2 py-2 bg-slate-800 rounded-lg text-xs text-slate-400 flex justify-between items-center">
                    <span>Créditos Disp:</span>
                    <span className="text-white font-bold">{credits.freeCredits + credits.premiumCredits}</span>
                </div>
                <button onClick={onBack} className="w-full flex items-center gap-2 text-slate-400 hover:text-white px-4 py-2 hover:bg-slate-800 rounded-lg transition-colors">
                    <LogOut size={18}/> Voltar ao Sistema
                </button>
            </div>
        </aside>

        {/* Mobile Header & Content */}
        <main className="flex-1 flex flex-col h-full overflow-hidden">
            
            {/* Mobile Header */}
            <div className="md:hidden bg-slate-900 text-white p-4 flex justify-between items-center z-30 shadow-md">
                 <div className="flex items-center gap-2">
                    <Logo className="w-8 h-8"/>
                    <span className="font-bold">Centro de Custo</span>
                 </div>
                 <button onClick={onBack} className="text-slate-300">
                    <LogOut size={24} />
                 </button>
            </div>

            {/* Scrollable Content Area */}
            <div className="flex-1 overflow-y-auto p-4 md:p-8 pb-24 md:pb-8 relative">
                
                {/* Stats Bar */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex items-center justify-between">
                        <div>
                            <p className="text-xs font-bold text-slate-400 uppercase">Receita Total</p>
                            <h3 className="text-xl font-bold text-slate-800">{formatCurrency(totals.income)}</h3>
                        </div>
                        <div className="p-2 bg-green-100 text-green-600 rounded-xl"><TrendingUp size={20}/></div>
                    </div>
                    <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex items-center justify-between">
                        <div>
                            <p className="text-xs font-bold text-slate-400 uppercase">Despesas Totais</p>
                            <h3 className="text-xl font-bold text-slate-800">{formatCurrency(totals.expense)}</h3>
                        </div>
                        <div className="p-2 bg-red-100 text-red-600 rounded-xl"><TrendingDown size={20}/></div>
                    </div>
                    <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex items-center justify-between">
                        <div>
                            <p className="text-xs font-bold text-slate-400 uppercase">Saldo Líquido</p>
                            <h3 className={`text-xl font-bold ${totals.balance >= 0 ? 'text-blue-600' : 'text-red-600'}`}>{formatCurrency(totals.balance)}</h3>
                        </div>
                        <div className="p-2 bg-blue-100 text-blue-600 rounded-xl"><DollarSign size={20}/></div>
                    </div>
                </div>

                {/* Content Switch */}
                {activeTab === 'overview' && (
                    <div className="space-y-6 animate-fade-in">
                        
                        {/* AI Insights Banner */}
                        <div className="bg-gradient-to-r from-indigo-600 to-purple-700 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
                            <div className="absolute right-0 top-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
                            <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                                <div>
                                    <h3 className="text-xl font-bold flex items-center gap-2"><BrainCircuit/> Inteligência da Frota</h3>
                                    <p className="text-indigo-100 text-sm mt-1 max-w-lg">
                                        Gere relatórios de eficiência, identifique gargalos e preveja manutenções.
                                    </p>
                                </div>
                                <button 
                                    onClick={handleGenerateAiReport}
                                    disabled={loadingAi}
                                    className="w-full md:w-auto bg-white text-indigo-700 font-bold py-3 px-6 rounded-xl shadow-lg hover:bg-indigo-50 transition-colors flex items-center justify-center gap-2 text-sm"
                                >
                                    {loadingAi ? <div className="animate-spin rounded-full h-4 w-4 border-2 border-indigo-600 border-t-transparent"></div> : <Briefcase size={18}/>}
                                    Gerar Relatório (1 Crédito)
                                </button>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                                <h3 className="font-bold text-lg mb-4 text-slate-800">Fluxo de Caixa (Visão Geral)</h3>
                                <div className="h-64">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <AreaChart data={chartData}>
                                            <defs>
                                                <linearGradient id="colorReceita" x1="0" y1="0" x2="0" y2="1">
                                                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.1}/>
                                                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                                                </linearGradient>
                                                <linearGradient id="colorDespesa" x1="0" y1="0" x2="0" y2="1">
                                                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.1}/>
                                                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                                                </linearGradient>
                                            </defs>
                                            <XAxis dataKey="name" />
                                            <YAxis />
                                            <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                            <Tooltip />
                                            <Legend />
                                            <Area type="monotone" dataKey="receita" stroke="#2563eb" fillOpacity={1} fill="url(#colorReceita)" />
                                            <Area type="monotone" dataKey="despesa" stroke="#ef4444" fillOpacity={1} fill="url(#colorDespesa)" />
                                        </AreaChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>

                            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                                <h3 className="font-bold text-lg mb-4 text-slate-800">Alertas Recentes</h3>
                                <div className="space-y-3">
                                    {employees.some(e => e.cnh_expiration && new Date(e.cnh_expiration) < new Date('2025-01-01')) && (
                                        <div className="flex items-center gap-3 p-3 bg-orange-50 text-orange-700 rounded-xl border border-orange-100">
                                            <AlertTriangle size={20} />
                                            <div>
                                                <p className="font-bold text-sm">CNH Próxima do Vencimento</p>
                                                <p className="text-xs">Verifique a situação dos motoristas.</p>
                                            </div>
                                        </div>
                                    )}
                                    {vehicles.length === 0 && (
                                        <div className="flex items-center gap-3 p-3 bg-blue-50 text-blue-700 rounded-xl border border-blue-100">
                                        <Truck size={20} />
                                        <div>
                                            <p className="font-bold text-sm">Cadastre sua frota</p>
                                            <p className="text-xs">Adicione veículos para gestão completa.</p>
                                        </div>
                                    </div>
                                    )}
                                    <div className="flex items-center gap-3 p-3 bg-slate-50 text-slate-600 rounded-xl border border-slate-200">
                                        <Lock size={20} />
                                        <div>
                                            <p className="font-bold text-sm">Dados Seguros</p>
                                            <p className="text-xs">Backup automático realizado hoje.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {activeTab === 'fleet' && (
                    <div className="space-y-6 animate-fade-in">
                        <div className="flex justify-between items-center">
                            <h2 className="text-xl font-bold text-slate-800">Gestão de Frota</h2>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {vehicles.map(v => (
                                <div key={v.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 group hover:border-blue-300 transition-colors">
                                    <div className="flex justify-between items-start mb-4">
                                        <div className="bg-slate-100 p-3 rounded-xl">
                                            <Truck className="text-slate-600" size={24}/>
                                        </div>
                                        <div className={`px-2 py-1 rounded text-xs font-bold ${v.last_oil_change_km ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}`}>
                                            {v.telemetry_provider ? 'Online' : 'Offline'}
                                        </div>
                                    </div>
                                    
                                    <h3 className="text-lg font-bold text-slate-800">{v.license_plate}</h3>
                                    <p className="text-sm text-slate-500 mb-4">{v.model_name || 'Modelo não informado'}</p>
                                    
                                    <div className="space-y-2 text-sm text-slate-600">
                                        <div className="flex justify-between">
                                            <span>Odômetro:</span>
                                            <span className="font-semibold">{v.current_odometer || 0} km</span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span>Média Consumo:</span>
                                            <span className="font-semibold">{v.fuel_consumption} km/l</span>
                                        </div>
                                    </div>

                                    <div className="mt-4 pt-4 border-t border-slate-100">
                                        <button 
                                            onClick={() => handleSyncTelemetry(v.license_plate)}
                                            className="w-full flex items-center justify-center gap-2 bg-slate-50 hover:bg-slate-100 text-slate-700 py-2 rounded-lg font-bold text-sm transition-colors"
                                        >
                                            <Signal size={16}/> Sincronizar Telemetria
                                        </button>
                                    </div>
                                </div>
                            ))}
                            {vehicles.length === 0 && (
                                <div className="col-span-3 text-center py-10 text-slate-400">
                                    Nenhum veículo cadastrado na garagem. Adicione veículos na tela inicial.
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {activeTab === 'hr' && (
                    <div className="space-y-6 animate-fade-in">
                        <div className="flex justify-between items-center">
                            <h2 className="text-xl font-bold text-slate-800">Recursos Humanos</h2>
                            <button className="bg-blue-600 text-white px-3 py-2 text-sm md:px-4 md:py-2 rounded-lg font-bold flex gap-2 hover:bg-blue-700"><Plus size={18}/> <span className="hidden md:inline">Novo Funcionário</span></button>
                        </div>

                        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-x-auto">
                            <table className="w-full text-left min-w-[600px]">
                                <thead className="bg-slate-50 border-b border-slate-200">
                                    <tr>
                                        <th className="p-4 font-bold text-slate-600">Nome</th>
                                        <th className="p-4 font-bold text-slate-600">Cargo</th>
                                        <th className="p-4 font-bold text-slate-600">Salário</th>
                                        <th className="p-4 font-bold text-slate-600">CNH</th>
                                        <th className="p-4 font-bold text-slate-600">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {employees.map(emp => (
                                        <tr key={emp.id} className="border-b border-slate-100 hover:bg-slate-50">
                                            <td className="p-4 font-bold text-slate-800">{emp.name}</td>
                                            <td className="p-4 text-slate-600 flex items-center gap-2">
                                                {emp.role === 'Motorista' ? <Truck size={16}/> : <Briefcase size={16}/>}
                                                {emp.role}
                                            </td>
                                            <td className="p-4 text-slate-600">{formatCurrency(emp.salary)}</td>
                                            <td className="p-4">
                                                {emp.cnh_expiration ? (
                                                    <span className={`text-xs font-bold px-2 py-1 rounded ${new Date(emp.cnh_expiration) < new Date() ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                                                        Vence: {new Date(emp.cnh_expiration).toLocaleDateString()}
                                                    </span>
                                                ) : '-'}
                                            </td>
                                            <td className="p-4">
                                                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-bold uppercase">Ativo</span>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}

                {activeTab === 'finance' && (
                    <div className="space-y-6 animate-fade-in">
                        <div className="flex justify-between items-center">
                            <h2 className="text-xl font-bold text-slate-800">Financeiro</h2>
                            <button onClick={() => setShowAddFinance(true)} className="bg-green-600 text-white px-3 py-2 text-sm md:px-4 md:py-2 rounded-lg font-bold flex gap-2 hover:bg-green-700"><Plus size={18}/> <span className="hidden md:inline">Nova Receita/Despesa</span></button>
                        </div>

                        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-x-auto">
                            <table className="w-full text-left min-w-[600px]">
                                <thead className="bg-slate-50 border-b border-slate-200">
                                    <tr>
                                        <th className="p-4 font-bold text-slate-600">Data</th>
                                        <th className="p-4 font-bold text-slate-600">Descrição</th>
                                        <th className="p-4 font-bold text-slate-600">Valor</th>
                                        <th className="p-4 font-bold text-slate-600">Status</th>
                                        <th className="p-4 font-bold text-slate-600">Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {financials.map(fin => (
                                        <tr key={fin.id} className="border-b border-slate-100 hover:bg-slate-50">
                                            <td className="p-4 text-slate-600 text-sm">{new Date(fin.date).toLocaleDateString()}</td>
                                            <td className="p-4">
                                                <span className="font-bold text-slate-800">{fin.description}</span>
                                                <div className="flex gap-2 mt-1">
                                                    <span className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded uppercase">{fin.category}</span>
                                                    {fin.vehicle_plate && <span className="text-[10px] bg-blue-50 text-blue-500 px-1.5 py-0.5 rounded font-bold">{fin.vehicle_plate}</span>}
                                                </div>
                                            </td>
                                            <td className={`p-4 font-bold ${fin.type === 'INCOME' ? 'text-green-600' : 'text-red-600'}`}>
                                                {fin.type === 'INCOME' ? '+' : '-'} {formatCurrency(fin.amount)}
                                            </td>
                                            <td className="p-4">
                                                <span className={`text-xs px-2 py-1 rounded font-bold uppercase ${fin.status === 'paid' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
                                                    {fin.status === 'paid' ? 'Pago' : 'Pendente'}
                                                </span>
                                            </td>
                                            <td className="p-4">
                                                {fin.status === 'pending' ? (
                                                    <button 
                                                        onClick={() => handleToggleStatus(fin)}
                                                        className={`flex items-center gap-1 text-xs font-bold px-3 py-1.5 rounded-lg transition-colors shadow-sm text-white ${fin.type === 'INCOME' ? 'bg-green-600 hover:bg-green-700' : 'bg-orange-500 hover:bg-orange-600'}`}
                                                    >
                                                        <CheckCircle size={14}/> {fin.type === 'INCOME' ? 'Receber' : 'Pagar'}
                                                    </button>
                                                ) : (
                                                    <button 
                                                        onClick={() => handleToggleStatus(fin)}
                                                        className="flex items-center gap-1 text-xs font-bold text-slate-400 hover:text-slate-600"
                                                        title="Reabrir Lançamento"
                                                    >
                                                        <CheckCircle size={16} className="text-green-500" /> Concluído
                                                    </button>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}
            </div>

            {/* Mobile Bottom Navigation Bar */}
            <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-[0_-4px_10px_rgba(0,0,0,0.05)] z-40 flex justify-around p-2">
                 <button onClick={() => setActiveTab('overview')} className={`flex flex-col items-center gap-1 p-2 rounded-lg ${activeTab==='overview' ? 'text-blue-600 bg-blue-50' : 'text-slate-400'}`}>
                     <LayoutDashboard size={20} />
                     <span className="text-[10px] font-bold">Visão</span>
                 </button>
                 <button onClick={() => setActiveTab('fleet')} className={`flex flex-col items-center gap-1 p-2 rounded-lg ${activeTab==='fleet' ? 'text-blue-600 bg-blue-50' : 'text-slate-400'}`}>
                     <Truck size={20} />
                     <span className="text-[10px] font-bold">Frota</span>
                 </button>
                 <button onClick={() => setActiveTab('finance')} className={`flex flex-col items-center gap-1 p-2 rounded-lg ${activeTab==='finance' ? 'text-blue-600 bg-blue-50' : 'text-slate-400'}`}>
                     <FileText size={20} />
                     <span className="text-[10px] font-bold">Finanças</span>
                 </button>
                 <button onClick={() => setActiveTab('hr')} className={`flex flex-col items-center gap-1 p-2 rounded-lg ${activeTab==='hr' ? 'text-blue-600 bg-blue-50' : 'text-slate-400'}`}>
                     <Users size={20} />
                     <span className="text-[10px] font-bold">RH</span>
                 </button>
            </div>

            {/* Modal Add Finance */}
            {showAddFinance && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
                    <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md space-y-4">
                        <h3 className="font-bold text-lg text-slate-800">Adicionar Movimentação</h3>
                        
                        <div className="grid grid-cols-2 gap-4">
                            <select 
                                className="p-3 border rounded-xl"
                                value={newExpense.type}
                                onChange={e => setNewExpense({...newExpense, type: e.target.value as any})}
                            >
                                <option value="EXPENSE">Despesa</option>
                                <option value="INCOME">Receita</option>
                            </select>
                            <select 
                                className="p-3 border rounded-xl"
                                value={newExpense.category}
                                onChange={e => setNewExpense({...newExpense, category: e.target.value as any})}
                            >
                                <option value="FUEL">Combustível</option>
                                <option value="MAINTENANCE">Manutenção</option>
                                <option value="FINE">Multa</option>
                                <option value="SALARY">Salário</option>
                                <option value="TAX">Imposto</option>
                                <option value="FREIGHT">Frete</option>
                                <option value="OTHER">Outro</option>
                            </select>
                        </div>

                        <input 
                            className="w-full p-3 border rounded-xl" 
                            placeholder="Descrição (Ex: Abastecimento)" 
                            value={newExpense.description || ''}
                            onChange={e => setNewExpense({...newExpense, description: e.target.value})}
                        />
                        
                        <div className="grid grid-cols-2 gap-4">
                            <input 
                                type="number"
                                className="w-full p-3 border rounded-xl" 
                                placeholder="Valor (R$)" 
                                value={newExpense.amount || ''}
                                onChange={e => setNewExpense({...newExpense, amount: parseFloat(e.target.value)})}
                            />
                             <input 
                                type="date"
                                className="w-full p-3 border rounded-xl" 
                                value={newExpense.date}
                                onChange={e => setNewExpense({...newExpense, date: e.target.value})}
                            />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                             <input 
                                className="w-full p-3 border rounded-xl" 
                                placeholder="NFe / Doc (Opcional)" 
                                value={newExpense.document_number || ''}
                                onChange={e => setNewExpense({...newExpense, document_number: e.target.value})}
                            />
                            <select 
                                className="p-3 border rounded-xl"
                                value={newExpense.vehicle_plate || ''}
                                onChange={e => setNewExpense({...newExpense, vehicle_plate: e.target.value})}
                            >
                                <option value="">Sem veículo</option>
                                {vehicles.map(v => (
                                    <option key={v.id} value={v.license_plate}>{v.license_plate}</option>
                                ))}
                            </select>
                        </div>

                        <div className="flex gap-3 pt-2">
                            <button onClick={() => setShowAddFinance(false)} className="flex-1 p-3 bg-slate-100 rounded-xl font-bold text-slate-600">Cancelar</button>
                            <button onClick={handleAddFinancial} className="flex-1 p-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-bold">Salvar</button>
                        </div>
                    </div>
                </div>
            )}

            {/* Modal AI Report */}
            {showAiModal && aiReport && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
                    <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-lg space-y-6 relative overflow-hidden">
                        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-indigo-500 to-purple-500"></div>
                        
                        <div className="flex items-center gap-3">
                            <div className="bg-indigo-100 p-3 rounded-full text-indigo-600">
                                <BrainCircuit size={32} />
                            </div>
                            <h2 className="text-2xl font-black text-slate-900">Relatório Inteligente</h2>
                        </div>

                        <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 text-slate-700 leading-relaxed text-sm whitespace-pre-line max-h-[60vh] overflow-y-auto">
                            {aiReport}
                        </div>

                        <button 
                            onClick={() => setShowAiModal(false)}
                            className="w-full bg-slate-900 text-white font-bold py-4 rounded-xl hover:bg-black transition-colors"
                        >
                            Fechar Relatório
                        </button>
                    </div>
                </div>
            )}

        </main>
    </div>
  );
};

export default FleetDashboard;
