
import React from 'react';
import { RouteData, VehicleData } from '../types';
import { Truck, MapPin, DollarSign, Edit3, Navigation, Package, User, ArrowLeft, Save, FileText, ExternalLink, CheckCircle2 } from 'lucide-react';
import Logo from './Logo';

interface ReviewScreenProps {
  vehicle: VehicleData;
  route: RouteData;
  onEditVehicle: () => void;
  onEditRoute: (step: 'pickup' | 'delivery') => void;
  onAnalyze: () => void;
  onSaveOnly: () => void;
  onBack: () => void;
  isLoading: boolean;
}

const ReviewScreen: React.FC<ReviewScreenProps> = ({ 
  vehicle, 
  route, 
  onEditVehicle, 
  onEditRoute, 
  onAnalyze,
  onSaveOnly,
  onBack, 
  isLoading 
}) => {
  
  const totalFreight = [...route.pickups, ...route.deliveries].reduce((acc, curr) => acc + (curr.value || 0), 0);
  
  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  const openMapCheck = (address: string) => {
    if (!address) return;
    const query = encodeURIComponent(address);
    window.open(`https://www.google.com/maps/search/?api=1&query=${query}`, '_blank');
  };

  return (
    <div className="max-w-3xl mx-auto pb-44 animate-fade-in space-y-6">
      
      {/* Header */}
      <div className="bg-slate-900 text-white p-8 rounded-3xl shadow-xl flex items-center justify-between relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>
        <div className="relative z-10">
            <div className="flex items-center gap-2 mb-2">
                <FileText className="text-blue-400" size={20}/>
                <span className="text-xs font-bold uppercase tracking-wider text-blue-200">Conferência Segura</span>
            </div>
            <h2 className="text-3xl font-bold flex items-center gap-3">
                Resumo da Viagem
            </h2>
            <p className="text-slate-400 mt-2 text-sm max-w-md">Confira os endereços e valores abaixo antes de calcular a viabilidade.</p>
        </div>
        <div className="text-right hidden sm:block relative z-10">
            <p className="text-xs text-slate-400 uppercase font-bold">Total do Frete</p>
            <p className="text-3xl font-black text-green-400">{formatCurrency(totalFreight)}</p>
        </div>
      </div>

      {/* Vehicle & Driver Summary */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 relative group hover:border-blue-300 transition-colors">
         <button 
            onClick={onEditVehicle}
            className="absolute top-4 right-4 text-blue-600 hover:bg-blue-50 p-2 rounded-lg transition-colors flex items-center gap-1 text-xs font-bold uppercase tracking-wide"
         >
            <Edit3 size={14} /> Editar
         </button>

         <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <div className="bg-blue-100 p-2 rounded-lg text-blue-600"><Truck size={20} /></div>
            Dados do Veículo
         </h3>

         <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
                <div className="bg-white p-2 rounded-full text-slate-500 shadow-sm"><User size={16}/></div>
                <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Motorista</span>
                    <span className="font-bold text-slate-800">{vehicle.driverName || 'Não informado'}</span>
                </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
                 <div className="bg-white p-2 rounded-full text-slate-500 shadow-sm"><Truck size={16}/></div>
                 <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Configuração</span>
                    <span className="font-bold text-slate-800">{vehicle.axles} Eixos • {vehicle.cargoCapacity} Ton</span>
                 </div>
            </div>
         </div>
      </div>

      {/* Route Visualizer - Manifest Style */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
         <div className="bg-slate-50 p-4 border-b border-gray-200 flex justify-between items-center">
            <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                <Navigation size={20} className="text-slate-600" />
                Pontos da Rota
            </h3>
            <span className="text-xs bg-white border border-slate-200 px-2 py-1 rounded text-slate-500">
                {route.pickups.length + route.deliveries.length} Locais
            </span>
         </div>

         <div className="p-6 relative">
             {/* Connector Line */}
            <div className="absolute left-[43px] top-8 bottom-8 w-0.5 bg-gradient-to-b from-green-500 via-slate-300 to-blue-500"></div>
            
            <div className="space-y-8">
                {/* Pickups */}
                <div>
                    <div className="flex justify-between items-center mb-4 pl-14">
                        <span className="text-green-700 text-xs font-bold uppercase tracking-widest flex items-center gap-1">
                            <CheckCircle2 size={12}/> Origem / Coleta
                        </span>
                        <button onClick={() => onEditRoute('pickup')} className="text-slate-400 hover:text-blue-600 text-xs font-bold flex items-center gap-1 transition-colors"><Edit3 size={12}/> Editar</button>
                    </div>
                    
                    {route.pickups.map((p, idx) => (
                        <div key={p.id} className="relative flex items-start gap-4 mb-6 last:mb-0 group">
                            {/* Dot */}
                            <div className="absolute left-[11px] top-1 w-4 h-4 rounded-full bg-green-500 border-4 border-white shadow-sm z-10"></div>
                            
                            {/* Number */}
                            <div className="w-10 text-right font-mono text-xs text-slate-300 font-bold pt-1 mr-1">
                                {String(idx + 1).padStart(2, '0')}
                            </div>

                            {/* Content Card */}
                            <div className="flex-1">
                                <div className="bg-white p-4 rounded-xl border-2 border-slate-100 hover:border-green-400 transition-all shadow-sm group-hover:shadow-md">
                                    <div className="flex justify-between items-start gap-4">
                                        <div className="flex-1">
                                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Endereço de Coleta</p>
                                            <p className="font-bold text-slate-900 text-lg leading-tight">
                                                {p.address || 'Endereço não informado'}
                                            </p>
                                        </div>
                                        <button 
                                            onClick={() => openMapCheck(p.address)}
                                            className="text-blue-600 bg-blue-50 p-2 rounded-lg hover:bg-blue-100 transition-colors"
                                            title="Conferir no Google Maps"
                                        >
                                            <ExternalLink size={18} />
                                        </button>
                                    </div>
                                    
                                    {(p.value > 0 || p.weight > 0) && (
                                        <div className="mt-3 pt-3 border-t border-slate-50 flex flex-wrap gap-2 text-xs">
                                            {p.weight > 0 && (
                                                <span className="font-bold text-slate-600 bg-slate-100 px-2 py-1 rounded border border-slate-200">
                                                    📦 {p.weight} Ton
                                                </span>
                                            )}
                                            {p.value > 0 && (
                                                <span className="font-bold text-green-700 bg-green-50 px-2 py-1 rounded border border-green-100">
                                                    💰 +{formatCurrency(p.value)}
                                                </span>
                                            )}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Deliveries */}
                <div>
                    <div className="flex justify-between items-center mb-4 pl-14 pt-2">
                        <span className="text-blue-700 text-xs font-bold uppercase tracking-widest flex items-center gap-1">
                            <CheckCircle2 size={12}/> Destino / Entrega
                        </span>
                        <button onClick={() => onEditRoute('delivery')} className="text-slate-400 hover:text-blue-600 text-xs font-bold flex items-center gap-1 transition-colors"><Edit3 size={12}/> Editar</button>
                    </div>
                    
                    {route.deliveries.map((p, idx) => (
                        <div key={p.id} className="relative flex items-start gap-4 mb-6 last:mb-0 group">
                            {/* Dot */}
                            <div className="absolute left-[11px] top-1 w-4 h-4 rounded-full bg-blue-600 border-4 border-white shadow-sm z-10"></div>
                            
                            {/* Number */}
                            <div className="w-10 text-right font-mono text-xs text-slate-300 font-bold pt-1 mr-1">
                                {String(idx + 1).padStart(2, '0')}
                            </div>

                            {/* Content Card */}
                            <div className="flex-1">
                                <div className="bg-white p-4 rounded-xl border-2 border-slate-100 hover:border-blue-400 transition-all shadow-sm group-hover:shadow-md">
                                     <div className="flex justify-between items-start gap-4">
                                        <div className="flex-1">
                                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Endereço de Entrega</p>
                                            <p className="font-bold text-slate-900 text-lg leading-tight">
                                                {p.address || 'Endereço não informado'}
                                            </p>
                                        </div>
                                        <button 
                                            onClick={() => openMapCheck(p.address)}
                                            className="text-blue-600 bg-blue-50 p-2 rounded-lg hover:bg-blue-100 transition-colors"
                                            title="Conferir no Google Maps"
                                        >
                                            <ExternalLink size={18} />
                                        </button>
                                    </div>

                                    {p.value > 0 && (
                                        <div className="mt-3 pt-3 border-t border-slate-50 text-xs">
                                            <span className="font-bold text-green-700 bg-green-50 px-2 py-1 rounded border border-green-100">
                                                💰 +{formatCurrency(p.value)} (Extra)
                                            </span>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
         </div>
      </div>

      {/* DUAL ACTION BUTTONS (Single now) */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/95 backdrop-blur-md border-t border-gray-200 z-50 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)]">
        <div className="max-w-3xl mx-auto flex flex-col md:flex-row gap-3">
             {/* SAVE ONLY HIDDEN (ERP DISABLED)
             <button
                onClick={onSaveOnly}
                disabled={isLoading}
                className="flex-1 bg-white text-slate-700 border-2 border-slate-200 hover:bg-slate-50 font-bold py-4 rounded-xl shadow-sm flex items-center justify-center gap-2 text-sm md:text-base transition-all active:scale-[0.98]"
             >
                <Save size={20} className="text-slate-500" />
                <div className="text-left">
                    <span className="block leading-none">Apenas Registrar</span>
                    <span className="text-[10px] uppercase font-bold opacity-70">Grátis • Sem IA</span>
                </div>
             </button>
             */}

             <button
                onClick={onAnalyze}
                disabled={isLoading}
                className={`w-full text-white font-bold py-4 rounded-xl shadow-xl flex items-center justify-center gap-3 text-lg transition-all
                ${isLoading ? 'bg-slate-400 cursor-not-allowed' : 'bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-700 hover:to-indigo-800 active:scale-[0.98] ring-4 ring-blue-500/20'}
                `}
             >
                {isLoading ? (
                <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    Calculando...
                </>
                ) : (
                <>
                    <DollarSign size={24} />
                    <div className="text-left">
                        <span className="block leading-none">Calcular Lucro Real</span>
                        <span className="text-[10px] text-blue-200 uppercase font-bold">IA + Pedágios + Rotas</span>
                    </div>
                </>
                )}
             </button>
        </div>
      </div>

    </div>
  );
};

export default ReviewScreen;
